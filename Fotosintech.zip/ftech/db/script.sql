-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 05-03-2024 a las 22:55:17
-- Versión del servidor: 10.4.28-MariaDB
-- Versión de PHP: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `fotosintech`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `bloque`
--

CREATE TABLE `bloque` (
  `bloqid` bigint(11) NOT NULL,
  `nombloq` varchar(255) DEFAULT NULL,
  `empid` bigint(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `bloque`
--

INSERT INTO `bloque` (`bloqid`, `nombloq`, `empid`) VALUES
(1, 'Bloque', 1),
(20, 'Bloque', 1),
(22, 'Bloque', 1),
(23, 'Bloquesito', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `blqxcam`
--

CREATE TABLE `blqxcam` (
  `bloqid` bigint(11) NOT NULL,
  `camid` bigint(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `blqxcam`
--

INSERT INTO `blqxcam` (`bloqid`, `camid`) VALUES
(1, 1),
(1, 2),
(1, 3),
(1, 4),
(20, 2),
(20, 6),
(20, 6),
(20, 4),
(20, 4),
(20, 5),
(20, 3),
(20, 3),
(20, 4),
(20, 1),
(22, 1),
(22, 1),
(22, 1),
(22, 3),
(22, 5),
(23, 6),
(23, 4),
(23, 5),
(23, 3),
(23, 3),
(23, 5);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cama`
--

CREATE TABLE `cama` (
  `camid` bigint(11) NOT NULL,
  `florid` bigint(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `cama`
--

INSERT INTO `cama` (`camid`, `florid`) VALUES
(2, 1),
(6, 10),
(1, 32),
(4, 36),
(3, 46),
(5, 58);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `dominio`
--

CREATE TABLE `dominio` (
  `domid` bigint(11) NOT NULL,
  `nomd` varchar(70) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `dominio`
--

INSERT INTO `dominio` (`domid`, `nomd`) VALUES
(2, 'Tipo documento'),
(6, 'Estado Civil'),
(101, 'Empaques'),
(102, 'Tipos De Flor'),
(202, 'Procesos');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `empresa`
--

CREATE TABLE `empresa` (
  `empid` bigint(11) NOT NULL,
  `ubid` bigint(11) NOT NULL,
  `nemp` varchar(100) NOT NULL,
  `nitemp` varchar(100) NOT NULL,
  `diremp` varchar(255) NOT NULL,
  `email` varchar(45) NOT NULL,
  `tel` int(11) NOT NULL,
  `logo` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `empresa`
--

INSERT INTO `empresa` (`empid`, `ubid`, `nemp`, `nitemp`, `diremp`, `email`, `tel`, `logo`) VALUES
(1, 25175, 'FOTOSINTECH', '123456', 'cl 4 #2-45', 'miemp@empre.com', 123456, 'img/emp_20240301085535.png');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `fitopat`
--

CREATE TABLE `fitopat` (
  `fitoid` bigint(11) NOT NULL,
  `empid` bigint(11) NOT NULL,
  `nomfito` varchar(45) DEFAULT NULL,
  `tpfito` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `fitopat`
--

INSERT INTO `fitopat` (`fitoid`, `empid`, `nomfito`, `tpfito`) VALUES
(2, 1, 'Mosca Blanca', 'Enfermedades Abioticas'),
(4, 1, 'Roya', 'Enfermedades Bioticas'),
(5, 1, 'Botritis', 'Enfermedades Bioticas'),
(6, 1, 'Araña', 'Enfermedades Abioticas'),
(7, 1, 'Trip', 'Enfermedades Abioticas');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `flor`
--

CREATE TABLE `flor` (
  `florid` bigint(11) NOT NULL,
  `desf` varchar(45) DEFAULT NULL,
  `color` varchar(45) NOT NULL,
  `cuidaf` varchar(255) DEFAULT NULL,
  `imgf` varchar(255) DEFAULT NULL,
  `valid` bigint(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `flor`
--

INSERT INTO `flor` (`florid`, `desf`, `color`, `cuidaf`, `imgf`, `valid`) VALUES
(1, 'prueba', 'Color prueba', 'esta es una prueba ', 'img/flor_20240304170231.jpg', 207),
(2, 'Vendela', 'Blanco', '', NULL, 207),
(4, 'Jessica', 'Rosado Claro', NULL, NULL, 207),
(5, 'Ladies Night', 'Rosado Oscuro', NULL, NULL, 207),
(6, 'Sugar Doll', 'Blanco', NULL, NULL, 207),
(7, 'Freedom', 'Rojo', NULL, NULL, 207),
(8, 'Engagement', 'Bicolor Rosado', NULL, NULL, 207),
(9, 'Diplomat', 'Bicolor Rosado', NULL, NULL, 207),
(10, 'Panama', 'Bicolor Rosado', NULL, NULL, 207),
(11, 'Satina', 'Bicolor Rosado', NULL, NULL, 207),
(12, 'Panama', 'Bicolor Rosado', NULL, NULL, 207),
(13, 'Amber', 'Naranja', NULL, NULL, 207),
(14, 'Marilyn', 'Bicolor Rosado ', NULL, NULL, 207),
(15, 'Erin', 'Naranja', NULL, NULL, 207),
(16, 'Sandra', 'Rosado Claro ', NULL, NULL, 207),
(17, 'Impact', 'Naranja', NULL, NULL, 207),
(18, 'Deep Purple', 'Lavanda ', NULL, NULL, 207),
(19, 'Tormenta', 'Bicolor Rosado ', NULL, NULL, 207),
(20, 'Frutetto', 'Bicolor Rosado ', NULL, NULL, 207),
(21, 'Pink Candy', 'Rosado Claro ', NULL, NULL, 207),
(22, 'Panama', 'Bicolor Rosado ', NULL, NULL, 207),
(23, 'Hightlander', 'Bicolor Rosado ', NULL, NULL, 207),
(24, 'Tabata', 'Rosado Oscuro  ', NULL, NULL, 207),
(25, 'Queen Berry', 'Rosado Oscuro  ', NULL, NULL, 207),
(26, 'Shay', 'Rosado Claro ', NULL, NULL, 207),
(27, 'Hight Magic', 'Amarillo ', NULL, NULL, 207),
(28, 'Citran', 'Amarillo ', NULL, NULL, 207),
(29, 'Skyline', 'Amarillo ', NULL, NULL, 207),
(30, 'Cool Water', 'Lavanda ', NULL, NULL, 207),
(31, 'Estratosphere', 'Amarillo ', NULL, NULL, 207),
(32, 'Canary', 'Amarillo ', NULL, NULL, 207),
(34, 'Escansano', 'Blanco ', NULL, NULL, 208),
(35, 'Shaday', 'Naranja', NULL, NULL, 208),
(36, 'General', 'Naranja', NULL, NULL, 208),
(37, 'Pavia', 'Amarillo ', NULL, NULL, 208),
(38, 'Hinault', 'Amarillo ', NULL, NULL, 208),
(39, 'Tressor', 'Naranja', NULL, NULL, 208),
(40, 'Big Smile (Rojo)', 'Rojo ', NULL, NULL, 209),
(41, 'Teddy Bear (Rojo)', 'Rojo ', NULL, NULL, 209),
(42, 'Sunspot (Rojo)', 'Rojo ', NULL, NULL, 209),
(43, 'Moonwalker (Rojo)', 'Rojo ', NULL, NULL, 209),
(44, 'Big Smile (Naranja)', 'Naranja', NULL, NULL, 209),
(45, 'Teddy Bear (Naranja)', 'Naranja', NULL, NULL, 209),
(46, 'Sunspot (Naranja)', 'Naranja', NULL, NULL, 209),
(47, 'Moonwalker (Naranja)', 'Naranja', NULL, NULL, 209),
(48, 'Big Smile (Amarillo)', 'Amarillo ', NULL, NULL, 209),
(49, 'Teddy Bear(Amarillo)', 'Amarillo ', NULL, NULL, 209),
(50, 'Sunspot(Amarillo)', 'Amarillo ', NULL, NULL, 209),
(51, 'Moonwalker(Amarillo)', 'Amarillo ', NULL, NULL, 209),
(52, 'Big Smile (Otro Color)', 'Otro Color', NULL, NULL, 209),
(53, 'Teddy Bear(Otro Color)', 'Otro Color', NULL, NULL, 209),
(54, 'Sunspot(Otro Color)', 'Otro Color', NULL, NULL, 209),
(55, 'Moonwalker(Otro Color)', 'Otro Color', NULL, NULL, 209),
(56, 'Jamaica', 'Amarillo ', NULL, NULL, 210),
(57, 'Red Will', 'Rojo ', NULL, NULL, 210),
(58, 'Malta', 'Rosado Claro ', NULL, NULL, 210),
(59, 'Fuggi', 'Blanco ', NULL, NULL, 210),
(60, 'Nacional(Blanco)', 'Blanco ', NULL, NULL, 200),
(61, 'Nacional(Rojo)', 'Rojo ', NULL, NULL, 200),
(62, 'Nacional(Amarillo)', 'Amarillo ', NULL, NULL, 200),
(63, 'Nacional(Naranja)', 'Naranja', NULL, NULL, 200),
(64, 'Nacional(Bicolor)', 'Bicolor ', NULL, NULL, 200),
(65, 'Nacional(Rosado)', 'Rosado Claro ', NULL, NULL, 200),
(66, 'Nacional(Otro Color)', 'Otro Color', NULL, NULL, 200),
(87, 'bvhmbgkjfhyjgjkfy', 'Rosado Claro', 'hjgkjhgugilg', 'img/flor_20240304155156.png', 207);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `fumigacion`
--

CREATE TABLE `fumigacion` (
  `fumid` bigint(11) NOT NULL,
  `bloqid` bigint(11) DEFAULT NULL,
  `quimid` bigint(11) DEFAULT NULL,
  `fecha` datetime DEFAULT NULL,
  `perid` bigint(11) DEFAULT NULL,
  `dosis` float DEFAULT NULL,
  `ncamas` int(10) DEFAULT NULL,
  `ltsxcama` float DEFAULT NULL,
  `totagua` float DEFAULT NULL,
  `totquim` float DEFAULT NULL,
  `elival` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `modulo`
--

CREATE TABLE `modulo` (
  `modid` bigint(11) NOT NULL,
  `nomod` varchar(100) NOT NULL,
  `imgmod` varchar(255) NOT NULL,
  `actmod` tinyint(1) NOT NULL,
  `pagid` bigint(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `modulo`
--

INSERT INTO `modulo` (`modid`, `nomod`, `imgmod`, `actmod`, `pagid`) VALUES
(1, 'Configuración', 'img/mod_20240229164010.png', 1, 502),
(2, 'Cultivo', 'img/mod_20240229164102.png', 1, 102);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pagina`
--

CREATE TABLE `pagina` (
  `pagid` bigint(11) NOT NULL,
  `pagnom` varchar(45) DEFAULT NULL,
  `pagarc` varchar(100) DEFAULT NULL,
  `pagmos` int(3) DEFAULT NULL,
  `pagord` int(3) DEFAULT NULL,
  `pagmen` varchar(30) DEFAULT NULL,
  `icono` varchar(245) DEFAULT NULL,
  `modid` bigint(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `pagina`
--

INSERT INTO `pagina` (`pagid`, `pagnom`, `pagarc`, `pagmos`, `pagord`, `pagmen`, `icono`, `modid`) VALUES
(103, 'Bloque', 'views/vbloq.php', 1, 3, 'home.php', 'bloque.svg', 2),
(201, 'Cama', 'views/vcam.php', 1, 4, 'home.php', 'cama.svg', 2),
(303, 'Post cosecha', 'views/vpcos.php', 1, 6, 'home.php', 'postco.svg', 2),
(304, 'Fumigación', 'views/vfum.php', 1, 7, 'home.php', 'fumig.svg', 2),
(401, 'Perfil', 'views/vpef.php', 1, 12, 'home.php', 'perfil.svg', 1),
(402, 'perfil - persona', 'views/vpfxper.php', 2, 9, 'home.php', 'fa-solid fa-bars', 1),
(403, 'pagina - persona', 'views/pagxper.php', 2, 10, 'home.php', 'fa-regular fa-rectangle-list', 1),
(501, 'Pagina ', 'views/vpag.php', 1, 11, 'home.php', 'file.svg', 1),
(502, 'Persona', 'views/vper.php', 1, 1, 'home.php', 'user.svg', 1),
(503, 'Fitopatología', 'views/vfitopat.php', 1, 13, 'home.php', 'fitop.svg', 2),
(601, 'Quimicos', 'views/vquim.php', 1, 14, 'home.php', 'jar.svg', 2),
(603, 'Flor', 'views/vflor.php', 1, 8, 'home.php', 'flower.svg', 2),
(604, 'Dominio', 'views/vdom.php', 1, 17, 'home.php', 'dominio.svg', 1),
(605, 'Valor', 'views/vval.php', 1, 18, 'home.php', 'val.svg', 1),
(701, 'Módulo', 'views/vmod.php', 1, 21, 'home.php', 'folder.svg', 1),
(1001, 'Empresa', 'views/vemp.php', 1, 2, 'home.php', 'emp.svg', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `perfil`
--

CREATE TABLE `perfil` (
  `pefid` bigint(11) NOT NULL,
  `pefnom` varchar(45) DEFAULT NULL,
  `modid` bigint(11) NOT NULL,
  `pagid` bigint(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `perfil`
--

INSERT INTO `perfil` (`pefid`, `pefnom`, `modid`, `pagid`) VALUES
(1, 'Administrador', 1, 502),
(2, 'Empresa', 1, 502),
(3, 'Supervisor', 2, 303),
(5, 'Admin cultivo', 2, 603);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `persona`
--

CREATE TABLE `persona` (
  `perid` bigint(11) NOT NULL,
  `empid` bigint(11) NOT NULL,
  `ndper` varchar(12) DEFAULT NULL,
  `nomper` varchar(45) DEFAULT NULL,
  `apper` varchar(45) DEFAULT NULL,
  `emaper` varchar(245) DEFAULT NULL,
  `passper` varchar(45) DEFAULT NULL,
  `dirper` varchar(45) DEFAULT NULL,
  `telper` varchar(10) DEFAULT NULL,
  `ubid` bigint(11) DEFAULT NULL,
  `fecnacper` datetime DEFAULT NULL,
  `actper` tinyint(1) NOT NULL,
  `sexo` varchar(1) NOT NULL,
  `clav` varchar(500) DEFAULT NULL,
  `fecsol` datetime DEFAULT NULL,
  `feccam` datetime DEFAULT NULL,
  `estper` bigint(11) NOT NULL,
  `ocuper` varchar(30) NOT NULL,
  `foto` varchar(150) DEFAULT NULL,
  `pass` varchar(45) DEFAULT NULL,
  `fecsper` date DEFAULT NULL,
  `tipdper` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `persona`
--

INSERT INTO `persona` (`perid`, `empid`, `ndper`, `nomper`, `apper`, `emaper`, `passper`, `dirper`, `telper`, `ubid`, `fecnacper`, `actper`, `sexo`, `clav`, `fecsol`, `feccam`, `estper`, `ocuper`, `foto`, `pass`, `fecsper`, `tipdper`) VALUES
(1, 1, '123456', 'Felipe', 'Rodriguez', 'feliperodriguezamaya916@gmail.com', '10470c3b4b1fed12c3baac014be15fac67c6e815Xg5%', 'La granja', '3224357097', 25200, '2001-06-21 00:00:00', 1, 'M', NULL, NULL, NULL, 213, 'Estudiante', 'pepe.avif', NULL, NULL, '218'),
(2, 1, '123456', 'sergio', 'pedraza', 'pedrazacan16@gmail.com', '10470c3b4b1fed12c3baac014be15fac67c6e815Xg5%', 'calle 10 n6 a 46', '3106998709', 25899, '2004-08-28 00:00:00', 1, 'M', NULL, NULL, NULL, 213, 'Estudiante', NULL, NULL, NULL, '218'),
(4, 1, '1075652425', 'Brayan', 'Cuevas ', 'brayan004c@gmail.com', '10470c3b4b1fed12c3baac014be15fac67c6e815Xg5%', 'cl 7a #5-53', '3012678715', 25899, '2004-10-13 00:00:00', 1, 'M', NULL, NULL, NULL, 215, 'Estudiante', 'img/per_20240304162613.jpg', NULL, NULL, '218'),
(8, 1, '1000594632', 'Juan ', 'Buitrago', 'juansebastiang01@outlook.com', '10470c3b4b1fed12c3baac014be15fac67c6e815Xg5%', 'Conjunto San German ', '3023122176', 25175, '2003-05-24 00:00:00', 1, 'M', NULL, NULL, NULL, 213, 'Estudiante', NULL, NULL, NULL, '218');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `perxpef`
--

CREATE TABLE `perxpef` (
  `perid` bigint(11) DEFAULT NULL,
  `pefid` bigint(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `perxpef`
--

INSERT INTO `perxpef` (`perid`, `pefid`) VALUES
(1, 3),
(2, 2),
(2, 5),
(8, 1),
(8, 5),
(4, 1),
(4, 5);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pgxpef`
--

CREATE TABLE `pgxpef` (
  `pefid` bigint(11) DEFAULT NULL,
  `pagid` bigint(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `pgxpef`
--

INSERT INTO `pgxpef` (`pefid`, `pagid`) VALUES
(3, 303),
(3, 304),
(2, 403),
(2, 502),
(1, 401),
(1, 402),
(1, 403),
(1, 501),
(1, 502),
(1, 604),
(1, 605),
(1, 701),
(1, 1001),
(5, 103),
(5, 201),
(5, 303),
(5, 304),
(5, 503),
(5, 601),
(5, 603);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `postcos`
--

CREATE TABLE `postcos` (
  `cosecid` bigint(11) NOT NULL,
  `bloqid` bigint(11) DEFAULT NULL,
  `fech` datetime DEFAULT NULL,
  `cant` int(45) DEFAULT NULL,
  `florid` bigint(11) DEFAULT NULL,
  `valid` bigint(11) DEFAULT NULL,
  `ncajas` int(11) DEFAULT NULL,
  `tam` varchar(45) NOT NULL,
  `emp` varchar(45) NOT NULL,
  `perid` bigint(11) NOT NULL,
  `elival` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `quimico`
--

CREATE TABLE `quimico` (
  `quimid` bigint(11) NOT NULL,
  `empid` bigint(11) NOT NULL,
  `nomquim` varchar(45) NOT NULL,
  `actquim` tinyint(1) DEFAULT NULL,
  `ingreact` varchar(45) NOT NULL,
  `fitoid` bigint(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `quimico`
--

INSERT INTO `quimico` (`quimid`, `empid`, `nomquim`, `actquim`, `ingreact`, `fitoid`) VALUES
(3, 1, 'Pirimifos-metilo', 1, 'Organofosforado', 2),
(4, 1, 'Deltametrina', 1, 'Deltametrina', 2),
(5, 1, 'Aceite de neem', 1, 'azadiractina', 2),
(6, 1, 'Tebuconazol', 1, 'triazol', 4),
(7, 1, 'Propiconazol ', 1, 'triazol', 4),
(8, 1, 'Trifloxistrobina ', 1, 'estrobilurina', 4),
(9, 1, 'Azoxistrobina ', 1, 'estrobilurina', 4),
(10, 1, 'Bifentrina', 1, 'piretroide', 6),
(11, 1, ' Imidacloprid ', 1, 'neonicotinoide', 6),
(12, 1, 'Fludioxonil ', 1, 'fenilpirazol', 5),
(13, 1, 'Piraclostrobina ', 1, 'estrobilurina', 5),
(14, 1, ' Iprodiona ', 1, 'dicarboximida', 5),
(15, 1, 'Acefato ', 1, 'organofosforado', 7);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ubicacion`
--

CREATE TABLE `ubicacion` (
  `ubid` bigint(11) NOT NULL,
  `nomubi` varchar(45) DEFAULT NULL,
  `depubi` varchar(45) DEFAULT NULL,
  `estubi` varchar(45) DEFAULT NULL,
  `cddubi` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `ubicacion`
--

INSERT INTO `ubicacion` (`ubid`, `nomubi`, `depubi`, `estubi`, `cddubi`) VALUES
(5, 'ANTIOQUIA', '0', '1', '0'),
(8, 'ATLANTICO', '0', '1', '0'),
(11, 'BOGOTÁ D.C.', '0', '1', '0'),
(13, 'BOLIVAR', '0', '1', '0'),
(15, 'BOYACA', '0', '1', '0'),
(17, 'CALDAS', '0', '1', '0'),
(18, 'CAQUETA', '0', '1', '0'),
(19, 'CAUCA', '0', '1', '0'),
(20, 'CESAR', '0', '1', '0'),
(23, 'CORDOBA', '0', '1', '0'),
(25, 'CUNDINAMARCA', '0', '1', '0'),
(27, 'CHOCO', '0', '1', '0'),
(41, 'HUILA', '0', '1', '0'),
(44, 'LA GUAJIRA', '0', '1', '0'),
(47, 'MAGDALENA', '0', '1', '0'),
(50, 'META', '0', '1', '0'),
(52, 'NARIÑO', '0', '1', '0'),
(54, 'NORTE DE SANTANDER', '0', '1', '0'),
(63, 'QUINDIO', '0', '1', '0'),
(66, 'RISALDA', '0', '1', '0'),
(68, 'SANTANDER', '0', '1', '0'),
(70, 'SUCRE', '0', '1', '0'),
(73, 'TOLIMA', '0', '1', '0'),
(76, 'VALLE DEL CAUCA', '0', '1', '0'),
(81, 'ARAUCA', '0', '1', '0'),
(85, 'CASANARE', '0', '1', '0'),
(86, 'PUTUMAYO', '0', '1', '0'),
(88, 'SAN ANDRES Y PROVIDE', '0', '1', '0'),
(91, 'AMAZONAS', '0', '1', '0'),
(94, 'GUAINIA', '0', '1', '0'),
(95, 'GUAVIARE', '0', '1', ''),
(97, 'VAUPES', '0', '1', '0'),
(99, 'VICHADA', '0', '1', '0'),
(5001, 'Medellin', '5', '1', '0'),
(5002, 'Abejorral', '5', '1', '0'),
(5004, 'Abriaqui', '5', '1', '0'),
(5021, 'Alejandria', '5', '1', '0'),
(5030, 'Amaga', '5', '1', '0'),
(5031, 'Amalfi', '5', '1', '0'),
(5034, 'Andes', '5', '1', '0'),
(5036, 'Angelopolis', '5', '1', '0'),
(5038, 'Angostura', '5', '1', '0'),
(5040, 'Anori', '5', '1', '0'),
(5042, 'Antioquia', '5', '1', '0'),
(5044, 'Anza', '5', '1', '0'),
(5045, 'Apartado', '5', '1', '0'),
(5051, 'Arboletes', '5', '1', '0'),
(5055, 'Argelia', '5', '1', '0'),
(5059, 'Armenia', '5', '1', '0'),
(5079, 'Barbosa', '5', '1', '0'),
(5086, 'Belmira', '5', '1', '0'),
(5088, 'Bello', '5', '1', '0'),
(5091, 'Betania', '5', '1', '0'),
(5093, 'Betulia', '5', '1', '0'),
(5101, 'Bolivar', '5', '1', '0'),
(5107, 'Briceno', '5', '1', '0'),
(5113, 'Buritica', '5', '1', '0'),
(5120, 'Caceres', '5', '1', '0'),
(5125, 'Caicedo', '5', '1', '0'),
(5129, 'Caldas', '5', '1', '0'),
(5134, 'Campamento', '5', '1', '0'),
(5138, 'CaÃ±asgordas', '5', '1', '0'),
(5142, 'Caracoli', '5', '1', '0'),
(5145, 'Caramanta', '5', '1', '0'),
(5147, 'Carepa', '5', '1', '0'),
(5148, 'Carmen de Viboral', '5', '1', '0'),
(5150, 'Carolina', '5', '1', '0'),
(5154, 'Caucasia', '5', '1', '0'),
(5172, 'Chigorodo', '5', '1', '0'),
(5190, 'Cisneros', '5', '1', '0'),
(5197, 'Cocorna', '5', '1', '0'),
(5206, 'Concepcion', '5', '1', '0'),
(5209, 'Concordia', '5', '1', '0'),
(5212, 'Copacabana', '5', '1', '0'),
(5234, 'Dabeiba', '5', '1', '0'),
(5237, 'Don Matias', '5', '1', '0'),
(5240, 'Ebejico', '5', '1', '0'),
(5250, 'El Bagre', '5', '1', '0'),
(5264, 'Entrerrios', '5', '1', '0'),
(5266, 'Envigado', '5', '1', '0'),
(5282, 'Fredonia', '5', '1', '0'),
(5284, 'Frontino', '5', '1', '0'),
(5306, 'Giraldo', '5', '1', '0'),
(5308, 'Girardota', '5', '1', '0'),
(5310, 'Gomez Plata', '5', '1', '0'),
(5313, 'Granada', '5', '1', '0'),
(5315, 'Guadalupe', '5', '1', '0'),
(5318, 'Guarne', '5', '1', '0'),
(5321, 'Guatape', '5', '1', '0'),
(5347, 'Heliconia', '5', '1', '0'),
(5353, 'Hispania', '5', '1', '0'),
(5360, 'Itagui', '5', '1', '0'),
(5361, 'Ituango', '5', '1', '0'),
(5364, 'Jardin', '5', '1', '0'),
(5368, 'Jerico', '5', '1', '0'),
(5376, 'La Ceja', '5', '1', '0'),
(5380, 'La Estrella', '5', '1', '0'),
(5390, 'La Pintada', '5', '1', '0'),
(5400, 'La Union', '5', '1', '0'),
(5411, 'Liborina', '5', '1', '0'),
(5425, 'Maceo', '5', '1', '0'),
(5440, 'Marinilla', '5', '1', '0'),
(5467, 'Montebello', '5', '1', '0'),
(5475, 'Murindo', '5', '1', '0'),
(5480, 'Mutata', '5', '1', '0'),
(5483, 'NariÃ±o', '5', '1', '0'),
(5490, 'Necocli', '5', '1', '0'),
(5495, 'Nechi', '5', '1', '0'),
(5501, 'Olaya', '5', '1', '0'),
(5541, 'PeÃ±ol', '5', '1', '0'),
(5543, 'Peque', '5', '1', '0'),
(5576, 'Pueblorrico', '5', '1', '0'),
(5579, 'Puerto Berrio', '5', '1', '0'),
(5585, 'Puerto Nare (La Magd', '5', '1', '0'),
(5591, 'Puerto Triunfo', '5', '1', '0'),
(5604, 'Remedios', '5', '1', '0'),
(5607, 'Retiro', '5', '1', '0'),
(5615, 'Rionegro', '5', '1', '0'),
(5628, 'Sabanalarga', '5', '1', '0'),
(5631, 'Sabaneta', '5', '1', '0'),
(5642, 'Salgar', '5', '1', '0'),
(5647, 'San Andres', '5', '1', '0'),
(5649, 'San Carlos', '5', '1', '0'),
(5652, 'San Francisco', '5', '1', '0'),
(5656, 'San Jeronimo', '5', '1', '0'),
(5658, 'San Jose de la Monta', '5', '1', '0'),
(5659, 'San Juan de Uraba', '5', '1', '0'),
(5660, 'San Luis', '5', '1', '0'),
(5664, 'San Pedro', '5', '1', '0'),
(5665, 'San Pedro de Uraba', '5', '1', '0'),
(5667, 'San Rafael', '5', '1', '0'),
(5670, 'San Roque', '5', '1', '0'),
(5674, 'San Vicente', '5', '1', '0'),
(5679, 'Santa Barbara', '5', '1', '0'),
(5686, 'Santa Rosa de Osos', '5', '1', '0'),
(5690, 'Santo Domingo', '5', '1', '0'),
(5697, 'Santuario', '5', '1', '0'),
(5736, 'Segovia', '5', '1', '0'),
(5756, 'Sonson', '5', '1', '0'),
(5761, 'Sopetran', '5', '1', '0'),
(5789, 'Tamesis', '5', '1', '0'),
(5790, 'Taraza', '5', '1', '0'),
(5792, 'Tarso', '5', '1', '0'),
(5809, 'Titiribi', '5', '1', '0'),
(5819, 'Toledo', '5', '1', '0'),
(5837, 'Turbo', '5', '1', '0'),
(5842, 'Uramita', '5', '1', '0'),
(5847, 'Urrao', '5', '1', '0'),
(5854, 'Valdivia', '5', '1', '0'),
(5856, 'Valparaiso', '5', '1', '0'),
(5858, 'Vegachi', '5', '1', '0'),
(5861, 'Venecia', '5', '1', '0'),
(5873, 'Vigia del Fuerte', '5', '1', '0'),
(5885, 'Yali', '5', '1', '0'),
(5887, 'Yarumal', '5', '1', '0'),
(5890, 'Yolombo', '5', '1', '0'),
(5893, 'Yondo (Casabe)', '5', '1', '0'),
(5895, 'Zaragoza', '5', '1', '0'),
(8001, 'Barranquilla', '8', '1', '0'),
(8078, 'Baranoa', '8', '1', '0'),
(8137, 'Campo de la Cruz', '8', '1', '0'),
(8141, 'Candelaria', '8', '1', '0'),
(8296, 'Galapa', '8', '1', '0'),
(8372, 'Juan de Acosta', '8', '1', '0'),
(8421, 'Luruaco', '8', '1', '0'),
(8433, 'Malambo', '8', '1', '0'),
(8436, 'Manati', '8', '1', '0'),
(8520, 'Palmar de Varela', '8', '1', '0'),
(8549, 'Piojo', '8', '1', '0'),
(8558, 'Polo Nuevo', '8', '1', '0'),
(8560, 'Ponedera', '8', '1', '0'),
(8573, 'Puerto Colombia', '8', '1', '0'),
(8606, 'Repelon', '8', '1', '0'),
(8634, 'Sabanagrande', '8', '1', '0'),
(8638, 'Sabanalarga', '8', '1', '0'),
(8675, 'Santa Lucia', '8', '1', '0'),
(8685, 'Santo Tomas', '8', '1', '0'),
(8758, 'Soledad', '8', '1', '0'),
(8770, 'Suan', '8', '1', '0'),
(8832, 'Tubara', '8', '1', '0'),
(8849, 'Usiacuri', '8', '1', '0'),
(11001, 'Bogota', '11', '1', '0'),
(13001, 'Cartagena', '13', '1', '0'),
(13006, 'Achi', '13', '1', '0'),
(13030, 'Altos del Rosario', '13', '1', '0'),
(13042, 'Arenal', '13', '1', '0'),
(13052, 'Arjona', '13', '1', '0'),
(13062, 'Arroyohondo', '13', '1', '0'),
(13074, 'Barranco de Loba', '13', '1', '0'),
(13140, 'Calamar', '13', '1', '0'),
(13160, 'Cantagallo', '13', '1', '0'),
(13188, 'Cicuco', '13', '1', '0'),
(13212, 'Cordoba', '13', '1', '0'),
(13222, 'Clemencia', '13', '1', '0'),
(13244, 'El Carmen de Bolivar', '13', '1', '0'),
(13248, 'El Guamo', '13', '1', '0'),
(13268, 'El PeÃ±on', '13', '1', '0'),
(13300, 'Hatillo de Loba', '13', '1', '0'),
(13430, 'Magangue', '13', '1', '0'),
(13433, 'Mahates', '13', '1', '0'),
(13440, 'Margarita', '13', '1', '0'),
(13442, 'Maria La Baja', '13', '1', '0'),
(13458, 'Montecristo', '13', '1', '0'),
(13468, 'Mompos', '13', '1', '0'),
(13473, 'Morales', '13', '1', '0'),
(13490, 'Norosi', '13', '1', ''),
(13549, 'Pinillos', '13', '1', '0'),
(13580, 'Regidor', '13', '1', '0'),
(13600, 'Rio Viejo', '13', '1', '0'),
(13620, 'San Cristobal', '13', '1', '0'),
(13647, 'San Estanislao', '13', '1', '0'),
(13650, 'San Fernando', '13', '1', '0'),
(13654, 'San Jacinto', '13', '1', '0'),
(13655, 'San Jacinto del Cauca', '13', '1', '0'),
(13657, 'San Juan Nepomuceno', '13', '1', '0'),
(13667, 'San Martin de Loba', '13', '1', '0'),
(13670, 'San Pablo', '13', '1', '0'),
(13673, 'Santa Catalina', '13', '1', '0'),
(13683, 'Santa Rosa', '13', '1', '0'),
(13688, 'Santa Rosa del Sur', '13', '1', '0'),
(13744, 'Simiti', '13', '1', '0'),
(13760, 'Soplaviento', '13', '1', '0'),
(13780, 'Talaigua NUevo', '13', '1', '0'),
(13810, 'Tiquisio (Puerto Ric', '13', '1', '0'),
(13836, 'Turbaco', '13', '1', '0'),
(13838, 'Turbana', '13', '1', '0'),
(13873, 'Villanueva', '13', '1', '0'),
(13894, 'Zambrano', '13', '1', '0'),
(14001, 'Cartagena', '14', '1', '0'),
(15001, 'Tunja', '15', '1', '0'),
(15022, 'Almeida', '15', '1', '0'),
(15047, 'Aquitania', '15', '1', '0'),
(15051, 'Arcabuco', '15', '1', '0'),
(15087, 'Belen', '15', '1', '0'),
(15090, 'Berbeo', '15', '1', '0'),
(15092, 'Beteitiva', '15', '1', '0'),
(15097, 'Boavita', '15', '1', '0'),
(15104, 'Boyaca', '15', '1', '0'),
(15106, 'Briceno', '15', '1', '0'),
(15109, 'Buenavista', '15', '1', '0'),
(15114, 'Busbanza', '15', '1', '0'),
(15131, 'Caldas', '15', '1', '0'),
(15135, 'Campohermoso', '15', '1', '0'),
(15162, 'Cerinza', '15', '1', '0'),
(15172, 'Chinavita', '15', '1', '0'),
(15176, 'Chiquinquira', '15', '1', '0'),
(15180, 'Chiscas', '15', '1', '0'),
(15183, 'Chita', '15', '1', '0'),
(15185, 'Chitaraque', '15', '1', '0'),
(15187, 'Chivata', '15', '1', '0'),
(15189, 'Cienega', '15', '1', '0'),
(15204, 'Combita', '15', '1', '0'),
(15212, 'Coper', '15', '1', '0'),
(15215, 'Corrales', '15', '1', '0'),
(15218, 'Covarachia', '15', '1', '0'),
(15223, 'Cubara', '15', '1', '0'),
(15224, 'Cucaita', '15', '1', '0'),
(15226, 'Cuitiva', '15', '1', '0'),
(15232, 'Chiquiza', '15', '1', '0'),
(15236, 'Chivor', '15', '1', '0'),
(15238, 'Duitama', '15', '1', '0'),
(15244, 'El Cocuy', '15', '1', '0'),
(15248, 'El Espino', '15', '1', '0'),
(15272, 'Firavitoba', '15', '1', '0'),
(15276, 'Floresta', '15', '1', '0'),
(15293, 'Gachantiva', '15', '1', '0'),
(15296, 'Gameza', '15', '1', '0'),
(15299, 'Garagoa', '15', '1', '0'),
(15317, 'Guacamayas', '15', '1', '0'),
(15322, 'Guateque', '15', '1', '0'),
(15325, 'Guayata', '15', '1', '0'),
(15332, 'Guican', '15', '1', '0'),
(15362, 'Iza', '15', '1', '0'),
(15367, 'Jenesano', '15', '1', '0'),
(15368, 'Jerico', '15', '1', '0'),
(15377, 'Labranzagrande', '15', '1', '0'),
(15380, 'La Capilla', '15', '1', '0'),
(15401, 'La Victoria', '15', '1', '0'),
(15403, 'La Uvita', '15', '1', '0'),
(15407, 'VIlla de Leyva', '15', '1', '0'),
(15425, 'Macanal', '15', '1', '0'),
(15442, 'Maripi', '15', '1', '0'),
(15455, 'Miraflores', '15', '1', '0'),
(15464, 'Mongua', '15', '1', '0'),
(15466, 'Mongui', '15', '1', '0'),
(15469, 'Moniquira', '15', '1', '0'),
(15476, 'Motavita', '15', '1', '0'),
(15480, 'Muzo', '15', '1', '0'),
(15491, 'Nobsa', '15', '1', '0'),
(15494, 'Nuevo Colon', '15', '1', '0'),
(15500, 'Oicata', '15', '1', '0'),
(15507, 'Otanche', '15', '1', '0'),
(15511, 'Pachavita', '15', '1', '0'),
(15514, 'Paez', '15', '1', '0'),
(15516, 'Paipa', '15', '1', '0'),
(15518, 'Pajarito', '15', '1', '0'),
(15522, 'Panqueba', '15', '1', '0'),
(15531, 'Pauna', '15', '1', '0'),
(15533, 'Paya', '15', '1', '0'),
(15537, 'Paz de Rio', '15', '1', '0'),
(15542, 'Pesca', '15', '1', '0'),
(15550, 'Pisba', '15', '1', '0'),
(15572, 'Puerto Boyaca', '15', '1', '0'),
(15580, 'Quipama', '15', '1', '0'),
(15599, 'Ramiriqui', '15', '1', '0'),
(15600, 'Raquira', '15', '1', '0'),
(15621, 'Rondon', '15', '1', '0'),
(15632, 'Saboya', '15', '1', '0'),
(15638, 'Sachica', '15', '1', '0'),
(15646, 'Samaca', '15', '1', '0'),
(15660, 'San Eduardo', '15', '1', '0'),
(15664, 'San Jose de Pare', '15', '1', '0'),
(15667, 'San Luis de Gaceno', '15', '1', '0'),
(15673, 'San Mateo', '15', '1', '0'),
(15676, 'San Miguel de Sema', '15', '1', '0'),
(15681, 'San Pablo de Borbur', '15', '1', '0'),
(15686, 'Santana', '15', '1', '0'),
(15690, 'Santa Maria', '15', '1', '0'),
(15693, 'Santa Rosa de Viterb', '15', '1', '0'),
(15696, 'Santa Sofia', '15', '1', '0'),
(15720, 'Sativanorte', '15', '1', '0'),
(15723, 'Sativasur', '15', '1', '0'),
(15740, 'Siachoque', '15', '1', '0'),
(15753, 'Soata', '15', '1', '0'),
(15755, 'Socota', '15', '1', '0'),
(15757, 'Socha', '15', '1', '0'),
(15759, 'Sogamoso', '15', '1', '0'),
(15761, 'Somondoco', '15', '1', '0'),
(15762, 'Sora', '15', '1', '0'),
(15763, 'Sotaquira', '15', '1', '0'),
(15764, 'Soraca', '15', '1', '0'),
(15774, 'Susacon', '15', '1', '0'),
(15776, 'Sutamarchan', '15', '1', '0'),
(15778, 'Sutatenza', '15', '1', '0'),
(15790, 'Tasco', '15', '1', '0'),
(15798, 'Tenza', '15', '1', '0'),
(15804, 'Tibana', '15', '1', '0'),
(15806, 'Tibasosa', '15', '1', '0'),
(15808, 'Tinjaca', '15', '1', '0'),
(15810, 'Tipacoque', '15', '1', '0'),
(15814, 'Toca', '15', '1', '0'),
(15816, 'Togui', '15', '1', '0'),
(15820, 'Topaga', '15', '1', '0'),
(15822, 'Tota', '15', '1', '0'),
(15832, 'Tunungua', '15', '1', '0'),
(15835, 'Turmeque', '15', '1', '0'),
(15837, 'Tuta', '15', '1', '0'),
(15839, 'Tutaza', '15', '1', '0'),
(15842, 'Umbita', '15', '1', '0'),
(15861, 'Ventaquemada', '15', '1', '0'),
(15879, 'Viracacha', '15', '1', '0'),
(15897, 'Zetaquira', '15', '1', '0'),
(17001, 'Manizales', '17', '1', '0'),
(17013, 'Aguadas', '17', '1', '0'),
(17042, 'Anserma', '17', '1', '0'),
(17050, 'Aranzazu', '17', '1', '0'),
(17088, 'Belalcazar', '17', '1', '0'),
(17174, 'Chinchina', '17', '1', '0'),
(17272, 'Filadelfia', '17', '1', '0'),
(17380, 'La Dorada', '17', '1', '0'),
(17388, 'La Merced', '17', '1', '0'),
(17433, 'Manzanares', '17', '1', '0'),
(17442, 'Marmato', '17', '1', '0'),
(17444, 'Marquetalia', '17', '1', '0'),
(17446, 'Marulanda', '17', '1', '0'),
(17486, 'Neira', '17', '1', '0'),
(17495, 'Norcasia', '17', '1', '0'),
(17513, 'Pacora', '17', '1', '0'),
(17524, 'Palestina', '17', '1', '0'),
(17541, 'Pensilvania', '17', '1', '0'),
(17614, 'Riosucio', '17', '1', '0'),
(17616, 'Risaralda', '17', '1', '0'),
(17653, 'Salamina', '17', '1', '0'),
(17662, 'Samana', '17', '1', '0'),
(17665, 'San Jose', '17', '1', '0'),
(17777, 'Supia', '17', '1', '0'),
(17867, 'Victoria', '17', '1', '0'),
(17873, 'Villamaria', '17', '1', '0'),
(17877, 'Viterbo', '17', '1', '0'),
(18001, 'Florencia', '18', '1', '0'),
(18029, 'Albania', '18', '1', '0'),
(18094, 'Belen de los Andaqui', '18', '1', '0'),
(18150, 'Cartagena del Chaira', '18', '1', '0'),
(18205, 'Curillo', '18', '1', '0'),
(18247, 'El Doncello', '18', '1', '0'),
(18256, 'El Paujil', '18', '1', '0'),
(18410, 'La Montanita', '18', '1', '0'),
(18460, 'Milan', '18', '1', '0'),
(18479, 'Morelia', '18', '1', '0'),
(18592, 'Puerto Rico', '18', '1', '0'),
(18610, 'San Jose del Fragua', '18', '1', '0'),
(18753, 'San Vicente del Cagu', '18', '1', '0'),
(18756, 'Solano', '18', '1', '0'),
(18785, 'Solita', '18', '1', '0'),
(18860, 'Valparaiso', '18', '1', '0'),
(19001, 'Popayan', '19', '1', '0'),
(19022, 'Almaguer', '19', '1', '0'),
(19050, 'Argelia', '19', '1', '0'),
(19075, 'Balboa', '19', '1', '0'),
(19100, 'Bolivar', '19', '1', '0'),
(19110, 'Buenos Aires', '19', '1', '0'),
(19130, 'Cajibio', '19', '1', '0'),
(19137, 'Caldono', '19', '1', '0'),
(19142, 'Caloto', '19', '1', '0'),
(19212, 'Corinto', '19', '1', '0'),
(19256, 'El Tambo', '19', '1', '0'),
(19290, 'Florencia', '19', '1', '0'),
(19318, 'Guapi', '19', '1', '0'),
(19355, 'Inza', '19', '1', '0'),
(19364, 'Jambalo', '19', '1', '0'),
(19392, 'La Sierra', '19', '1', '0'),
(19397, 'La Vega', '19', '1', '0'),
(19418, 'Lopez (Micay)', '19', '1', '0'),
(19450, 'Mercaderes', '19', '1', '0'),
(19455, 'Miranda', '19', '1', '0'),
(19473, 'Morales', '19', '1', '0'),
(19513, 'Padilla', '19', '1', '0'),
(19517, 'Paez', '19', '1', '0'),
(19532, 'Patia (EL Bordo)', '19', '1', '0'),
(19533, 'Piamonte', '19', '1', '0'),
(19548, 'Piendamo', '19', '1', '0'),
(19573, 'Puerto Tejada', '19', '1', '0'),
(19585, 'Purace', '19', '1', '0'),
(19622, 'Rosas', '19', '1', '0'),
(19693, 'San Sebastian', '19', '1', '0'),
(19698, 'Santander de Quilich', '19', '1', '0'),
(19701, 'Santa Rosa', '19', '1', '0'),
(19743, 'Silvia', '19', '1', '0'),
(19760, 'Sotara', '19', '1', '0'),
(19780, 'Suarez', '19', '1', '0'),
(19785, 'Sucre', '19', '1', '0'),
(19807, 'Timbio', '19', '1', '0'),
(19809, 'Timbiqui', '19', '1', '0'),
(19821, 'Toribio', '19', '1', '0'),
(19824, 'ToToro', '19', '1', '0'),
(19845, 'Villarica', '19', '1', '0'),
(20001, 'Valledupar', '20', '1', '0'),
(20011, 'Aguachica', '20', '1', '0'),
(20013, 'Agustin Codazzi', '20', '1', '0'),
(20032, 'Astrea', '20', '1', '0'),
(20045, 'Becerril', '20', '1', '0'),
(20060, 'Bosconia', '20', '1', '0'),
(20175, 'Chimichagua', '20', '1', '0'),
(20178, 'Chiriguana', '20', '1', '0'),
(20228, 'Curumani', '20', '1', '0'),
(20238, 'El Copey', '20', '1', '0'),
(20250, 'El Paso', '20', '1', '0'),
(20295, 'Gamarra', '20', '1', '0'),
(20310, 'Gonzalez', '20', '1', '0'),
(20383, 'La Gloria', '20', '1', '0'),
(20400, 'La Jagua de Ibirico', '20', '1', '0'),
(20443, 'Manaure Balcon del C', '20', '1', '0'),
(20517, 'Pailitas', '20', '1', '0'),
(20550, 'Pelaya', '20', '1', '0'),
(20570, 'Pueblo Bello', '20', '1', '0'),
(20614, 'Rio de Oro', '20', '1', '0'),
(20621, 'Robles (La Paz)', '20', '1', '0'),
(20710, 'San Alberto', '20', '1', '0'),
(20750, 'San Diego', '20', '1', '0'),
(20770, 'San Martin', '20', '1', '0'),
(20787, 'Tamalameque', '20', '1', '0'),
(23001, 'Monteria', '23', '1', '0'),
(23068, 'Ayapel', '23', '1', '0'),
(23079, 'Buenavista', '23', '1', '0'),
(23090, 'Canalete', '23', '1', '0'),
(23162, 'Cerete', '23', '1', '0'),
(23168, 'Chima', '23', '1', '0'),
(23182, 'Chinu', '23', '1', '0'),
(23189, 'Cienaga de Oro', '23', '1', '0'),
(23300, 'Cotorra', '23', '1', '0'),
(23350, 'La Apartada', '23', '1', '0'),
(23417, 'Lorica', '23', '1', '0'),
(23419, 'Los Cordobas', '23', '1', '0'),
(23464, 'Momil', '23', '1', '0'),
(23466, 'Montelibano', '23', '1', '0'),
(23500, 'MoÃ±itos', '23', '1', '0'),
(23555, 'Planeta Rica', '23', '1', '0'),
(23570, 'Pueblo Nuevo', '23', '1', '0'),
(23574, 'Puerto Escondido', '23', '1', '0'),
(23580, 'Puerto Libertador', '23', '1', '0'),
(23586, 'Purisima', '23', '1', '0'),
(23660, 'Sahagun', '23', '1', '0'),
(23670, 'San Andres Sotavento', '23', '1', '0'),
(23672, 'San Antero', '23', '1', '0'),
(23675, 'San Bernardo del Vie', '23', '1', '0'),
(23678, 'San Carlos', '23', '1', '0'),
(23686, 'San Pelayo', '23', '1', '0'),
(23807, 'Tierralta', '23', '1', '0'),
(23855, 'Valencia', '23', '1', '0'),
(25001, 'Agua de Dios', '25', '1', '0'),
(25019, 'Alban', '25', '1', '0'),
(25035, 'Anapoima', '25', '1', '0'),
(25040, 'Anolaima', '25', '1', '0'),
(25053, 'Arbelaez', '25', '1', '0'),
(25086, 'Beltran', '25', '1', '0'),
(25095, 'Bituima', '25', '1', '0'),
(25099, 'Bojaca', '25', '1', '0'),
(25120, 'Cabrera', '25', '1', '0'),
(25123, 'Cachipay', '25', '1', '0'),
(25126, 'CajicÃ¡', '25', '1', '0'),
(25148, 'Caparrapi', '25', '1', '0'),
(25151, 'Caqueza', '25', '1', '0'),
(25154, 'Carmen de Carupa', '25', '1', '0'),
(25168, 'Chaguani', '25', '1', '0'),
(25175, 'Chí­a', '25', '1', '0'),
(25178, 'Chipaque', '25', '1', '0'),
(25181, 'Choachi', '25', '1', '0'),
(25183, 'Choconta', '25', '1', '0'),
(25200, 'Cogua', '25', '1', '0'),
(25214, 'Cota', '25', '1', '0'),
(25224, 'Cucunuba', '25', '1', '0'),
(25245, 'El Colegio', '25', '1', '0'),
(25258, 'El PeÃ±on', '25', '1', '0'),
(25260, 'El Rosal', '25', '1', '0'),
(25269, 'Facatativa', '25', '1', '0'),
(25279, 'Fomeque', '25', '1', '0'),
(25281, 'Fosca', '25', '1', '0'),
(25286, 'Funza', '25', '1', '0'),
(25288, 'Fuquene', '25', '1', '0'),
(25290, 'Fusagasuga', '25', '1', '0'),
(25293, 'Gachala', '25', '1', '0'),
(25295, 'Gachancipa', '25', '1', '0'),
(25297, 'Gacheta', '25', '1', '0'),
(25299, 'Gama', '25', '1', '0'),
(25307, 'Girardot', '25', '1', '0'),
(25312, 'Granada', '25', '1', '0'),
(25317, 'Guacheta', '25', '1', '0'),
(25320, 'Guaduas', '25', '1', '0'),
(25322, 'Guasca', '25', '1', '0'),
(25324, 'Guataqui', '25', '1', '0'),
(25326, 'Guatavita', '25', '1', '0'),
(25328, 'Guayabal de Siquima', '25', '1', '0'),
(25335, 'Guayabetal', '25', '1', '0'),
(25339, 'Gutierrez', '25', '1', '0'),
(25368, 'Jerusalen', '25', '1', '0'),
(25372, 'Junin', '25', '1', '0'),
(25377, 'La Calera', '25', '1', '0'),
(25386, 'La Mesa', '25', '1', '0'),
(25394, 'La Palma', '25', '1', '0'),
(25398, 'La PeÃ±a', '25', '1', '0'),
(25402, 'La Vega', '25', '1', '0'),
(25407, 'Lenguazaque', '25', '1', '0'),
(25426, 'Macheta', '25', '1', '0'),
(25430, 'Madrid', '25', '1', '0'),
(25436, 'Manta', '25', '1', '0'),
(25438, 'Medina', '25', '1', '0'),
(25473, 'Mosquera', '25', '1', '0'),
(25483, 'NariÃ±o', '25', '1', '0'),
(25486, 'Nemocon', '25', '1', '0'),
(25488, 'Nilo', '25', '1', '0'),
(25489, 'Nimaima', '25', '1', '0'),
(25491, 'Nocaima', '25', '1', '0'),
(25506, 'Venecia', '25', '1', '0'),
(25513, 'Pacho', '25', '1', '0'),
(25518, 'Paime', '25', '1', '0'),
(25524, 'Pandi', '25', '1', '0'),
(25530, 'Paratebueno', '25', '1', '0'),
(25535, 'Pasca', '25', '1', '0'),
(25572, 'Puerto Salgar', '25', '1', '0'),
(25580, 'Puli', '25', '1', '0'),
(25592, 'Quebradanegra', '25', '1', '0'),
(25594, 'Quetame', '25', '1', '0'),
(25596, 'Quipile', '25', '1', '0'),
(25599, 'Apulo', '25', '1', '0'),
(25612, 'Ricaurte', '25', '1', '0'),
(25645, 'San Antonio del Tequendama', '25', '1', '0'),
(25649, 'San Bernardo', '25', '1', '0'),
(25653, 'San Cayetano', '25', '1', '0'),
(25658, 'San Francisco', '25', '1', '0'),
(25662, 'San Juan de Rio Seco', '25', '1', '0'),
(25718, 'Sasaima', '25', '1', '0'),
(25736, 'Sesquile', '25', '1', '0'),
(25740, 'Sibate', '25', '1', '0'),
(25743, 'Silvania', '25', '1', '0'),
(25745, 'Simijaca', '25', '1', '0'),
(25754, 'Soacha', '25', '1', '0'),
(25758, 'Sopo', '25', '1', '0'),
(25769, 'Subachoque', '25', '1', '0'),
(25772, 'Suesca', '25', '1', '0'),
(25777, 'Supata', '25', '1', '0'),
(25779, 'Susa', '25', '1', '0'),
(25781, 'Sutatausa', '25', '1', '0'),
(25785, 'Tabio', '25', '1', '0'),
(25793, 'Tausa', '25', '1', '0'),
(25797, 'Tena', '25', '1', '0'),
(25799, 'Tenjo', '25', '1', '0'),
(25805, 'Tibacuy', '25', '1', '0'),
(25807, 'Tibirita', '25', '1', '0'),
(25815, 'Tocaima', '25', '1', '0'),
(25817, 'TocancipÃ¡', '25', '1', '0'),
(25823, 'Topaipi', '25', '1', '0'),
(25839, 'Ubala', '25', '1', '0'),
(25841, 'Ubaque', '25', '1', '0'),
(25843, 'Villa de San Diego de Ubate', '25', '1', '0'),
(25845, 'Une', '25', '1', '0'),
(25851, 'Utica', '25', '1', '0'),
(25862, 'Vergara', '25', '1', '0'),
(25867, 'Viani', '25', '1', '0'),
(25871, 'Villagomez', '25', '1', '0'),
(25873, 'Villapinzon', '25', '1', '0'),
(25875, 'Villeta', '25', '1', '0'),
(25878, 'Viota', '25', '1', '0'),
(25885, 'Yacopi', '25', '1', '0'),
(25898, 'Zipacon', '25', '1', '0'),
(25899, 'Zipaquirá', '25', '1', '0'),
(27001, 'Quibdo', '27', '1', '0'),
(27006, 'Acandi', '27', '1', '0'),
(27025, 'Alto Baudo (Pie de P', '27', '1', '0'),
(27050, 'Atrato', '27', '1', '0'),
(27073, 'Bagado', '27', '1', '0'),
(27075, 'Bahia Solano (Mutis)', '27', '1', '0'),
(27077, 'Bajo Baudo (Pizarro)', '27', '1', '0'),
(27099, 'Bojaya (Bellavista)', '27', '1', '0'),
(27135, 'El Canton del San Pablo ', '27', '1', '0'),
(27150, 'Carmen del Darien', '27', '1', '0'),
(27160, 'Certegui', '27', '1', '0'),
(27205, 'Condoto', '27', '1', '0'),
(27245, 'El Carmen de Atrato', '27', '1', '0'),
(27250, 'Litoral del Bajo San', '27', '1', '0'),
(27361, 'Itsmina', '27', '1', '0'),
(27372, 'Jurado', '27', '1', '0'),
(27413, 'Lloro', '27', '1', '0'),
(27425, 'Medio Atrato', '27', '1', '0'),
(27430, 'Medio Baudo (Boca de', '27', '1', '0'),
(27450, 'Medio San Juan', '27', '1', '0'),
(27491, 'Novita', '27', '1', '0'),
(27495, 'Nuqui', '27', '1', '0'),
(27580, 'Rio Iro', '27', '1', '0'),
(27600, 'Rioquito', '27', '1', '0'),
(27615, 'Riosucio', '27', '1', '0'),
(27660, 'San Jose del Palmar', '27', '1', '0'),
(27745, 'Sipi', '27', '1', '0'),
(27787, 'Tado', '27', '1', '0'),
(27800, 'Unguia', '27', '1', '0'),
(27810, 'Union Panamericana', '27', '1', '0'),
(41001, 'Neiva', '41', '1', '0'),
(41006, 'Acevedo', '41', '1', '0'),
(41013, 'Agrado', '41', '1', '0'),
(41016, 'Aipe', '41', '1', '0'),
(41020, 'Algeciras', '41', '1', '0'),
(41026, 'Altamira', '41', '1', '0'),
(41078, 'Baraya', '41', '1', '0'),
(41132, 'Campoalegre', '41', '1', '0'),
(41206, 'Colombia', '41', '1', '0'),
(41244, 'Elias', '41', '1', '0'),
(41298, 'Garzon', '41', '1', '0'),
(41306, 'Gigante', '41', '1', '0'),
(41319, 'Guadalupe', '41', '1', '0'),
(41349, 'Hobo', '41', '1', '0'),
(41357, 'Iquira', '41', '1', '0'),
(41359, 'Isnos (San Jose de I', '41', '1', '0'),
(41378, 'La Argentina', '41', '1', '0'),
(41396, 'La Plata', '41', '1', '0'),
(41483, 'Nataga', '41', '1', '0'),
(41503, 'Oporapa', '41', '1', '0'),
(41518, 'Paicol', '41', '1', '0'),
(41524, 'Palermo', '41', '1', '0'),
(41530, 'Palestina', '41', '1', '0'),
(41548, 'Pital', '41', '1', '0'),
(41551, 'Pitalito', '41', '1', '0'),
(41615, 'Rivera', '41', '1', '0'),
(41660, 'Saladoblanco', '41', '1', '0'),
(41668, 'San Agustin', '41', '1', '0'),
(41676, 'Santa Maria', '41', '1', '0'),
(41770, 'Suaza', '41', '1', '0'),
(41791, 'Tarqui', '41', '1', '0'),
(41797, 'Tesalia', '41', '1', '0'),
(41799, 'Tello', '41', '1', '0'),
(41801, 'Teruel', '41', '1', '0'),
(41807, 'Timana', '41', '1', '0'),
(41872, 'Villavieja', '41', '1', '0'),
(41885, 'Yaguara', '41', '1', '0'),
(44001, 'Riohacha', '44', '1', '0'),
(44035, 'Albania', '44', '1', '0'),
(44078, 'Barrancas', '44', '1', '0'),
(44090, 'Dibulla', '44', '1', '0'),
(44098, 'Distraccion', '44', '1', '0'),
(44110, 'El Molino', '44', '1', '0'),
(44279, 'Fonseca', '44', '1', '0'),
(44378, 'Hatonuevo', '44', '1', '0'),
(44420, 'La Jagua del Pilar', '44', '1', '0'),
(44430, 'Maicao', '44', '1', '0'),
(44560, 'Manaure', '44', '1', '0'),
(44650, 'San Juan del Cesar', '44', '1', '0'),
(44847, 'Uribia', '44', '1', '0'),
(44855, 'Urumita', '44', '1', '0'),
(44874, 'Villanueva', '44', '1', '0'),
(47001, 'Santa Marta', '47', '1', '0'),
(47030, 'Algarrobo', '47', '1', '0'),
(47053, 'Aracataca', '47', '1', '0'),
(47058, 'Ariguani (El Dificil', '47', '1', '0'),
(47161, 'Cerro San Antonio', '47', '1', '0'),
(47170, 'Chivolo', '47', '1', '0'),
(47189, 'Cienaga', '47', '1', '0'),
(47205, 'Concordia', '47', '1', '0'),
(47245, 'El Banco', '47', '1', '0'),
(47258, 'El PiÃ±on', '47', '1', '0'),
(47268, 'El Reten', '47', '1', '0'),
(47288, 'Fundacion', '47', '1', '0'),
(47318, 'Guamal', '47', '1', '0'),
(47460, 'Nueva Granada', '47', '1', '0'),
(47541, 'Pedraza', '47', '1', '0'),
(47545, 'PijiÃ±o del Carmen (P', '47', '1', '0'),
(47551, 'Pivijay', '47', '1', '0'),
(47555, 'Plato', '47', '1', '0'),
(47570, 'Puebloviejo', '47', '1', '0'),
(47605, 'Remolino', '47', '1', '0'),
(47660, 'Sabanas de San Angel', '47', '1', '0'),
(47675, 'Salamina', '47', '1', '0'),
(47692, 'San Sebastian de Bue', '47', '1', '0'),
(47703, 'San Zenon', '47', '1', '0'),
(47707, 'Santa Ana', '47', '1', '0'),
(47720, 'Santa Barbara de Pin', '47', '1', '0'),
(47745, 'Sitio Nuevo', '47', '1', '0'),
(47798, 'Tenerife', '47', '1', '0'),
(47960, 'Zapayan', '47', '1', '0'),
(47980, 'Zona Bananera', '47', '1', '0'),
(47983, 'Bordo', '19', '1', '0'),
(50001, 'Villavicencio', '50', '1', '0'),
(50006, 'Acacias', '50', '1', '0'),
(50110, 'Barranca de Upia', '50', '1', '0'),
(50124, 'Cabuyaro', '50', '1', '0'),
(50150, 'Castilla La Nueva', '50', '1', '0'),
(50223, 'Cubarral', '50', '1', '0'),
(50226, 'Cumaral', '50', '1', '0'),
(50245, 'El Calvario', '50', '1', '0'),
(50251, 'El Castillo', '50', '1', '0'),
(50270, 'El Dorado', '50', '1', '0'),
(50287, 'Fuente de Oro', '50', '1', '0'),
(50313, 'Granada', '50', '1', '0'),
(50318, 'Guamal', '50', '1', '0'),
(50325, 'Mapiripan', '50', '1', '0'),
(50330, 'Mesetas', '50', '1', '0'),
(50350, 'La Macarena', '50', '1', '0'),
(50370, 'La Uribe', '50', '1', '0'),
(50400, 'Lejanias', '50', '1', '0'),
(50450, 'Puerto Concordia', '50', '1', '0'),
(50568, 'Puerto Gaitan', '50', '1', '0'),
(50573, 'Puerto Lopez', '50', '1', '0'),
(50577, 'Puerto Lleras', '50', '1', '0'),
(50590, 'Puerto Rico', '50', '1', '0'),
(50606, 'Restrepo', '50', '1', '0'),
(50680, 'San Carlos de Guaroa', '50', '1', '0'),
(50683, 'San Juan de Arama', '50', '1', '0'),
(50686, 'San Juanito', '50', '1', '0'),
(50689, 'San Martin', '50', '1', '0'),
(50711, 'Vistahermosa', '50', '1', '0'),
(52001, 'Pasto', '52', '1', '0'),
(52019, 'Alban (San Jose)', '52', '1', '0'),
(52022, 'Aldana', '52', '1', '0'),
(52036, 'Ancuya', '52', '1', '0'),
(52051, 'Arboleda (Berruecos)', '52', '1', '0'),
(52079, 'Barbacoas', '52', '1', '0'),
(52083, 'Belen', '52', '1', '0'),
(52110, 'Buesaco', '52', '1', '0'),
(52203, 'Colon (Genova)', '52', '1', '0'),
(52207, 'Consaca', '52', '1', '0'),
(52210, 'Contadero', '52', '1', '0'),
(52215, 'Cordoba', '52', '1', '0'),
(52224, 'Cuaspud (Carlosama)', '52', '1', '0'),
(52227, 'Cumbal', '52', '1', '0'),
(52233, 'Cumbitara', '52', '1', '0'),
(52240, 'Chachagui', '52', '1', '0'),
(52250, 'El Charco', '52', '1', '0'),
(52254, 'El PeÃ±ol', '52', '1', '0'),
(52256, 'El Rosario', '52', '1', '0'),
(52258, 'El Tablon', '52', '1', '0'),
(52260, 'El Tambo', '52', '1', '0'),
(52287, 'Funes', '52', '1', '0'),
(52317, 'Guachucal', '52', '1', '0'),
(52320, 'Guaitarilla', '52', '1', '0'),
(52323, 'Gualmatan', '52', '1', '0'),
(52352, 'Iles', '52', '1', '0'),
(52354, 'Imues', '52', '1', '0'),
(52356, 'Ipiales', '52', '1', '0'),
(52378, 'La Cruz', '52', '1', '0'),
(52381, 'La Florida', '52', '1', '0'),
(52385, 'La Llanada', '52', '1', '0'),
(52390, 'La Tola', '52', '1', '0'),
(52399, 'La Union', '52', '1', '0'),
(52405, 'Leiva', '52', '1', '0'),
(52411, 'Linares', '52', '1', '0'),
(52418, 'Los Andes (Sotomayor', '52', '1', '0'),
(52427, 'Magui (Payan)', '52', '1', '0'),
(52435, 'Mallama (Piedrancha)', '52', '1', '0'),
(52473, 'Mosquera', '52', '1', '0'),
(52480, 'NariÃ±o', '52', '1', '0'),
(52490, 'Olaya Herrera(Bocas ', '52', '1', '0'),
(52506, 'Ospina', '52', '1', '0'),
(52520, 'Francisco Pizarro (S', '52', '1', '0'),
(52540, 'Policarpa', '52', '1', '0'),
(52560, 'Potosi', '52', '1', '0'),
(52565, 'Providencia', '52', '1', '0'),
(52573, 'Puerres', '52', '1', '0'),
(52585, 'Pupiales', '52', '1', '0'),
(52612, 'Ricaurte', '52', '1', '0'),
(52621, 'Roberto Payan (San J', '52', '1', '0'),
(52678, 'Samaniego', '52', '1', '0'),
(52683, 'Sandona', '52', '1', '0'),
(52685, 'San Bernardo', '52', '1', '0'),
(52687, 'San Lorenzo', '52', '1', '0'),
(52693, 'San Pablo', '52', '1', '0'),
(52694, 'San Pedro de Cartago', '52', '1', '0'),
(52696, 'Santa Barbara (Iscua', '52', '1', '0'),
(52699, 'Santa Cruz (Guachave', '52', '1', '0'),
(52720, 'Sapuyes', '52', '1', '0'),
(52786, 'Taminango', '52', '1', '0'),
(52788, 'Tangua', '52', '1', '0'),
(52835, 'Tumaco', '52', '1', '0'),
(52838, 'Tuquerres', '52', '1', '0'),
(52885, 'Yacuanquer', '52', '1', '0'),
(54001, 'Cucuta', '54', '1', '0'),
(54003, 'Abrego', '54', '1', '0'),
(54051, 'Arboledas', '54', '1', '0'),
(54099, 'Bochalema', '54', '1', '0'),
(54109, 'Bucarasica', '54', '1', '0'),
(54125, 'Cacota', '54', '1', '0'),
(54128, 'Cachira', '54', '1', '0'),
(54172, 'Chinacota', '54', '1', ''),
(54174, 'Chitaga', '54', '1', '0'),
(54206, 'Convencion', '54', '1', '0'),
(54223, 'Cucutilla', '54', '1', '0'),
(54239, 'Durania', '54', '1', '0'),
(54245, 'El Carmen', '54', '1', '0'),
(54250, 'El Tarra', '54', '1', '0'),
(54261, 'El Zulia', '54', '1', '0'),
(54313, 'Gramalote', '54', '1', '0'),
(54344, 'Hacari', '54', '1', '0'),
(54347, 'Herran', '54', '1', '0'),
(54377, 'Labateca', '54', '1', '0'),
(54385, 'La Esperanza', '54', '1', '0'),
(54398, 'La Playa', '54', '1', '0'),
(54405, 'Los Patios', '54', '1', '0'),
(54418, 'Lourdes', '54', '1', '0'),
(54480, 'Mutiscua', '54', '1', '0'),
(54498, 'OcaÃ±a', '54', '1', '0'),
(54518, 'Pamplona', '54', '1', '0'),
(54520, 'Pamplonita', '54', '1', '0'),
(54553, 'Puerto Santander', '54', '1', '0'),
(54599, 'Ragonvalia', '54', '1', '0'),
(54660, 'Salazar', '54', '1', '0'),
(54670, 'San Calixto', '54', '1', '0'),
(54673, 'San Cayetano', '54', '1', '0'),
(54680, 'Santiago', '54', '1', '0'),
(54720, 'Sardinata', '54', '1', '0'),
(54743, 'Silos', '54', '1', '0'),
(54800, 'Teorama', '54', '1', '0'),
(54810, 'Tibu', '54', '1', '0'),
(54820, 'Toledo', '54', '1', '0'),
(54871, 'Villa Caro', '54', '1', '0'),
(54874, 'Villa del Rosario', '54', '1', '0'),
(63001, 'Armenia', '63', '1', '0'),
(63111, 'Buenavista', '63', '1', '0'),
(63130, 'Calarca', '63', '1', '0'),
(63190, 'Circasia', '63', '1', '0'),
(63212, 'Cordoba', '63', '1', '0'),
(63272, 'Filandia', '63', '1', '0'),
(63302, 'Genova', '63', '1', '0'),
(63401, 'La Tebaida', '63', '1', '0'),
(63470, 'Montenegro', '63', '1', '0'),
(63548, 'Pijao', '63', '1', '0'),
(63594, 'Quimbaya', '63', '1', '0'),
(63690, 'Salento', '63', '1', '0'),
(66001, 'Pereira', '66', '1', '0'),
(66045, 'Apia', '66', '1', '0'),
(66075, 'Balboa', '66', '1', '0'),
(66088, 'Belen de Umbria', '66', '1', '0'),
(66170, 'Dosquebradas', '66', '1', '0'),
(66318, 'Guatica', '66', '1', '0'),
(66383, 'La Celia', '66', '1', '0'),
(66400, 'La Virginia', '66', '1', '0'),
(66440, 'Marsella', '66', '1', '0'),
(66456, 'Mistrato', '66', '1', '0'),
(66572, 'Pueblo Rico', '66', '1', '0'),
(66594, 'Quinchia', '66', '1', '0'),
(66682, 'Santa Rosa de Cabal', '66', '1', '0'),
(66687, 'Santuario', '66', '1', '0'),
(68001, 'Bucaramanga', '68', '1', '0'),
(68013, 'Aguada', '68', '1', '0'),
(68020, 'Albania', '68', '1', '0'),
(68051, 'Aratoca', '68', '1', '0'),
(68077, 'Barbosa', '68', '1', '0'),
(68079, 'Barichara', '68', '1', '0'),
(68081, 'Barrancabermeja', '68', '1', '0'),
(68092, 'Betulia', '68', '1', '0'),
(68101, 'Bolivar', '68', '1', '0'),
(68121, 'Cabrera', '68', '1', '0'),
(68132, 'California', '68', '1', '0'),
(68147, 'Capitanejo', '68', '1', '0'),
(68152, 'Carcasi', '68', '1', '0'),
(68160, 'Cepita', '68', '1', '0'),
(68162, 'Cerrito', '68', '1', '0'),
(68167, 'Charala', '68', '1', '0'),
(68169, 'Charta', '68', '1', '0'),
(68176, 'Chima', '68', '1', '0'),
(68179, 'Chipata', '68', '1', '0'),
(68190, 'Cimitarra', '68', '1', '0'),
(68207, 'Concepcion', '68', '1', '0'),
(68209, 'Confines', '68', '1', '0'),
(68211, 'Contratacion', '68', '1', '0'),
(68217, 'Coromoro', '68', '1', '0'),
(68229, 'Curiti', '68', '1', '0'),
(68235, 'El Carmen de Chucuri', '68', '1', '0'),
(68245, 'El Guacamayo', '68', '1', '0'),
(68250, 'El PeÃ±on', '68', '1', '0'),
(68255, 'El Playon', '68', '1', '0'),
(68264, 'Encino', '68', '1', '0'),
(68266, 'Enciso', '68', '1', '0'),
(68271, 'Florian', '68', '1', '0'),
(68276, 'Floridablanca', '68', '1', '0'),
(68296, 'Galan', '68', '1', '0'),
(68298, 'Gambita', '68', '1', '0'),
(68307, 'Giron', '68', '1', '0'),
(68318, 'Guaca', '68', '1', '0'),
(68320, 'Guadalupe', '68', '1', '0'),
(68322, 'Guapota', '68', '1', '0'),
(68324, 'Guavata', '68', '1', '0'),
(68327, 'Guepsa', '68', '1', '0'),
(68344, 'Hato', '68', '1', '0'),
(68368, 'Jesus Maria', '68', '1', '0'),
(68370, 'Jordan', '68', '1', '0'),
(68377, 'La Belleza', '68', '1', '0'),
(68385, 'Landazuri', '68', '1', '0'),
(68397, 'La Paz', '68', '1', '0'),
(68406, 'Lebrija', '68', '1', '0'),
(68418, 'Los Santos', '68', '1', '0'),
(68425, 'Macaravita', '68', '1', '0'),
(68432, 'Malaga', '68', '1', '0'),
(68444, 'Matanza', '68', '1', '0'),
(68464, 'Mogotes', '68', '1', '0'),
(68468, 'Molagavita', '68', '1', '0'),
(68498, 'Ocamonte', '68', '1', '0'),
(68500, 'Oiba', '68', '1', '0'),
(68502, 'Onzaga', '68', '1', '0'),
(68522, 'Palmar', '68', '1', '0'),
(68524, 'Palmas Socorro', '68', '1', '0'),
(68533, 'Paramo', '68', '1', '0'),
(68547, 'Piedecuesta', '68', '1', '0'),
(68549, 'Pinchote', '68', '1', '0'),
(68572, 'Puente Nacional', '68', '1', '0'),
(68573, 'Puerto Parra', '68', '1', '0'),
(68575, 'Puerto Wilches', '68', '1', '0'),
(68615, 'Rionegro', '68', '1', '0'),
(68655, 'Sabana de Torres', '68', '1', '0'),
(68669, 'San Andres', '68', '1', '0'),
(68673, 'San Benito', '68', '1', '0'),
(68679, 'San Gil', '68', '1', '0'),
(68682, 'San Joaquin', '68', '1', '0'),
(68684, 'San Jose de Miranda', '68', '1', '0'),
(68686, 'San Miguel', '68', '1', '0'),
(68689, 'San Vicente de Chucu', '68', '1', '0'),
(68705, 'Santa Barbara', '68', '1', '0'),
(68720, 'Santa Helena del Opo', '68', '1', '0'),
(68745, 'Simacota', '68', '1', '0'),
(68755, 'Socorro', '68', '1', '0'),
(68770, 'Suaita', '68', '1', '0'),
(68773, 'Sucre', '68', '1', '0'),
(68780, 'Surata', '68', '1', '0'),
(68820, 'Tona', '68', '1', '0'),
(68855, 'Valle de San Jose', '68', '1', '0'),
(68861, 'Velez', '68', '1', '0'),
(68867, 'Vetas', '68', '1', '0'),
(68872, 'Villanueva', '68', '1', '0'),
(68895, 'Zapatoca', '68', '1', '0'),
(70001, 'Sincelejo', '70', '1', '0'),
(70110, 'Buenavista', '70', '1', '0'),
(70124, 'Caimito', '70', '1', '0'),
(70204, 'Coloso (Ricaurte)', '70', '1', '0'),
(70215, 'Corozal', '70', '1', '0'),
(70221, 'CoveÃ±as', '70', '1', '0'),
(70230, 'Chalan', '70', '1', '0'),
(70233, 'El Roble', '70', '1', '0'),
(70235, 'Galeras (Nueva Grana', '70', '1', '0'),
(70265, 'Guaranda', '70', '1', '0'),
(70400, 'La Union', '70', '1', '0'),
(70418, 'Los Palmitos', '70', '1', '0'),
(70429, 'Majagual', '70', '1', '0'),
(70473, 'Morroa', '70', '1', '0'),
(70508, 'Ovejas', '70', '1', '0'),
(70523, 'Palmito', '70', '1', '0'),
(70670, 'Sampues', '70', '1', '0'),
(70678, 'San Benito Abad', '70', '1', '0'),
(70702, 'San Juan de Betulia', '70', '1', '0'),
(70708, 'San Marcos', '70', '1', '0'),
(70713, 'San Onofre', '70', '1', '0'),
(70717, 'San Pedro', '70', '1', '0'),
(70742, 'Since', '70', '1', '0'),
(70771, 'Sucre', '70', '1', '0'),
(70820, 'Tolu', '70', '1', '0'),
(70823, 'Toluviejo', '70', '1', '0'),
(73001, 'Ibague', '73', '1', '0'),
(73024, 'Alpujarra', '73', '1', '0'),
(73026, 'Alvarado', '73', '1', '0'),
(73030, 'Ambalema', '73', '1', '0'),
(73043, 'Anzoategui', '73', '1', '0'),
(73055, 'Armero (Guayabal)', '73', '1', '0'),
(73067, 'Ataco', '73', '1', '0'),
(73124, 'Cajamarca', '73', '1', '0'),
(73148, 'Carmen de Apicala', '73', '1', '0'),
(73152, 'Casabianca', '73', '1', '0'),
(73168, 'Chaparral', '73', '1', '0'),
(73200, 'Coello', '73', '1', '0'),
(73217, 'Coyaima', '73', '1', '0'),
(73226, 'Cunday', '73', '1', '0'),
(73236, 'Dolores', '73', '1', '0'),
(73268, 'Espinal', '73', '1', '0'),
(73270, 'Falan', '73', '1', '0'),
(73275, 'Flandes', '73', '1', '0'),
(73283, 'Fresno', '73', '1', '0'),
(73319, 'Guamo', '73', '1', '0'),
(73347, 'Herveo', '73', '1', '0'),
(73349, 'Honda', '73', '1', '0'),
(73352, 'Icononzo', '73', '1', '0'),
(73408, 'Lerida', '73', '1', '0'),
(73411, 'Libano', '73', '1', '0'),
(73443, 'Mariquita', '73', '1', '0'),
(73449, 'Melgar', '73', '1', '0'),
(73461, 'Murillo', '73', '1', '0'),
(73483, 'Natagaima', '73', '1', '0'),
(73504, 'Ortega', '73', '1', '0'),
(73520, 'Palocabildo', '73', '1', '0'),
(73547, 'Piedras', '73', '1', '0'),
(73555, 'Planadas', '73', '1', '0'),
(73563, 'Prado', '73', '1', '0'),
(73585, 'Purificacion', '73', '1', '0'),
(73616, 'Rioblanco', '73', '1', '0'),
(73622, 'Roncesvalles', '73', '1', '0'),
(73624, 'Rovira', '73', '1', '0'),
(73671, 'SaldaÃ±a', '73', '1', '0'),
(73675, 'San Antonio', '73', '1', '0'),
(73678, 'San Luis', '73', '1', '0'),
(73686, 'Santa Isabel', '73', '1', '0'),
(73770, 'Suarez', '73', '1', '0'),
(73854, 'Valle de San Juan', '73', '1', '0'),
(73861, 'Venadillo', '73', '1', '0'),
(73870, 'Villahermosa', '73', '1', '0'),
(73873, 'Villarica', '73', '1', '0'),
(76001, 'Cali', '76', '1', '0'),
(76020, 'Alcala', '76', '1', '0'),
(76036, 'Andalucia', '76', '1', '0'),
(76041, 'Ansermanuevo', '76', '1', '0'),
(76054, 'Argelia', '76', '1', '0'),
(76100, 'Bolivar', '76', '1', '0'),
(76109, 'Buenaventura', '76', '1', '0'),
(76111, 'Buga', '76', '1', '0'),
(76113, 'Bugalagrande', '76', '1', '0'),
(76122, 'Caicedonia', '76', '1', '0'),
(76126, 'Darien', '76', '1', '0'),
(76130, 'Candelaria', '76', '1', '0'),
(76147, 'Cartago', '76', '1', '0'),
(76233, 'Dagua', '76', '1', '0'),
(76243, 'El Aguila', '76', '1', '0'),
(76246, 'El Cairo', '76', '1', '0'),
(76248, 'El Cerrito', '76', '1', '0'),
(76250, 'El Dovio', '76', '1', '0'),
(76275, 'Florida', '76', '1', '0'),
(76306, 'Ginebra', '76', '1', '0'),
(76318, 'Guacari', '76', '1', '0'),
(76364, 'Jamundi', '76', '1', '0'),
(76377, 'La Cumbre', '76', '1', '0'),
(76400, 'La Union', '76', '1', '0'),
(76403, 'La Victoria', '76', '1', '0'),
(76497, 'Obando', '76', '1', '0'),
(76520, 'Palmira', '76', '1', '0'),
(76563, 'Pradera', '76', '1', '0'),
(76606, 'Restrepo', '76', '1', '0'),
(76616, 'Riofrio', '76', '1', '0'),
(76622, 'Roldanillo', '76', '1', '0'),
(76670, 'San Pedro', '76', '1', '0'),
(76736, 'Sevilla', '76', '1', '0'),
(76823, 'Toro', '76', '1', '0'),
(76828, 'Trujillo', '76', '1', '0'),
(76834, 'Tulua', '76', '1', '0'),
(76845, 'Ulloa', '76', '1', '0'),
(76863, 'Versalles', '76', '1', '0'),
(76869, 'Vijes', '76', '1', '0'),
(76890, 'Yotoco', '76', '1', '0'),
(76892, 'Yumbo', '76', '1', '0'),
(76895, 'Zarzal', '76', '1', '0'),
(81001, 'Arauca', '81', '1', '0'),
(81065, 'Arauquita', '81', '1', '0'),
(81220, 'Cravo Norte', '81', '1', '0'),
(81300, 'Fortul', '81', '1', '0'),
(81591, 'Puerto Rondon', '81', '1', '0'),
(81736, 'Saravena', '81', '1', '0'),
(81794, 'Tame', '81', '1', '0'),
(85001, 'Yopal', '85', '1', '0'),
(85010, 'Aguazul', '85', '1', '0'),
(85015, 'Chameza', '85', '1', '0'),
(85125, 'Hato Corozal', '85', '1', '0'),
(85136, 'La Salina', '85', '1', '0'),
(85139, 'Mani', '85', '1', '0'),
(85162, 'Monterrey', '85', '1', '0'),
(85225, 'Nunchia', '85', '1', '0'),
(85230, 'Orocue', '85', '1', '0'),
(85250, 'Paz de Ariporo', '85', '1', '0'),
(85263, 'Pore', '85', '1', '0'),
(85279, 'Recetor', '85', '1', '0'),
(85300, 'Sabanalarga', '85', '1', '0'),
(85315, 'Sacama', '85', '1', '0'),
(85325, 'San Luis de Palenque', '85', '1', '0'),
(85400, 'Tamara', '85', '1', '0'),
(85410, 'Tauramena', '85', '1', '0'),
(85430, 'Trinidad', '85', '1', '0'),
(85440, 'Villanueva', '85', '1', '0'),
(86001, 'Mocoa', '86', '1', '0'),
(86219, 'Colon', '86', '1', '0'),
(86320, 'Orito', '86', '1', '0'),
(86568, 'Puerto Asis', '86', '1', '0'),
(86569, 'Puerto Caicedo', '86', '1', '0'),
(86571, 'Puerto Guzman', '86', '1', '0'),
(86573, 'Puerto Leguizamo', '86', '1', '0'),
(86749, 'Sibundoy', '86', '1', '0'),
(86755, 'San Francisco', '86', '1', '0'),
(86757, 'San Miguel (La Dorad', '86', '1', '0'),
(86760, 'Santiago', '86', '1', '0'),
(86865, 'Valle del Guamuez', '86', '1', '0'),
(86885, 'Villagarzon', '86', '1', '0'),
(88001, 'San Andres', '88', '1', '0'),
(88564, 'Providencia', '88', '1', '0'),
(91001, 'Leticia', '91', '1', '0'),
(91263, 'El Encanto (CD)', '91', '1', '0'),
(91405, 'La Chorrera (CD)', '91', '1', '0'),
(91407, 'La Pedrera (CD)', '91', '1', '0'),
(91430, 'La Victoria (CD)', '91', '1', '0'),
(91460, 'Miriti Parana (CD)', '91', '1', '0'),
(91530, 'Puerto Alegria (CD)', '91', '1', '0'),
(91536, 'Puerto Arica (CD)', '91', '1', '0'),
(91540, 'Puerto Nariño', '91', '1', '0'),
(91669, 'Puerto Santander (CD', '91', '1', '0'),
(91798, 'Tarapaca (CD)', '91', '1', '0'),
(94001, 'Puerto Inirida', '94', '1', '0'),
(94343, 'Barranco Minas', '94', '1', '0'),
(94663, 'Mapiripana', '94', '1', '0'),
(94883, 'San Felipe', '94', '1', '0'),
(94884, 'Puerto Colombia', '94', '1', '0'),
(94885, 'La Guadalupe', '94', '1', '0'),
(94886, 'Cacahual', '94', '1', '0'),
(94887, 'Pana Pana', '94', '1', '0'),
(94888, 'Morichal', '94', '1', '0'),
(95001, 'San Jose del Guaviare', '95', '1', '0'),
(95015, 'Calamar', '95', '1', '0'),
(95025, 'El Retorno', '95', '1', '0'),
(95200, 'Miraflores', '95', '1', '0'),
(97001, 'Mitu', '97', '1', '0'),
(97161, 'Caruru', '97', '1', '0'),
(97511, 'Pacoa (CD)', '97', '1', '0'),
(97666, 'Taraira', '97', '1', '0'),
(97777, 'Papunaua (Morichal) ', '97', '1', '0'),
(97889, 'Yavarate (CD)', '97', '1', '0'),
(99001, 'Puerto Carreño', '99', '1', '0'),
(99524, 'La Primavera', '99', '1', '0'),
(99624, 'Santa Rosalia', '99', '1', '0'),
(99773, 'Cumaribo', '99', '1', '0');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `valor`
--

CREATE TABLE `valor` (
  `valid` bigint(11) NOT NULL,
  `domid` bigint(11) NOT NULL,
  `nomval` varchar(50) NOT NULL,
  `parval` varchar(50) DEFAULT NULL,
  `actval` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `valor`
--

INSERT INTO `valor` (`valid`, `domid`, `nomval`, `parval`, `actval`) VALUES
(8, 101, 'Tabacos', '', 1),
(9, 101, 'Mallas', '', 1),
(10, 101, 'Cajas', '', 1),
(11, 101, 'Otros', '', 1),
(13, 101, 'Ramos', '', 1),
(200, 102, 'Nacional', '', 1),
(207, 102, 'Rosas', '', 1),
(208, 102, 'Lirios', '', 1),
(209, 102, 'Girasoles', '', 1),
(210, 102, 'Astroemerias', '', 1),
(213, 6, 'Soltero(a)', NULL, 1),
(214, 6, 'Casado(a)', NULL, 1),
(215, 6, 'Separado(a)', NULL, 1),
(216, 6, 'Divorciado(a)', NULL, 1),
(217, 6, 'Union Libre', NULL, 1),
(218, 2, 'C.C', NULL, 1),
(219, 2, 'T.I', NULL, 1),
(220, 2, 'C.E', NULL, 1),
(221, 2, 'Pasaporte', NULL, 1);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `bloque`
--
ALTER TABLE `bloque`
  ADD PRIMARY KEY (`bloqid`),
  ADD KEY `fk_empid` (`empid`);

--
-- Indices de la tabla `blqxcam`
--
ALTER TABLE `blqxcam`
  ADD KEY `fk_bloq` (`bloqid`),
  ADD KEY `fk_camid` (`camid`);

--
-- Indices de la tabla `cama`
--
ALTER TABLE `cama`
  ADD PRIMARY KEY (`camid`),
  ADD KEY `fk_flor` (`florid`);

--
-- Indices de la tabla `dominio`
--
ALTER TABLE `dominio`
  ADD PRIMARY KEY (`domid`);

--
-- Indices de la tabla `empresa`
--
ALTER TABLE `empresa`
  ADD PRIMARY KEY (`empid`),
  ADD KEY `fk_em_ubid` (`ubid`);

--
-- Indices de la tabla `fitopat`
--
ALTER TABLE `fitopat`
  ADD PRIMARY KEY (`fitoid`),
  ADD KEY `fk_fit_emp` (`empid`);

--
-- Indices de la tabla `flor`
--
ALTER TABLE `flor`
  ADD PRIMARY KEY (`florid`),
  ADD KEY `valid` (`valid`);

--
-- Indices de la tabla `fumigacion`
--
ALTER TABLE `fumigacion`
  ADD PRIMARY KEY (`fumid`),
  ADD KEY `fk_quim` (`quimid`),
  ADD KEY `fk_bloqf` (`bloqid`),
  ADD KEY `perid` (`perid`);

--
-- Indices de la tabla `modulo`
--
ALTER TABLE `modulo`
  ADD PRIMARY KEY (`modid`);

--
-- Indices de la tabla `pagina`
--
ALTER TABLE `pagina`
  ADD PRIMARY KEY (`pagid`),
  ADD KEY `modid` (`modid`);

--
-- Indices de la tabla `perfil`
--
ALTER TABLE `perfil`
  ADD PRIMARY KEY (`pefid`),
  ADD KEY `modid` (`modid`),
  ADD KEY `pagid` (`pagid`);

--
-- Indices de la tabla `persona`
--
ALTER TABLE `persona`
  ADD PRIMARY KEY (`perid`),
  ADD KEY `empid_per_fk` (`empid`);

--
-- Indices de la tabla `perxpef`
--
ALTER TABLE `perxpef`
  ADD KEY `fk_pef` (`pefid`),
  ADD KEY `fk_per` (`perid`);

--
-- Indices de la tabla `pgxpef`
--
ALTER TABLE `pgxpef`
  ADD KEY `fk_pef` (`pefid`),
  ADD KEY `fk_pg` (`pagid`);

--
-- Indices de la tabla `postcos`
--
ALTER TABLE `postcos`
  ADD PRIMARY KEY (`cosecid`),
  ADD KEY `fk_bloq` (`bloqid`),
  ADD KEY `valid` (`valid`),
  ADD KEY `florid` (`florid`),
  ADD KEY `perid` (`perid`);

--
-- Indices de la tabla `quimico`
--
ALTER TABLE `quimico`
  ADD PRIMARY KEY (`quimid`),
  ADD KEY `fitoid` (`fitoid`),
  ADD KEY `fk_qim_emp` (`empid`);

--
-- Indices de la tabla `ubicacion`
--
ALTER TABLE `ubicacion`
  ADD PRIMARY KEY (`ubid`);

--
-- Indices de la tabla `valor`
--
ALTER TABLE `valor`
  ADD PRIMARY KEY (`valid`),
  ADD KEY `domid` (`domid`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `bloque`
--
ALTER TABLE `bloque`
  MODIFY `bloqid` bigint(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT de la tabla `cama`
--
ALTER TABLE `cama`
  MODIFY `camid` bigint(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de la tabla `dominio`
--
ALTER TABLE `dominio`
  MODIFY `domid` bigint(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=204;

--
-- AUTO_INCREMENT de la tabla `empresa`
--
ALTER TABLE `empresa`
  MODIFY `empid` bigint(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de la tabla `fitopat`
--
ALTER TABLE `fitopat`
  MODIFY `fitoid` bigint(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT de la tabla `flor`
--
ALTER TABLE `flor`
  MODIFY `florid` bigint(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=88;

--
-- AUTO_INCREMENT de la tabla `fumigacion`
--
ALTER TABLE `fumigacion`
  MODIFY `fumid` bigint(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT de la tabla `modulo`
--
ALTER TABLE `modulo`
  MODIFY `modid` bigint(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `perfil`
--
ALTER TABLE `perfil`
  MODIFY `pefid` bigint(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de la tabla `persona`
--
ALTER TABLE `persona`
  MODIFY `perid` bigint(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT de la tabla `postcos`
--
ALTER TABLE `postcos`
  MODIFY `cosecid` bigint(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT de la tabla `quimico`
--
ALTER TABLE `quimico`
  MODIFY `quimid` bigint(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT de la tabla `ubicacion`
--
ALTER TABLE `ubicacion`
  MODIFY `ubid` bigint(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=99774;

--
-- AUTO_INCREMENT de la tabla `valor`
--
ALTER TABLE `valor`
  MODIFY `valid` bigint(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=222;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `bloque`
--
ALTER TABLE `bloque`
  ADD CONSTRAINT `fk_empid` FOREIGN KEY (`empid`) REFERENCES `empresa` (`empid`);

--
-- Filtros para la tabla `blqxcam`
--
ALTER TABLE `blqxcam`
  ADD CONSTRAINT `fk_bloq` FOREIGN KEY (`bloqid`) REFERENCES `bloque` (`bloqid`),
  ADD CONSTRAINT `fk_camid` FOREIGN KEY (`camid`) REFERENCES `cama` (`camid`);

--
-- Filtros para la tabla `cama`
--
ALTER TABLE `cama`
  ADD CONSTRAINT `cama_ibfk_1` FOREIGN KEY (`florid`) REFERENCES `flor` (`florid`);

--
-- Filtros para la tabla `empresa`
--
ALTER TABLE `empresa`
  ADD CONSTRAINT `fk_em_ubid` FOREIGN KEY (`ubid`) REFERENCES `ubicacion` (`ubid`);

--
-- Filtros para la tabla `fitopat`
--
ALTER TABLE `fitopat`
  ADD CONSTRAINT `fk_fit_emp` FOREIGN KEY (`empid`) REFERENCES `empresa` (`empid`);

--
-- Filtros para la tabla `fumigacion`
--
ALTER TABLE `fumigacion`
  ADD CONSTRAINT `fk_bloqf` FOREIGN KEY (`bloqid`) REFERENCES `bloque` (`bloqid`),
  ADD CONSTRAINT `fk_quim` FOREIGN KEY (`quimid`) REFERENCES `quimico` (`quimid`),
  ADD CONSTRAINT `perid` FOREIGN KEY (`perid`) REFERENCES `persona` (`perid`);

--
-- Filtros para la tabla `pagina`
--
ALTER TABLE `pagina`
  ADD CONSTRAINT `pagina_ibfk_1` FOREIGN KEY (`modid`) REFERENCES `modulo` (`modid`);

--
-- Filtros para la tabla `perfil`
--
ALTER TABLE `perfil`
  ADD CONSTRAINT `fk_mod` FOREIGN KEY (`modid`) REFERENCES `modulo` (`modid`);

--
-- Filtros para la tabla `persona`
--
ALTER TABLE `persona`
  ADD CONSTRAINT `empid_per_fk` FOREIGN KEY (`empid`) REFERENCES `empresa` (`empid`);

--
-- Filtros para la tabla `perxpef`
--
ALTER TABLE `perxpef`
  ADD CONSTRAINT `perxpef_ibfk_1` FOREIGN KEY (`perid`) REFERENCES `persona` (`perid`),
  ADD CONSTRAINT `perxpef_ibfk_2` FOREIGN KEY (`pefid`) REFERENCES `perfil` (`pefid`);

--
-- Filtros para la tabla `pgxpef`
--
ALTER TABLE `pgxpef`
  ADD CONSTRAINT `fk_pg` FOREIGN KEY (`pagid`) REFERENCES `pagina` (`pagid`),
  ADD CONSTRAINT `pgxpef_ibfk_1` FOREIGN KEY (`pefid`) REFERENCES `perfil` (`pefid`);

--
-- Filtros para la tabla `postcos`
--
ALTER TABLE `postcos`
  ADD CONSTRAINT `postcos_ibfk_1` FOREIGN KEY (`bloqid`) REFERENCES `bloque` (`bloqid`),
  ADD CONSTRAINT `postcos_ibfk_2` FOREIGN KEY (`valid`) REFERENCES `valor` (`valid`),
  ADD CONSTRAINT `postcos_ibfk_3` FOREIGN KEY (`florid`) REFERENCES `flor` (`florid`),
  ADD CONSTRAINT `postcos_ibfk_4` FOREIGN KEY (`perid`) REFERENCES `persona` (`perid`);

--
-- Filtros para la tabla `quimico`
--
ALTER TABLE `quimico`
  ADD CONSTRAINT `fk_qim_emp` FOREIGN KEY (`empid`) REFERENCES `empresa` (`empid`),
  ADD CONSTRAINT `quimico_ibfk_1` FOREIGN KEY (`fitoid`) REFERENCES `fitopat` (`fitoid`);

--
-- Filtros para la tabla `valor`
--
ALTER TABLE `valor`
  ADD CONSTRAINT `valor_ibfk_1` FOREIGN KEY (`domid`) REFERENCES `dominio` (`domid`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
