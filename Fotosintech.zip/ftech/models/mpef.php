<?php
class Mpef{
//Atributos	
	private $pefid;
	private $pefnom;
    private $modid;
    private $pagid;
	
// Metodos GET devuelven el dato
    function getPefid(){
		return $this->pefid;
	}
	function getPefnom(){
		return $this->pefnom;
	}
    function getModid(){
		return $this->modid;
	}
	function getPagid(){
		return $this->pagid;
	}
	
	
// Metodos SET guardar el dato
	function setPefid($pefid){
		$this->pefid = $pefid;
	}
	function setPefnom($pefnom){
		$this->pefnom = $pefnom;
	}
    function setModid($modid){
		$this->modid = $modid;
	}
	function setPagid($pagid){
		$this->pagid = $pagid;
	}

	public function getAll(){
		$sql = "SELECT f.pefid, f.pefnom, f.modid, f.pagid, m.nomod, p.pagnom FROM perfil AS f INNER JOIN modulo AS m ON f.modid = m.modid LEFT JOIN pagina AS p ON f.pagid = p.pagid";
		$modelo = new conexion();
		$conexion = $modelo->get_conexion();
		$result = $conexion->prepare($sql);
		$result->execute();
		$res = $result->fetchall(PDO::FETCH_ASSOC);
		return $res;
	}


	public function getOne(){
		$sql = "SELECT f.pefid, f.pefnom, f.modid, f.pagid, m.nomod, p.pagnom FROM perfil AS f INNER JOIN modulo AS m ON f.modid = m.modid LEFT JOIN pagina AS p ON f.pagid = p.pagid WHERE pefid=:pefid";
		$modelo = new conexion();
		$conexion = $modelo->get_conexion();
		$result = $conexion->prepare($sql);
		$pefid = $this->getPefid();
		$result->bindParam(':pefid',$pefid);
		$result->execute();
		$res = $result->fetchall(PDO::FETCH_ASSOC);
		return $res;
	}
	
	public function save(){
		try {
			$sql = "INSERT INTO perfil (pefnom, modid, pagid) VALUES (:pefnom, :modid, :pagid)";
			$modelo = new conexion();
			$conexion = $modelo->get_conexion();
			$result = $conexion->prepare($sql);
			$pefnom = $this->getPefnom();
			$result->bindParam(':pefnom',$pefnom);
			$modid = $this->getModid();
			$result->bindParam(':modid',$modid);
			$pagid = $this->getPagid();
			$result->bindParam(':pagid',$pagid);
			$result->execute();
        } catch (Exception $e) {
            ManejoError($e);
        }
	}

	public function savePxP(){
        $modelo = new conexion();
        $conexion = $modelo->get_conexion();
        $sql = "INSERT INTO pgxpef(pagid,pefid) VALUES (:pagid,:pefid);";
        $result = $conexion->prepare($sql);
        $pefid = $this->getPefid();
        $result->bindParam(":pefid",$pefid);
        $pagid = $this->getPagid();
        $result->bindParam(":pagid",$pagid);
        $result->execute();
    }

	public function edit(){
		$sql = "UPDATE perfil SET  pefnom=:pefnom, modid=:modid, pagid=:pagid WHERE pefid=:pefid";
		$modelo = new conexion();
		$conexion = $modelo->get_conexion();
		$result = $conexion->prepare($sql);
		$pefid = $this->getPefid();
		$result->bindParam(':pefid',$pefid);
		$pefnom = $this->getPefnom();
		$result->bindParam(':pefnom',$pefnom);
		$modid = $this->getModid();
		$result->bindParam(':modid',$modid);
		$pagid = $this->getPagid();
		$result->bindParam(':pagid',$pagid);
		$result->execute();
	}

	public function getPag(){
        $res = NULL;
        $modelo = new conexion();
        $conexion = $modelo->get_conexion();
        $sql = "SELECT pagid, pagnom, icono, modid FROM pagina WHERE modid=:modid";
        $result = $conexion->prepare($sql);
        $modid = $this->getModid();
        $result->bindParam(":modid",$modid);
        $result->execute();
        $res = $result-> fetchall(PDO::FETCH_ASSOC);
        return $res;
    }

    public function delPXP(){
        try {
            $modelo = new conexion();
            $conexion = $modelo->get_conexion();
            $sql = "DELETE FROM pgxpef WHERE pefid=:pefid";
            $result = $conexion->prepare($sql);
            $pefid = $this->getPefid(); 
            $result->bindParam(":pefid", $pefid);
            $result->execute();
        } catch (Exception $e) {
            ManejoError($e);
        }
    }
	function del(){
        try{
            $sql = "DELETE FROM perfil WHERE pefid=:pefid";
            $modelo = new conexion();
            $conexion = $modelo->get_conexion();
            $result = $conexion->prepare($sql);
            $pefid = $this->getPefid();
            $result->bindParam(":pefid",$pefid);
            $result->execute();
        }catch(Exception $e){
            ManejoError($e);
        }
    }

    public function selPxP(){
        $res = NULL;
        $modelo = new conexion();
        $conexion = $modelo->get_conexion();
        $sql = "SELECT pagid FROM pgxpef WHERE pefid=:pefid";
        $result = $conexion->prepare($sql);
        $pefid = $this->getPefid();
        $result->bindParam(":pefid", $pefid);
        $result->execute();
        $res = $result-> fetchall(PDO::FETCH_ASSOC);
        return $res;
    }

	// public function grafic(){
	// 	$sql = "SELECT f.pefid, f.pefnom, COUNT(p.pefid) as cn FROM perfil AS f LEFT JOIN pgxpef AS p ON f.pefid=p.pefid GROUP BY f.pefid, f.pefnom ORDER BY COUNT(p.pefid) DESC, f.pefnom";
	// 	$modelo = new conexion();
	// 	$conexion = $modelo->get_conexion();
	// 	$result = $conexion->prepare($sql);
	// 	$result->execute();
	// 	$res = $result->fetchall(PDO::FETCH_ASSOC);
	// 	return $res;
	// }
}
?>