<?php
class Mfum{
	private $fumid;
	private $bloqid;
	private $quimid;
	private $fecha;
    private $perid;
	private $ncamas;
	private $totagua;
	private $totquim;
	private $elival;
	// Metodos Get 

	public function getFumid()
	{
		return $this->fumid;
	}
	public function getBloqid()
	{
		return $this->bloqid;
	}
	public function getQuimid()
	{
		return $this->quimid;
	}
	public function getFecha()
	{
		return $this->fecha;
	}
    public function getPerid()
	{
		return $this->perid;
	}
	public function getNcamas(){
		return $this->ncamas;
	}
	public function getTotagua(){
		return $this->totagua;
	}
	public function getTotquim(){
		return $this->totquim;
	}
	public function getElival(){
		return $this->elival;
	}
	//Metodos SET
	public function setFumid($fumid)
	{
		$this->fumid = $fumid;
	}
	public function setBloqid($bloqid){
		$this->bloqid = $bloqid;
	}
	public function setQuimid($quimid)
	{
		$this->quimid = $quimid;
	}
	public function setFecha($fecha)
	{
		$this->fecha = $fecha;
	}
    public function setPerid($perid)
	{
		$this->perid = $perid;
	}
	public function setNcamas($ncamas){
		$this->ncamas = $ncamas;
	}
	public function setTotagua($totagua){
		$this->totagua = $totagua;
	}
	public function setTotquim($totquim){
		$this->totquim = $totquim;
	}
	public function setElival($elival)
    {
        $this->elival = $elival;
    }

	public function getAll()
	{
    $sql = "SELECT f.fumid, f.bloqid, f.quimid, f.fecha, f.perid, f.ncamas,f.totagua, f.totquim, f.perid, f.elival, q.nomquim, p.ndper, p.nomper, p.apper ,q.fitoid, ft.nomfito, b.nombloq 
	FROM fumigacion AS f INNER JOIN bloque AS b ON f.bloqid=b.bloqid
	 INNER JOIN quimico AS q ON f.quimid=q.quimid
	 INNER JOIN persona AS p ON  f.perid=p.perid
	 LEFT JOIN fitopat AS ft ON q.fitoid=ft.fitoid " ; 
    $modelo = new Conexion();
    $conexion = $modelo->get_conexion();
    $result = $conexion->prepare($sql);
    $result->execute();
    $res = $result->fetchAll(PDO::FETCH_ASSOC);
    return $res;
	}

	public function getOne()
	{
		$sql = "SELECT f.fumid, f.bloqid, f.quimid, f.fecha, f.perid,f.ncamas, f.totagua, f.totquim, f.perid, f.elival, q.nomquim, ft.nomfito, p.ndper, p.nomper 
		FROM fumigacion AS f INNER JOIN blqxcam AS b ON f.bloqid=b.bloqid
		 INNER JOIN quimico AS q ON f.quimid=q.quimid
		 INNER JOIN persona AS p ON  f.perid=p.perid WHERE fumid=:fumid";
		$modelo = new Conexion();
		$conexion = $modelo->get_conexion();
		$result = $conexion->prepare($sql);
		$fumid = $this->getFumid();
		$result->bindParam(":fumid", $fumid);
		$result->execute();
		$res = $result->fetchAll(PDO::FETCH_ASSOC);
		return $res;
	}
	public function ImprF()
	{
		$sql = "SELECT DISTINCT f.fumid, f.bloqid, f.quimid, f.elival, q.ingreact, f.fecha, f.perid, f.ncamas, f.totagua, f.totquim, q.nomquim, ft.nomfito, p.ndper, p.nomper, p.apper, b.nombloq,  
		CAST((f.totagua + f.totquim) / f.ncamas AS DECIMAL(10, 2)) AS oper1,
		CAST(f.totquim / f.totagua AS DECIMAL(10, 2)) AS oper2
	 FROM fumigacion AS f INNER JOIN bloque AS b ON f.bloqid = b.bloqid INNER JOIN quimico AS q ON f.quimid = q.quimid INNER JOIN persona AS p ON f.perid = p.perid LEFT JOIN fitopat AS ft ON q.fitoid = ft.fitoid WHERE DATE(f.fecha) = CURRENT_DATE AND f.elival =0";
		$modelo = new Conexion();
		$conexion = $modelo->get_conexion();
		$result = $conexion->prepare($sql);
		$result->execute();
		$res = $result->fetchAll(PDO::FETCH_ASSOC);
		return $res;
	}
	public function total()
	{
		$sql = "SELECT SUM(f.ncamas) AS tncamas, SUM(f.totagua) as tltsa, SUM(f.totquim) AS tquim FROM fumigacion AS f WHERE DATE(f.fecha) = CURRENT_DATE AND f.elival = 0";
		$modelo = new Conexion();
		$conexion = $modelo->get_conexion();
		$result = $conexion->prepare($sql);
		$result->execute();
		$res = $result->fetchAll(PDO::FETCH_ASSOC);
		return $res;
	}
	function getOneFp(){
		$sql = 'SELECT fumid FROM fumigacion WHERE fecha=:fecha AND perid=:perid';
		$modelo = new conexion ();
		$conexion = $modelo->get_conexion();
		$result = $conexion-> prepare($sql);
		$fecha = $this->getFecha();
		$result -> bindParam (":fecha", $fecha);
		$perid = $this-> getPerid();
		$result -> bindParam(":perid", $perid);
		$result->execute();
		$res = $result->fetchAll(PDO::FETCH_ASSOC);
		return $res;
	}
	// Guardar
	public function save()
	{
		// try{
			$sql = "INSERT INTO fumigacion(bloqid, quimid, fecha, perid, ncamas, totagua, totquim) VALUES (:bloqid,:quimid,:fecha,:perid,:ncamas,:totagua,:totquim)";
			$modelo = new conexion();
			$conexion = $modelo->get_conexion();
			$result = $conexion->prepare($sql);
			$bloqid = $this->getBloqid();
			$result->bindParam(":bloqid",$bloqid);  
			$quimid = $this->getQuimid();
			$result->bindParam(":quimid", $quimid);
			$fecha = $this->getFecha();
			$result->bindParam(":fecha", $fecha);
			$perid = $_SESSION["perid"];
			$result->bindParam(":perid", $perid);
			$ncamas = $this->getNcamas();
			$result->bindParam(":ncamas",$ncamas);
			$totagua = $this->getTotagua();
			$result->bindParam(":totagua",$totagua);
			$totquim = $this->getTotquim();
			$result->bindParam(":totquim",$totquim);
			$result->execute();
			$res = $result -> fetchall(PDO::FETCH_ASSOC);
			return $res;
		// }catch(Exception $e){
		// 	ManejoError($e);
		//   }
	}
	// Eliminar
	function del()
	{
		// try{
			$sql = "UPDATE fumigacion SET elival='1' WHERE fumid = :fumid";
			$modelo = new conexion();
			$conexion = $modelo->get_conexion();
			$result = $conexion->prepare($sql);
			$fumid = $this->getFumid();
			$result->bindParam(":fumid", $fumid);
			$result->execute();
		//  }catch(Exception $e){
		//  	ManejoError($e);
		//    }
	}
	public function grafic(){
        $sql = "SELECT f.quimid ,q.nomquim AS quim, SUM(f.quimid) AS tot
		FROM fumigacion f
		JOIN quimico q ON f.quimid = q.quimid
		GROUP BY f.quimid, q.nomquim
		ORDER BY quimid;
		"; 
		$modelo = new conexion();
		$conexion = $modelo->get_conexion();
		$result = $conexion->prepare($sql);
		$result->execute();
		$res = $result->fetchall(PDO::FETCH_ASSOC);
		return $res;
	}
}
?>