<?php
class Mper{
//Atributos	
    private $perid;
    private $ndper;
    private $nomper;
    private $apper;
    private $emaper;
    private $passper;
    private $dirper;
    private $telper;
    private $ubid;
    private $empid;

    private $estper;
    private $fecnacper;
    private $ocuper;

    private $tipdper;
    private $actper;
    private $clav;
    private $fecsol;
    private $feccam;
    private $sexo;
    private $foto;

    private $pefid;
//Metodos GET devuelven el dato
    function getPerid(){
        return $this->perid;
    }
    function getNdper(){
        return $this->ndper;
    }
    function getNomper(){
        return $this->nomper;
    }
    function getApper(){
        return $this->apper;
    }
    function getEmaper(){
        return $this->emaper;
    }
    function getPassper(){
        return $this->passper;
    }
    function getDirper(){
        return $this->dirper;
    }
    function getTelper(){
        return $this->telper;
    }
    function getUbid(){
        return $this->ubid;
    }

    function getEstper(){
        return $this->estper;
    }
    function getFecnacper(){
        return $this->fecnacper;
    }
    function getOcuper(){
        return $this->ocuper;
    }
    public function getEmpid(){
        return $this->empid;
    }

    function getTipdper(){
        return $this->tipdper;
    }
    // function getAcomt(){
    //     return $this->acomt;
    // }
    function getActper(){
        return $this->actper;
    }
    function getPefid(){
        return $this->pefid;
    }
    function getSexo(){
        return $this->sexo;
    }
    function getClav(){
        return $this->clav;
    }
    function getFecsol(){
        return $this->fecsol;
    }
    function getFeccam(){
        return $this->feccam;
    }
    function getFoto(){
        return $this->foto;
    }
// Metodos SET guardar el dato
    function setPerid($perid){
        $this->perid = $perid;
    }
    function setNdper($ndper){
        $this->ndper = $ndper;
    }
    function setNomper($nomper){
        $this->nomper = $nomper;
    }
    function setApper($apper){
        $this->apper = $apper;
    }
    function setEmaper($emaper){
        $this->emaper = $emaper;
    }
    function SetPassper($passper){
        $this->passper = $passper;
    }
    function setDirper($dirper){
        $this->dirper = $dirper;
    }
    function setTelper($telper){
        $this->telper = $telper;
    }
    function setUbid($ubid){
        $this->ubid = $ubid;
    }
    function setEstper($estper){
        $this->estper = $estper;
    }
    function setFecnacper($fecnacper){
        $this->fecnacper = $fecnacper;
    }
    function setOcuper($ocuper){
        $this->ocuper = $ocuper;
    }
    public function setEmpid($empid){
        $this->empid = $empid;
    }

    function setTipdper($tipdper){
        $this->tipdper = $tipdper;
    }
    // function setAcomt($acomt){
    //     $this->acomt = $acomt;
    // }
    function setActper($actper){
        $this->actper = $actper;
    }
    function setClav($clav){
        $this->clav = $clav;
    }
    function setFecsol($fecsol){
        $this->fecsol = $fecsol;
    }
    function setFeccam($feccam){
        $this->feccam = $feccam;
    }
    function setSexo($sexo){
        $this->sexo = $sexo;
    }

    function setPefid($pefid){
        $this->pefid = $pefid;
    }
    function setFoto($foto){
        $this->foto = $foto;
    }
    // Metodos Generales
    public function getAll($pg){
        $sql = "SELECT p.perid, p.ndper, p.empid, p.nomper, p.apper, p.emaper, p.passper, p.dirper, p.telper, p.ubid, p.estper, p.fecnacper, p.ocuper,p.tipdper, p.actper, p.sexo, p.fecsol, p.clav, p.feccam,u.nomubi, p.foto FROM persona AS p INNER JOIN ubicacion AS u ON p.ubid=u.ubid";
        $modelo = new conexion();
        $conexion = $modelo->get_conexion();
        $result = $conexion->prepare($sql);
        $result->execute();
        $res = $result->fetchall(PDO::FETCH_ASSOC);
        return $res;
    }

    public function getOne(){
        $sql = "SELECT p.perid, p.ndper, p.empid, p.nomper, p.apper, p.emaper, p.passper, p.dirper, p.telper, p.ubid, p.estper, p.fecnacper, p.ocuper, p.tipdper, p.actper, p.sexo, u.nomubi, u.depubi,p.foto FROM persona AS p  INNER JOIN ubicacion AS u ON p.ubid=u.ubid WHERE perid=:perid"; 
        $modelo = new conexion();
        $conexion = $modelo->get_conexion();
        $result = $conexion->prepare($sql);
        $perid = $this->getPerid();
        $result->bindParam(':perid',$perid);
        $result->execute();
        $res = $result->fetchall(PDO::FETCH_ASSOC);
        return $res;
    }
    function save(){
        try{
            $sql = "INSERT INTO persona (empid, ndper, nomper, apper, emaper, passper, dirper, telper, ubid, fecnacper, actper, sexo, estper, ocuper, foto, tipdper) 
                    VALUES (:empid, :ndper, :nomper, :apper, :emaper, :passper, :dirper, :telper, :ubid, :fecnacper, :actper, :sexo, :estper, :ocuper, :foto, :tipdper) ";
            $modelo = new conexion();
            $conexion = $modelo->get_conexion();
            $result = $conexion->prepare($sql);
            $empid = $this->getEmpid();
            $result->bindParam(":empid", $empid);
            $ndper = $this->getNdper();
            $result->bindParam(":ndper",$ndper);
            $nomper = $this->getNomper();
            $result->bindParam(":nomper",$nomper);
            $apper = $this->getApper();
            $result->bindParam(":apper",$apper);
            $emaper = $this->getEmaper();
            $result->bindParam(":emaper",$emaper);
            $passper = $this->getPassper();
            $result->bindParam(":passper",$passper);
            $dirper = $this->getDirper();
            $result->bindParam(":dirper",$dirper);
            $telper = $this->getTelper();
            $result->bindParam(":telper",$telper);
            $ubid = $this->getUbid();
            $result->bindParam(":ubid",$ubid);
            $estper = $this->getEstper();
            $result->bindParam(":estper",$estper);
            $fecnacper = $this->getFecnacper();
            $result->bindParam(":fecnacper",$fecnacper);
            $ocuper = $this->getOcuper();
            $result->bindParam(":ocuper",$ocuper);
            $tipdper = $this->getTipdper();
            $result->bindParam(":tipdper",$tipdper);
            $actper = $this->getActper();
            $result->bindParam(":actper",$actper);
            $sexo = $this->getSexo();
            $result->bindParam(":sexo",$sexo);
            $foto = $this->getFoto();
            $result->bindParam(":foto",$foto);
            $result->execute();
        }catch(Exception $e){
            ManejoError($e);
        }
    }
    function savePxF(){
        try{
            $sql = "INSERT INTO perxpef (perid,pefid) VALUES (:perid,:pefid)";
            $modelo = new conexion();
            $conexion = $modelo->get_conexion();
            $result = $conexion->prepare($sql);
            $perid = $this->getPerid();
            $result->bindParam(":perid",$perid);
            $pefid = $this->getPefid();
            $result->bindParam(":pefid",$pefid);
            $result->execute();
            $res = $result->fetchall(PDO::FETCH_ASSOC);
            return $res; 
        }catch(Exception $e){
            ManejoError($e);
        }
    }
    function delPxF(){
        try{
            $sql = "DELETE FROM perxpef WHERE perid=:perid";
            $modelo = new conexion();
            $conexion = $modelo->get_conexion();
            $result = $conexion->prepare($sql);
            $perid = $this->getPerid();
            $result->bindParam(":perid",$perid);
            $result->execute();
            $res = $result->fetchall(PDO::FETCH_ASSOC);
            return $res; 
        }catch(Exception $e){
            ManejoError($e);
        }
    }
    function getOnePxF(){
        $sql = "SELECT pefid AS pagid FROM perxpef WHERE perid=:perid";
        $modelo = new conexion();
        $conexion = $modelo->get_conexion();
        $result = $conexion->prepare($sql);
        $perid = $this->getPerid();
        $result -> bindParam(":perid",$perid);
        $result->execute();
        $res = $result->fetchall(PDO::FETCH_ASSOC);
        return $res;
    }
    function edit(){
        $sql = "UPDATE persona SET empid=:empid, ndper=:ndper, nomper=:nomper, apper=:apper, emaper=:emaper, passper=:passper, dirper=:dirper, telper=:telper, ubid=:ubid, fecnacper=:fecnacper, actper=:actper, sexo=:sexo,";
            if($this->getFoto()) $sql .= "foto=:foto,"; 
        $sql .= "estper=:estper, ocuper=:ocuper, tipdper=:tipdper WHERE perid=:perid";
        $modelo = new conexion();
        $conexion = $modelo->get_conexion();
        $result = $conexion->prepare($sql);
        $perid = $this->getPerid();
        $result->bindParam(":perid",$perid);
        $empid = $this->getEmpid();
        $result->bindParam(":empid", $empid);
        $ndper = $this->getNdper();
        $result->bindParam(":ndper",$ndper);
        $nomper = $this->getNomper();
        $result->bindParam(":nomper",$nomper);
        $apper = $this->getApper();
        $result->bindParam(":apper",$apper);
        $emaper = $this->getEmaper();
        $result->bindParam(":emaper",$emaper);
        $passper = $this->getPassper();
        $result->bindParam(":passper",$passper);
        $dirper = $this->getDirper();
        $result->bindParam(":dirper",$dirper);
        $telper = $this->getTelper();
        $result->bindParam(":telper",$telper);
        $ubid = $this->getUbid();
        $result->bindParam(":ubid",$ubid);
        $estper = $this->getEstper();
        $result->bindParam(":estper",$estper);
        $fecnacper = $this->getFecnacper();
        $result->bindParam(":fecnacper",$fecnacper);
        $ocuper = $this->getOcuper();
        $result->bindParam(":ocuper",$ocuper);
        if($this->getFoto()) {
            $foto = $this->getFoto();
            $result->bindParam(":foto",$foto);
        }
        $tipdper = $this->getTipdper();
        $result->bindParam(":tipdper",$tipdper);
        $actper = $this->getActper();
        $result->bindParam(":actper",$actper);
        $sexo = $this->getSexo();
        $result->bindParam(":sexo",$sexo);
        $result->execute();
    }
    function del(){
        try{
            $sql = "DELETE FROM persona WHERE perid=:perid";
            $modelo = new conexion();
            $conexion = $modelo->get_conexion();
            $result = $conexion->prepare($sql);
            $perid = $this->getPerid();
            $result->bindParam(":perid",$perid);
            $result->execute();
        }catch(Exception $e){
            ManejoError($e);
        }
    }

    function getOnePef($modid){
        $sql = "SELECT pefid, pefnom, modid, pagid FROM perfil WHERE modid=:modid";
        $modelo = new conexion();
        $conexion = $modelo->get_conexion();
        $result = $conexion->prepare($sql);
        $result -> bindParam(":modid",$modid);
        $result->execute();
        $res = $result->fetchall(PDO::FETCH_ASSOC);
        return $res;
    }

    function Actper(){
        $sql = "UPDATE persona SET actper=:actper WHERE perid=:perid";
        $modelo = new conexion();
        $conexion = $modelo->get_conexion();
        $result = $conexion->prepare($sql);
        $perid = $this->getPerid();
        $result->bindParam(":perid",$perid);
        $actper = $this->getActper();
        $result->bindParam(":actper",$actper);
        $result->execute();
    }
    function valor(){
        $sql = "SELECT valid, nomval, domid FROM valor";
        $modelo = new conexion();
        $conexion = $modelo->get_conexion();
        $result = $conexion->prepare($sql);
        $result->execute();
        $res = $result->fetchall(PDO::FETCH_ASSOC);
        return $res;
    }

}
?>