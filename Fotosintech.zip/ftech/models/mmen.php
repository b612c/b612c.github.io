<?php
class Mmen{
	//Atributos	
	private $pagid;
	private $idper;
	// Metodos GET devuelven el dato
	function getPagid(){
		return $this->pagid;
	}
	function getIdper(){
		return $this->idper;
	}
	// Metodos SET guardar el dato
	function setIdper($idper){
		$this->idper = $idper;
	}
	function setPagid($pagid){
		$this->pagid = $pagid;
	}

	public function getMen(){
		$sql = "SELECT p.pagid, p.pagnom, p.pagarc, p.icono FROM pagina AS p INNER JOIN pgxpef AS f ON p.pagid=f.pagid WHERE p.pagmos=1 AND f.pefid='".$_SESSION['pefid']."' ORDER BY p.pagord;";
		$modelo = new conexion();
		$conexion = $modelo->get_conexion();
		$result = $conexion->prepare($sql);
		$result->execute();
		$res = $result->fetchall(PDO::FETCH_ASSOC);
		return $res;
	}

	public function getOneMen(){
		$sql = "SELECT p.pagid, p.pagnom, p.pagarc, p.icono FROM pagina AS p WHERE p.pagid=:pagid ORDER BY p.pagord;";
		$modelo = new conexion();
		$conexion = $modelo->get_conexion();
		$result = $conexion->prepare($sql);
		$pagid = $this->getPagid();
		$result->bindParam(':pagid', $pagid);
		$result->execute();
		$res = $result->fetchall(PDO::FETCH_ASSOC);
		return $res;
	}

	public function getVal(){
		$sql = "SELECT p.pagid, p.pagnom, p.pagarc, p.icono, p.pagmos FROM pagina AS p WHERE p.pagid=:pagid";
		$modelo = new conexion();
		$conexion = $modelo->get_conexion();
		$result = $conexion->prepare($sql);
		$pagid = $this->getpagid();
		$result->bindParam(':pagid', $pagid);
		$result->execute();
		$res = $result->fetchall(PDO::FETCH_ASSOC);
		return $res;
	}
}
