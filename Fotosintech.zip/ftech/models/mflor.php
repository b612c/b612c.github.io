<?php
class Mflor{
    
    private $florid; 
    private $desf; 
    private $cuidaf;
    private $color;
    private $imgf;
    private $valid;

    public function getFlorid(){
        return $this->florid;
    }
    public function getDesf(){
        return $this->desf;
    }
    public function getCuidaf(){
        return $this->cuidaf;
    }
    public function getImgf(){
        return $this->imgf;
    }
    public function getValid(){
        return $this->valid;
    }
    public function getColor(){
        return $this->color;
    }

    public function SetFlorid($florid){
        $this->florid = $florid;
    }
    public function SetDesf($desf){
        $this->desf = $desf;
    }
    public function SetCuidaf($cuidaf){
        $this->cuidaf = $cuidaf;
    }
    public function setImgf($imgf){
        $this->imgf = $imgf;
    }
    public function setValid($valid){
        $this->valid = $valid;
    }
    public function setColor($color){
        $this->color = $color;
    }


    function getAll(){
        $sql = "SELECT f.florid, f.desf, f.color, f.cuidaf, f.imgf, f.valid, v.nomval FROM flor AS f INNER JOIN valor AS v ON f.valid=v.valid ORDER BY florid ASC";
        $modelo = new conexion();
        $conexion = $modelo->get_conexion();
        $result = $conexion->prepare($sql);
        $result->execute();
        $res = $result->fetchAll(PDO::FETCH_ASSOC);
        return $res;
    }
    function getOne(){
        $sql = "SELECT f.florid, f.desf, f.cuidaf, f.color, f.imgf, f.valid, v.nomval AS tipo FROM flor AS f INNER JOIN valor AS v ON f.
        valid=v.valid WHERE florid=:florid";
        $modelo = new conexion();
        $conexion = $modelo->get_conexion();
        $result = $conexion->prepare($sql);
        $florid = $this->getFlorid();
        $result->bindParam(":florid", $florid);
        $result->execute();
        $res = $result->fetchAll(PDO::FETCH_ASSOC);
        return $res;
    }

    function save(){
        try {
            $sql = "INSERT INTO flor(desf, cuidaf, color, imgf, valid) Values (:desf, :cuidaf, :color, :imgf, :valid)";
            $modelo = new conexion();
            $conexion = $modelo->get_conexion();
            $result = $conexion->prepare($sql);
            $desf = $this->getDesf();
            $result->bindParam(":desf", $desf);
            $cuidaf = $this->getCuidaf();
            $result->bindParam(":cuidaf", $cuidaf);
            $imgf = $this->getImgf();
            $result->bindParam(":imgf", $imgf);
            $valid = $this->getValid();
            $result->bindParam(":valid", $valid);
            $color = $this->getColor();
            $result->bindParam(":color", $color);
            $result->execute();
        } catch (Exception $e) {
            ManejoError($e);
        }
    }
    function edit(){
        $sql = "UPDATE flor SET desf=:desf, cuidaf=:cuidaf, color=:color, "; 
            if($this->getImgf()) $sql .= "imgf=:imgf, ";
        $sql .= "valid=:valid WHERE florid=:florid";
        $modelo = new conexion();
        $conexion = $modelo->get_conexion();
        $result = $conexion->prepare($sql);
        $florid = $this->getFlorid();
        $result->bindParam(":florid", $florid);
        $desf = $this->getDesf();
        $result->bindParam(":desf", $desf);
        $cuidaf = $this->getCuidaf();
        $result->bindParam(":cuidaf", $cuidaf);
        
        if($this->getImgf()){
            $imgf = $this->getImgf();
            $result->bindParam(":imgf", $imgf);
        }
    
        $valid = $this->getValid();
        $result->bindParam(":valid", $valid);
        $color = $this->getColor();
        $result->bindParam(":color", $color);
        $result->execute();
        $res = $result->fetchall(PDO::FETCH_ASSOC);
        return $res; 
    }

    function del(){
        try {
            $sql = "DELETE FROM flor WHERE florid=:florid";
            $modelo = new conexion();
            $conexion = $modelo->get_conexion();
            $result = $conexion->prepare($sql);
            $florid = $this->getFlorid();
            $result->bindParam(":florid", $florid);
            $result->execute();
        } catch (Exception $e) {
            ManejoError($e);
        }
    }

    function getTpF(){
        $sql = " SELECT DISTINCT f.valid, v.nomval FROM flor AS f INNER JOIN valor AS v ON f.valid=v.valid";
        $modelo = new conexion();
        $conexion = $modelo->get_conexion();
        $result = $conexion->prepare($sql);
        $result->execute();
        $res = $result->fetchAll(PDO::FETCH_ASSOC);
        return $res;
    }
    
    function getClF(){
        $sql = " SELECT DISTINCT color FROM flor";
        $modelo = new conexion();
        $conexion = $modelo->get_conexion();
        $result = $conexion->prepare($sql);
        $result->execute();
        $res = $result->fetchAll(PDO::FETCH_ASSOC);
        return $res;
    }
    function getFxp($florid)
	{
		$res = NULL;
		$modelo = new conexion();
		$conexion = $modelo->get_conexion();
		$sql = "SELECT COUNT(cosecid) AS co FROM postcos WHERE florid=:florid";
		$result = $conexion->prepare($sql);

		$result->bindParam(":florid", $florid);
		$result->execute();
		$res = $result->fetchAll(PDO::FETCH_ASSOC);
		return $res;
	}
    function getFxc($florid)
	{
		$res = NULL;
		$modelo = new conexion();
		$conexion = $modelo->get_conexion();
		$sql = "SELECT COUNT(camid) AS ca FROM cama WHERE florid=:florid";
		$result = $conexion->prepare($sql);

		$result->bindParam(":florid", $florid);
		$result->execute();
		$res = $result->fetchAll(PDO::FETCH_ASSOC);
		return $res;
	}

}
?>