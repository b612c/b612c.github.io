<?php
	class Mmod{
		private $modid;
		private $nomod;
		private $imgmod;
		private $actmod;
		private $pagid;

		public function getModid(){
			return $this->modid;
		}
		public function getNomod(){
			return $this->nomod;
		}
		public function getImgmod(){
			return $this->imgmod;
		}
		public function getActmod(){
			return $this->actmod;
		}
		public function getPagid(){
			return $this->pagid;
		}

		public function setModid($modid){
			$this->modid=$modid;
		}
		public function setNomod($nomod){
			$this->nomod=$nomod;
		}
		public function setImgmod($imgmod){
			$this->imgmod=$imgmod;
		}
		public function setActmod($actmod){
			$this->actmod=$actmod;
		}
		public function setPagid($pagid){
			$this->pagid=$pagid;
		}

		function getAll(){
			$sql = "SELECT m.modid, m.nomod, m.imgmod, m.actmod, m.pagid, p.pagid, p.pagnom FROM modulo AS m LEFT JOIN pagina AS p ON m.pagid=p.pagid";
			$modelo = new conexion();
			$conexion = $modelo->get_conexion();
			$result = $conexion->prepare($sql);
			$result->execute();
			$res = $result->fetchall(PDO::FETCH_ASSOC);
			return $res;
		}

		function getAllAct(){
			$sql = "SELECT m.modid, m.nomod, m.imgmod, m.actmod FROM modulo AS m WHERE m.actmod=1;";
			$modelo = new conexion();
			$conexion = $modelo->get_conexion();
			$result = $conexion->prepare($sql);
			$result->execute();
			$res = $result->fetchall(PDO::FETCH_ASSOC);
			return $res;
		}

		function getOnePrPf(){
			$sql = "SELECT m.modid, m.nomod, p.pefid, p.pefnom, p.pagid FROM modulo AS m LEFT JOIN perfil AS p ON m.modid=p.modid RIGHT JOIN perxpef AS f ON p.pefid=f.pefid WHERE f.perid='".$_SESSION["perid"]."';";
			$modelo = new conexion();
			$conexion = $modelo->get_conexion();
			$result = $conexion->prepare($sql);
			$result->execute();
			$res = $result->fetchall(PDO::FETCH_ASSOC);
			return $res;
		}

		function getOnePrPfMd(){
			$sql = "SELECT m.modid, m.nomod, p.pefid, p.pefnom, p.pagid FROM modulo AS m LEFT JOIN perfil AS p ON m.modid=p.modid RIGHT JOIN perxpef AS f ON p.pefid=f.pefid WHERE f.perid='".$_SESSION["perid"]."' AND m.modid=:modid;";
			$modelo = new conexion();
			$conexion = $modelo->get_conexion();
			$result = $conexion->prepare($sql);
			$modid = $this->getModid();
			$result->bindParam(":modid",$modid);
			$result->execute();
			$res = $result->fetchall(PDO::FETCH_ASSOC);
			return $res;
		}

		function getOne(){
			$sql = "SELECT modid, nomod, imgmod, actmod, pagid FROM modulo WHERE modid=:modid";
			$modelo = new conexion();
			$conexion = $modelo->get_conexion();
			$result = $conexion->prepare($sql);
			$modid = $this->getModid();
			$result->bindParam(":modid",$modid);
			$result->execute();
			$res = $result->fetchall(PDO::FETCH_ASSOC);
			return $res;
		}

		function save(){
			try {
				$sql = "INSERT INTO modulo(nomod, ";
					if($this->getImgmod()) $sql .= "imgmod,";
				$sql .= " actmod, pagid) VALUES (:nomod, ";
					if($this->getImgmod()) $sql .= ":imgmod,";
				$sql .= " :actmod, :pagid)";
				$modelo = new conexion();
				$conexion = $modelo->get_conexion();
				$result = $conexion->prepare($sql);
				$nomod = $this->getNomod();
				$result->bindParam(":nomod",$nomod);
				if($this->getImgmod()){
					$imgmod = $this->getImgmod();
					$result->bindParam(":imgmod",$imgmod);
				}
				$actmod = $this->getActmod();
				$result->bindParam(":actmod",$actmod);
				$pagid = $this->getPagid();
				$result->bindParam(":pagid",$pagid);
				$result->execute();
			} catch (Exception $e) {
				ManejoError($e);
			}
		}

		function edact(){
			$sql = "UPDATE modulo SET actmod=:actmod WHERE modid=:modid";
			$modelo = new conexion();
			$conexion = $modelo->get_conexion();
			$result = $conexion->prepare($sql);
			$modid = $this->getModid();
			$result->bindParam(":modid",$modid);
			$actmod = $this->getActmod();
			$result->bindParam(":actmod",$actmod);
			$result->execute();
		}

		function edit(){
			$sql = "UPDATE modulo SET nomod=:nomod, ";
				if($this->getImgmod()) $sql .= "imgmod=:imgmod, ";
			$sql .= "actmod=:actmod, pagid=:pagid WHERE modid=:modid";
			$modelo = new conexion();
			$conexion = $modelo->get_conexion();
			$result = $conexion->prepare($sql);
			$modid = $this->getModid();
			$result->bindParam(":modid",$modid);
			$nomod = $this->getNomod();
			$result->bindParam(":nomod",$nomod);

			if($this->getImgmod()){
				$imgmod = $this->getImgmod();
				$result->bindParam(":imgmod",$imgmod);
			}

			$actmod = $this->getActmod();
			$result->bindParam(":actmod",$actmod);
			$pagid = $this->getPagid();
			$result->bindParam(":pagid",$pagid);
			$result->execute();
		}

		function del(){
			try {
				$sql = "DELETE FROM modulo WHERE modid=:modid";
				$modelo = new conexion();
				$conexion = $modelo->get_conexion();
				$result = $conexion->prepare($sql);
				$modid = $this->getModid();
				$result->bindParam(":modid",$modid);
				$result->execute();
		} catch (Exception $e) {
            ManejoError($e);
        }
		}

		public function getPag(){
        	$res = NULL;
        	$modelo = new conexion();
        	$conexion = $modelo->get_conexion();
        	$sql = "SELECT pagid, pagnom, icono, modid FROM pagina WHERE modid=:modid";
        	$result = $conexion->prepare($sql);
        	$modid = $this->getModid();
        	$result->bindParam(":modid",$modid);
        	$result->execute();
        	$res = $result-> fetchall(PDO::FETCH_ASSOC);
        	return $res;
    	}

		function getMxP($modid){
			$sql ="SELECT COUNT(pefid) AS can FROM perfil WHERE modid=:modid";
			$modelo =new conexion();
			$conexion = $modelo->get_conexion();
			$result = $conexion->prepare($sql);
			$result->bindParam(":modid",$modid);
			$result->execute();
			$res = $result-> fetchall(PDO::FETCH_ASSOC);
			return $res;
		}
	}
?>