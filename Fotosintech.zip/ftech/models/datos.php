<?php
	$host = "localhost";
	$db = "fotosintech";
	$user = "root";
	$pass = "";
	
$con = mysqli_connect($host, $user, $pass) or die("No se ha podido conectar al Servidor");
$database = mysqli_select_db($con, $db) or die("Upps! Error en conectar a la Base de Datos");


?>
