<?php
    class Mdom{
        private $domid;
        private $nomd;

        function getDomid(){
            return $this -> domid;
        }
        function getNomd(){
            return $this -> nomd;
        }

        function setDomid($domid){
            $this -> domid = $domid;
        }
        function setNomd($nomd){
            $this -> nomd = $nomd;
        }

        function getAll(){
            $sql = "SELECT domid, nomd FROM dominio";
            $modelo = new conexion();
            $conexion = $modelo -> get_conexion();
            $result = $conexion -> prepare($sql);
            $result -> execute();
            $res = $result -> fetchall(PDO::FETCH_ASSOC);
            return $res;
        }
        function getOne(){
            $sql = "SELECT domid, nomd FROM dominio WHERE domid=:domid";
            $modelo = new conexion();
            $conexion = $modelo -> get_conexion();
            $result = $conexion -> prepare($sql);
            $domid = $this -> getDomid();
            $result -> bindParam(':domid',$domid);
            $result -> execute();
            $res = $result -> fetchall(PDO::FETCH_ASSOC);
            return $res;
        }
        function save(){
            try{
                $sql = "INSERT INTO dominio (nomd) VAlUES (:nomd)";
                $modelo = new conexion();
                $conexion = $modelo -> get_conexion();
                $result = $conexion -> prepare($sql);
                $nomd = $this -> getNomd();
                $result -> bindParam(':nomd',$nomd);
                $result -> execute();
                $res = $result -> fetchall(PDO::FETCH_ASSOC);
                return $res;
            }catch(Exception $e){
                ManejoError($e);
            }
        }
        public function getDxV($domid){
          $modelo = new conexion();
          $conexion = $modelo->get_conexion();
          $sql = "SELECT COUNT(valid) AS can FROM valor WHERE domid=:domid";
          $result = $conexion->prepare($sql);
          $result->bindParam(":domid", $domid);
          $result->execute();
          return $result->fetchall(PDO::FETCH_ASSOC);
        }
        function edit(){
            $sql = "UPDATE dominio set nomd=:nomd WHERE domid=:domid";
            $modelo = new conexion();
            $conexion = $modelo -> get_conexion();
            $result = $conexion -> prepare($sql);
            $domid = $this -> getDomid();
            $result -> bindParam(':domid',$domid);
            $nomd = $this -> getNomd();
            $result -> bindParam(':nomd',$nomd);
            $result -> execute();
            $res = $result -> fetchall(PDO::FETCH_ASSOC);
            return $res;
        }
        function del(){
            try{
                $sql = "DELETE FROM dominio WHERE domid=:domid";
                $modelo = new conexion();
                $conexion = $modelo -> get_conexion();
                $result = $conexion -> prepare($sql);
                $domid = $this -> getDomid();
                $result -> bindParam(':domid',$domid);
                $result -> execute();
                $res = $result -> fetchall(PDO::FETCH_ASSOC);
                return $res;
            }catch(Exception $e){
                ManejoError($e);
            }
        }
    }
?>