<?php
class Mqui {
    private $quimid;
    private $empid;
    private $nomquim;
    private $actquim;
    private $ingreact;
    private $fitoid;
// Metodos Get 
public function getQuimid(){
    return $this->quimid;
}
public function getNomquim(){
    return $this->nomquim;
}
public function getActquim(){
    return $this->actquim;
}
public function getIngreact(){
    return $this->ingreact;
}
public function getFitoid(){
    return $this->fitoid;
}
public function getEmpid(){
    return $this->empid;
}
// Metodo set

public function setQuimid($quimid){
    $this->quimid= $quimid;
}
public function setNomquim($nomquim){
    $this->nomquim = $nomquim;
}
public function setActquim($actquim){
    $this->actquim = $actquim;
}
public function setIngreact($ingreact){
    $this->ingreact = $ingreact;
}
public function setFitoid($fitoid){
    $this->fitoid = $fitoid;
}
public function setEmpid($Empid){
    $this->empid = $Empid;
}
    public function getAll() {
        $sql = "SELECT q.quimid, q.nomquim, q.actquim, q.ingreact, q.fitoid, f.nomfito, f.tpfito  FROM quimico AS q INNER JOIN fitopat AS f ON q.fitoid=f.fitoid";
        $modelo = new Conexion();
        $conexion = $modelo->get_conexion();
        $result = $conexion->prepare($sql);
        $result->execute();
        $res = $result->fetchAll(PDO::FETCH_ASSOC);
        return $res;
    }
    public function getOne() {
        $sql = "SELECT quimid,nomquim,actquim,ingreact,fitoid,empid FROM quimico WHERE quimid=:quimid";
        $modelo = new Conexion();
        $conexion = $modelo->get_conexion();
        $result = $conexion->prepare($sql);
        $quimid = $this->getQuimid();
        $result->bindParam(":quimid", $quimid);
        $result->execute();
        $res = $result->fetchAll(PDO::FETCH_ASSOC);
        return $res;
    }
    // Guardar
    public function save(){
            $sql = "INSERT INTO quimico(nomquim,actquim,ingreact,fitoid,empid) VALUES (:nomquim,:actquim,:ingreact,:fitoid,:empid)";
            $modelo = new conexion();
            $conexion = $modelo->get_conexion();
            $result = $conexion->prepare($sql);
            $nomquim = $this->getNomquim();
            $result->bindParam(":nomquim",$nomquim);
            $actquim = $this->getActquim();
            $result->bindParam(":actquim",$actquim);
            $ingreact = $this->getIngreact();
            $result->bindParam(":ingreact",$ingreact);
            $fitoid = $this->getFitoid();
            $result->bindParam(":fitoid",$fitoid);
            $empid = $this->getEmpid();
            $result->bindParam(":empid", $empid);
            $result ->execute();
        
    }
//    Editar
    public function edit() {
            $sql = "UPDATE quimico SET nomquim = :nomquim, actquim = :actquim, ingreact=:ingreact, fitoid=:fitoid, empid=:empid WHERE quimid = :quimid";
            $modelo = new Conexion();
            $conexion = $modelo->get_conexion();
            $result = $conexion->prepare($sql);
            $quimid = $this->getQuimid();
            $result->bindParam(":quimid", $quimid);
            $nomquim = $this->getNomquim();
            $result->bindParam(":nomquim", $nomquim);
            $actquim = $this->getActquim();
            $result->bindParam(":actquim", $actquim);
            $ingreact = $this->getIngreact();
            $result->bindParam(":ingreact",$ingreact);
            $fitoid = $this->getFitoid();
            $result->bindParam(":fitoid",$fitoid);
            $empid = $this->getEmpid();
            $result->bindParam(":empid", $empid);
            $result->execute();
            $res = $result->fetchAll(PDO::FETCH_ASSOC);
            return $res;
    }
// Eliminar
    function del(){
        try{
            $sql = "DELETE FROM quimico WHERE quimid = :quimid";
            $modelo = new conexion();
            $conexion = $modelo->get_conexion();
            $result = $conexion->prepare($sql);
            $quimid = $this->getQuimid();
            $result->bindParam(":quimid", $quimid);
            $result->execute();
        }catch(Exception $e){
            ManejoError($e);
        }
    }
    function Actquim(){
        $sql ="UPDATE quimico SET actquim=:actquim WHERE quimid=:quimid";
        $modelo = new conexion();
        $conexion = $modelo->get_conexion();
        $result = $conexion->prepare($sql);
        $quimid = $this->getQuimid();
        $result->bindParam(":quimid",$quimid);
        $actquim = $this->getActquim();
        $result->bindParam(":actquim", $actquim);
        $result->execute();    
        
    }
    function getQxf($quimid)
	{
		$res = NULL;
		$modelo = new conexion();
		$conexion = $modelo->get_conexion();
		$sql = "SELECT COUNT(fumid) AS fu FROM fumigacion WHERE quimid=:quimid";
		$result = $conexion->prepare($sql);

		$result->bindParam(":quimid", $quimid);
		$result->execute();
		$res = $result->fetchAll(PDO::FETCH_ASSOC);
		return $res;
	}
}
?>