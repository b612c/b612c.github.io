<?php
require_once 'conexion.php';
class Mcam{
    private $camid;
    private $florid;

    public function getCamid(){
        return $this->camid;
    }
    public function getFlorid(){
        return $this->florid;
    }

    public function setCamid($camid){
        $this->camid = $camid;
    }
    public function setFlorid($florid){
        $this->florid = $florid;
    }

    function getAll(){
        $sql = "SELECT c.camid, c.florid, f.florid, f.desf,f.color, f.cuidaf, f.valid, v.nomval FROM cama AS c LEFT JOIN flor AS f ON c.florid=f.florid LEFT JOIN valor AS v ON f.valid=v.valid";
        $modelo = new conexion();
        $conexion = $modelo->get_conexion();
        $result = $conexion->prepare($sql);
        $result->execute();
        $res = $result->fetchAll(PDO::FETCH_ASSOC);
        return $res;
    }

    function save(){
        try {
            $sql = "INSERT INTO cama(florid) Values (:florid)";
            $modelo = new conexion();
            $conexion = $modelo->get_conexion();
            $result = $conexion->prepare($sql);
            $florid = $this->getFlorid();
            $result->bindParam(":florid", $florid);
            $result->execute();
        } catch (Exception $e) {
            ManejoError($e);
        }
    }

function getBxc($bloqid)
{
    $sql = "SELECT DISTINCT c.camid, f.desf, f.florid FROM cama AS c INNER JOIN flor AS f ON c.florid=f.florid INNER JOIN blqxcam AS b ON c.camid=b.camid WHERE b.bloqid=:bloqid";
    $modelo = new conexion();
    $conexion = $modelo->get_conexion();
    $result = $conexion->prepare($sql);
   
    $result->bindParam(":bloqid",$bloqid);
    $result->execute(); 
    $res = $result->fetchAll(PDO::FETCH_ASSOC);
        return $res; 
}
    function del(){
        try {
            $sql = "DELETE FROM cama WHERE camid=:camid";
            $modelo = new conexion();
            $conexion = $modelo->get_conexion();
            $result = $conexion->prepare($sql);
            $camid = $this->getCamid();
            $result->bindParam(":camid",$camid);
            $result->execute();
        } catch (Exception $e) {
            ManejoError($e);
        }
    }
    function getBxcama($bloqid)
{
    $sql = "SELECT bloqid, COUNT(camid) AS cant FROM blqxcam WHERE bloqid=:bloqid GROUP BY bloqid ;";
    $modelo = new conexion();
    $conexion = $modelo->get_conexion();
    $result = $conexion->prepare($sql);
   
    $result->bindParam(":bloqid",$bloqid);
    $result->execute(); 
    $res = $result->fetchAll(PDO::FETCH_ASSOC);
        return $res; 
}


}

?>





=SI(Y(C3 > 0;D3 > 0;E3 > 0);
    (C3*0,1)+(D3*0,15)+(E3*0,05);
    SI(Y(C3 = 0;D3 = 0);
        (E3 * 0,3);
        SI(Y(D3 > 0;E3 > 0);
            (D3 * 0,15)+(E3*0,15);
            SI(Y(D3 = 0; E3 = 0);
                C3*0,3;
                SI(Y(C3>0;D3>0);
                    (C3*0,15)+(D3*0,15);
                    SI(Y(C3>0;E3>0);
                        D3*0,3;0
                    )
                )
            )
        )
    )
)                









