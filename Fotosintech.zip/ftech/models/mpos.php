<?php
class Mpos
{
    private $cosecid;
    private $bloqid;
    private $fech;
    private $cant;
    private $florid;
    private $ncajas;
    private $tam;
    private $emp;
    private $perid;
    private $elival;
    // metodo get
    public function getCosecid()
    {
        return $this->cosecid;
    }
    public function getBloqid()
    {
        return $this->bloqid;
    }
    public function getFech()
    {
        return $this->fech;
    }
    public function getCant()
    {
        return $this->cant;
    }
    public function getFlorid()
    {
        return $this->florid;
    }
    public function getNcajas()
    {
        return $this->ncajas;
    }
    public function getTam()
    {
        return $this->tam;
    }
    public function getEmp()
    {
        return $this->emp;
    }
    public function getPerid()
    {
        return $this->perid;
    }
    public function getElival()
    {
        return $this->elival;
    }
    // metodo set
    public function setCosecid($cosecid)
    {
        $this->cosecid = $cosecid;
    }
    public function setBloqid($bloqid)
    {
        $this->bloqid = $bloqid;
    }
    public function setFech($fech)
    {
        $this->fech = $fech;
    }
    public function setCant($cant)
    {
        $this->cant = $cant;
    }
    public function setFlorid($florid)
    {
        $this->florid = $florid;
    }
    public function setNcajas($ncajas)
    {
        $this->ncajas = $ncajas;
    }
    public function setTam($tam)
    {
        $this->tam = $tam;
    }
    public function setEmp($emp)
    {
        $this->emp = $emp;
    }
    public function setPerid($perid)
    {
        $this->perid = $perid;
    }
    public function setElival($elival)
    {
        $this->elival = $elival;
    }

   public function getAll()
    {
        $sql = "SELECT p.cosecid, p.bloqid, p.fech, p.cant, p.florid, p.emp, p.ncajas, p.tam, p.perid, p.elival, f.desf, ps.ndper, ps.nomper, ps.apper, f.color, v.nomval FROM postcos AS p
            JOIN valor AS v ON p.emp = v.valid
            LEFT JOIN flor AS f ON p.florid=f.florid
            INNER JOIN persona AS ps ON p.perid=ps.perid";
        $modelo = new conexion();
        $conexion = $modelo->get_conexion();
        $result = $conexion->prepare($sql);
        $result->execute();
        $res = $result->fetchAll(PDO::FETCH_ASSOC);
        return $res;
    }

    public function getOne()
    {
        $sql = "SELECT p.cosecid, p.bloqid, p.fech, p.cant, p.florid, p.emp, p.ncajas, p.tam, p.perid, p.elival, ps.ndper, ps.nomper, f.color, f.desf FROM postcos AS p
            LEFT JOIN flor AS f ON p.florid=f.florid
            INNER JOIN persona AS ps ON p.perid=ps.perid WHERE cosecid=:cosecid;";
        $modelo = new conexion();
        $conexion = $modelo->get_conexion();
        $result = $conexion->prepare($sql);
        $cosecid = $this->getCosecid();
        $result->bindParam(':cosecid', $cosecid);
        $result->execute();
        $res = $result->fetchall(PDO::FETCH_ASSOC);
        return $res;
    }
    public function save()
    {
        try {
            $sql = "INSERT INTO postcos(bloqid, fech, cant, florid, ncajas, tam, emp, perid) VALUES (:bloqid, :fech,:cant,:florid,:ncajas,:tam,:emp, :perid)";
            $modelo = new conexion();
            $conexion = $modelo->get_conexion();
            $result = $conexion->prepare($sql);
            $bloqid = $this->getBloqid();
            $result->bindParam(':bloqid', $bloqid);
            $fech = $this->getFech();
            $result->bindParam(':fech', $fech);
            $cant = $this->getCant();
            $result->bindParam(':cant', $cant);
            $florid = $this->getFlorid();
            $result->bindParam(':florid', $florid);
            $ncajas = $this->getNcajas();
            $result->bindParam(':ncajas', $ncajas);
            $tam = $this->getTam();
            $result->bindParam(':tam', $tam);
            $emp = $this->getEmp();
            $result->bindParam(':emp', $emp);
            $perid = $_SESSION["perid"];
            $result->bindParam(":perid", $perid);
            $result->execute();
        } catch (Exception $e) {
            ManejoError($e);
        }
    }
    public function edit()
    {
        try {
            $sql = "UPDATE postcos SET bloqid=:bloqid, fech=:fech, cant=:cant, florid=:florid,ncajas=:ncajas, tam=:tam, emp=:emp, perid=:perid WHERE cosecid=:cosecid";
            $modelo = new conexion();
            $conexion = $modelo->get_conexion();
            $result = $conexion->prepare($sql);
            $cosecid = $this->getCosecid();
            $result->bindParam(":cosecid", $cosecid);
            $bloqid = $this->getBloqid();
            $result->bindParam(":bloqid", $bloqid);
            $fech = $this->getFech();
            $result->bindParam(":fech", $fech);
            $cant = $this->getCant();
            $result->bindParam(":cant", $cant);
            $florid = $this->getFlorid();
            $result->bindParam(":florid", $florid);
            $ncajas = $this->getNcajas();
            $result->bindParam(":ncajas", $ncajas);
            $tam = $this->getTam();
            $result->bindParam(":tam", $tam);
            $emp = $this->getEmp();
            $result->bindParam(":emp", $emp);
            $perid = $this->getPerid();
            $result->bindParam(":perid", $perid);
            $result->execute();
        } catch (Exception $e) {
            ManejoError($e);
        }
    }
    public function del()
    {
         try {
            $sql = "UPDATE postcos SET elival='1' WHERE cosecid = :cosecid";
            $modelo = new conexion();
            $conexion = $modelo->get_conexion();
            $result = $conexion->prepare($sql);
            $cosecid = $this->getCosecid();
            $result->bindParam(":cosecid", $cosecid);
            $result->execute();
        } catch (Exception $e) {
            ManejoError($e);
        }
    }
    public function Impr(){
		$sql = "SELECT 
        p.cant,
        p.florid,
        p.bloqid,
        p.perid,
        p.elival,
        p.ncajas,
        f.color,
        v.nomval,
        f.valid,
        f.desf,
        p.ncajas,
        p.fech,
        p.emp,
        ps.nomper,
        ps.apper,
        b.nombloq,
        SUM(p.cant*p.ncajas) AS tot_cant
    FROM 
        postcos AS p
    INNER JOIN 
        flor AS f 
    ON 
        p.florid = f.florid
    INNER JOIN persona AS ps ON p.perid=ps.perid
    INNER JOIN bloque AS b ON p.bloqid=b.bloqid
    JOIN valor AS v ON p.emp = v.valid
    WHERE 
        DATE(p.fech) = CURRENT_DATE
        AND p.elival = 0
    GROUP BY 
        p.cant,
        p.florid,
        p.bloqid,
        p.perid,
        f.color,
        f.desf,
        p.ncajas,
        p.fech,
        p.emp,
        ps.nomper,
        ps.apper,
        b.nombloq;
    
         ";
		$modelo = new conexion();
		$conexion = $modelo->get_conexion();
		$result = $conexion->prepare($sql);
		$result->execute();
		$res = $result->fetchall(PDO::FETCH_ASSOC);
		return $res;
	}
    
	public function Cant(){
		$sql = "SELECT 
        p.emp,v.nomval AS cant,
        SUM(ncajas) AS te
    FROM 
        postcos AS p
    JOIN valor AS v ON p.emp=v.valid 
    WHERE 
        DATE(fech) = CURRENT_DATE
        AND p.emp IN (
            SELECT 
                p.emp
            FROM 
                postcos
            WHERE 
                DATE(fech) = CURRENT_DATE
                AND elival = 0
            GROUP BY 
                p.emp
        )
    GROUP BY 
        p.emp;
        ";
		$modelo = new conexion();
		$conexion = $modelo->get_conexion();
		$result = $conexion->prepare($sql);
		$result->execute();
		$res = $result->fetchall(PDO::FETCH_ASSOC);
		return $res;
	}
    public function Total(){
		$sql = "SELECT 
        SUM(cant * ncajas) AS tot
    FROM 
        postcos
    WHERE 
        DATE(fech) = CURRENT_DATE
        AND emp IN (
            SELECT 
                emp
            FROM 
                postcos
            WHERE 
                DATE(fech) = CURRENT_DATE
                AND elival = 0
            GROUP BY 
                emp
        ); ";
		$modelo = new conexion();
		$conexion = $modelo->get_conexion();
		$result = $conexion->prepare($sql);
		$result->execute();
		$res = $result->fetchall(PDO::FETCH_ASSOC);
		return $res;
	}
    
    public function Emp(){
		$sql = "SELECT p.emp, v.nomval FROM postcos AS p JOIN valor AS v ON p.emp = v.valid; 
        ";
		$modelo = new conexion();
		$conexion = $modelo->get_conexion();
		$result = $conexion->prepare($sql);
		$result->execute();
		$res = $result->fetchall(PDO::FETCH_ASSOC);
		return $res;
	}
}
