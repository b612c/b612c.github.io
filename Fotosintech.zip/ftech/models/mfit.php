<?php
require_once 'conexion.php';
class Mfit{
	private $fitoid;
	private $tpfito;
	private $nomfito;
	private $empid;
	// Metodos Get 
	public function getEmpid(){
		return $this->empid;
	}
	public function getFitoid()
	{
		return $this->fitoid;
	}
	public function getTpfito()
	{
		return $this->tpfito;
	}
	public function getNomfito()
	{
		return $this->nomfito;
	}

	// Metodo set

	public function setFitoid($fitoid)
	{
		$this->fitoid = $fitoid;
	}
	public function setTpfito($tpfito)
	{
		$this->tpfito = $tpfito;
	}
	public function setNomfito($nomfito)
	{
		$this->nomfito = $nomfito;
	}
	public function setEmpid($Empid){
		$this->empid = $Empid;
	}
	public function getAll()
	{
    $sql = "SELECT fitoid, tpfito, nomfito 
            FROM fitopat"; 
    $modelo = new Conexion();
    $conexion = $modelo->get_conexion();
    $result = $conexion->prepare($sql);
    $result->execute();
    $res = $result->fetchAll(PDO::FETCH_ASSOC);
    return $res;
	}

	public function getOne()
	{
		$sql = "SELECT fitoid, tpfito, nomfito, empid FROM fitopat WHERE fitoid=:fitoid";
		$modelo = new Conexion();
		$conexion = $modelo->get_conexion();
		$result = $conexion->prepare($sql);
		$fitoid = $this->getFitoid();
		$result->bindParam(":fitoid", $fitoid);
		$result->execute();
		$res = $result->fetchAll(PDO::FETCH_ASSOC);
		return $res;
	}

	// Guardar
	public function save()
	{
		try{
			$sql = "INSERT INTO fitopat(tpfito, nomfito,empid ) VALUES (:tpfito, :nomfito, :empid)";
			$modelo = new conexion();
			$conexion = $modelo->get_conexion();
			$result = $conexion->prepare($sql);
			$tpfito = $this->getTpfito();
			$result->bindParam(":tpfito", $tpfito);
			$nomfito = $this->getNomfito();
			$result->bindParam(":nomfito", $nomfito);
			$empid = $this->getEmpid();
            $result->bindParam(":empid", $empid);
			$result->execute();
		}catch(Exception $e){
			ManejoError($e);
		  }
	}
	//    Editar
	public function edit()
	{
		try{
			$sql = "UPDATE fitopat SET tpfito = :tpfito, nomfito = :nomfito,  empid=:empid  WHERE fitoid = :fitoid";
			$modelo = new Conexion();
			$conexion = $modelo->get_conexion();
			$result = $conexion->prepare($sql);
			$fitoid = $this->getFitoid();
			$result ->bindParam(":fitoid",$fitoid);
			$tpfito = $this->getTpfito();
			$result->bindParam(":tpfito", $tpfito);
			$nomfito = $this->getNomfito();
			$result->bindParam(":nomfito", $nomfito);
			$empid = $this->getEmpid();
            $result->bindParam(":empid", $empid);
			$result->execute();
		}catch(Exception $e){
			ManejoError($e);
		  }
	}
	// Eliminar
	function del()
	{
		try{
			$sql = "DELETE FROM fitopat WHERE fitoid = :fitoid";
			$modelo = new conexion();
			$conexion = $modelo->get_conexion();
			$result = $conexion->prepare($sql);
			$fitoid = $this->getFitoid();
			$result->bindParam(":fitoid",$fitoid);
			$result->execute();
		}catch(Exception $e){
			ManejoError($e);
		  }
	}
	function getFxq($fitoid)
	{
		$res = NULL;
		$modelo = new conexion();
		$conexion = $modelo->get_conexion();
		$sql = "SELECT COUNT(quimid) AS qui FROM quimico WHERE fitoid=:fitoid";
		$result = $conexion->prepare($sql);

		$result->bindParam(":fitoid", $fitoid);
		$result->execute();
		$res = $result->fetchAll(PDO::FETCH_ASSOC);
		return $res;
	}
	
function getQxf($fitoid)
{
    $sql = "SELECT f.fitoid,f.nomfito,q.quimid,q.nomquim FROM fitopat AS f INNER JOIN quimico AS q ON f.fitoid=q.fitoid WHERE f.fitoid=:fitoid;";
    $modelo = new conexion();
    $conexion = $modelo->get_conexion();
    $result = $conexion->prepare($sql);

    $result->bindParam(":fitoid",$fitoid);
    $result->execute(); 
    $res = $result->fetchAll(PDO::FETCH_ASSOC);
        return $res; 
}
}
?>