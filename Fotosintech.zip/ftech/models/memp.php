<?php
    class Memp{
        private $empid;
        private $ubid;
        private $nemp;
        private $nitemp;
        private $diremp;
        private $email;
        private $tel;
        private $logo;


        public function getEmpid(){
            return $this->empid;
        }
        public function getUbid(){
            return $this->ubid;
        }
        public function getNemp(){
            return $this->nemp;
        }
        public function getNitemp(){
            return $this->nitemp;
        }
        public function getDiremp(){
            return $this->diremp;
        }
        public function getEmail(){
            return $this->email;
        }
        public function getTel(){
            return $this->tel;
        }
        public function getLogo(){
            return $this->logo;
        }

        public function setEmpid($empid){
            $this->empid = $empid;
        }
        public function setUbid($ubid){
            $this->ubid = $ubid;
        }
        public function setNemp($nemp){
            $this->nemp = $nemp;
        }
        public function setNitemp($nitemp){
            $this->nitemp = $nitemp;
        }
        public function setDiremp($diremp){
            $this->diremp = $diremp;
        }
        public function setEmail($email){
            $this->email = $email;
        }
        public function setTel($tel){
            $this->tel = $tel;
        }
        public function setLogo($logo){
            $this->logo = $logo;
        }

        public function getAll(){
            $sql = "SELECT e.empid, e.ubid, e.nemp, e.nitemp, e.diremp, e.email, e.tel, e.logo, u.nomubi FROM empresa AS e INNER JOIN ubicacion AS u ON e.ubid=u.ubid";
            $modelo = new conexion();
            $conexion = $modelo->get_conexion();
            $result = $conexion->prepare($sql);
            $result->execute();
            $res = $result->fetchall(PDO::FETCH_ASSOC);
            return $res;
        }

        public function getOne(){
            $sql = "SELECT e.empid, e.ubid, e.nemp, e.nitemp, e.diremp, e.email, e.tel, e.logo, u.nomubi, u.depubi FROM empresa AS e INNER JOIN ubicacion AS u ON e.ubid=u.ubid WHERE empid=:empid";
            $modelo = new conexion();
            $conexion = $modelo->get_conexion();
            $result = $conexion->prepare($sql);
            $empid = $this->getEmpid();
            $result->bindParam(":empid", $empid);
            $result->execute();
            $res = $result->fetchall(PDO::FETCH_ASSOC);
            return $res;
        }

        function save(){
            try {
                $sql = "INSERT INTO empresa(ubid, nemp, nitemp, diremp, email, tel, logo) Values (:ubid, :nemp, :nitemp, :diremp, :email, :tel, :logo)";
                $modelo = new conexion();
                $conexion = $modelo->get_conexion();
                $result = $conexion->prepare($sql);
                $ubid = $this->getUbid();
                $result->bindParam(":ubid", $ubid);
                $nemp = $this->getNemp();
                $result->bindParam(":nemp", $nemp);
                $nitemp = $this->getNitemp();
                $result->bindParam(":nitemp", $nitemp);
                $diremp = $this->getDiremp();
                $result->bindParam(":diremp", $diremp);
                $email = $this->getEmail();
                $result->bindParam(":email", $email);
                $tel = $this->getTel();
                $result->bindParam(":tel", $tel);
                $logo = $this->getLogo();
                $result->bindParam(":logo", $logo);
                $result->execute();
            } catch (Exception $e) {
                ManejoError($e);
            }
        }
        
        function edit(){
            try {
                $sql = "UPDATE empresa SET ubid=:ubid, nemp=:nemp, nitemp=:nitemp, diremp=:diremp, email=:email, tel=:tel";
                    if($this->getLogo()) $sql .= ", logo=:logo";
                $sql .= " WHERE empid=:empid";
                $modelo = new conexion();
                $conexion = $modelo->get_conexion();
                $result = $conexion->prepare($sql);
                $empid = $this->getEmpid();
                $result->bindParam(":empid", $empid);
                $ubid = $this->getUbid();
                $result->bindParam(":ubid", $ubid);
                $nemp = $this->getNemp();
                $result->bindParam(":nemp", $nemp);
                $nitemp = $this->getNitemp();
                $result->bindParam(":nitemp", $nitemp);
                $diremp = $this->getDiremp();
                $result->bindParam(":diremp", $diremp);
                $email = $this->getEmail();
                $result->bindParam(":email", $email);
                $tel = $this->getTel();
                $result->bindParam(":tel", $tel);
                if($this->getLogo()){
                    $logo = $this->getLogo();
                    $result->bindParam(":logo", $logo);
                }
                $result->execute();
            } catch (Exception $e) {
                ManejoError($e);
            }
        }

        function del(){
            try {
                $sql = "DELETE FROM empresa WHERE empid=:empid";
                $modelo = new conexion();
                $conexion = $modelo->get_conexion();
                $result = $conexion->prepare($sql);
                $empid = $this->getEmpid();
                $result->bindParam(":empid", $empid);
                $result->execute();
            } catch (Exception $e) {
                ManejoError($e);
            }
        }
    }


?>