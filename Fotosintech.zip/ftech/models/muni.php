<?php
require_once 'conexion.php';
class Muni{
	function getMun($muni){
		$sql = "SELECT ubid, nomubi, depubi, estubi, cddubi FROM ubicacion WHERE depubi='".$muni."' ORDER BY nomubi";
		$modelo = new conexion();
		$conexion = $modelo->get_conexion();
		$result = $conexion->prepare($sql);
		$result->execute();
		$res = $result-> fetchall(PDO::FETCH_ASSOC);
		return $res;
	}
}
?>