<?php
class Mbloq{
    private $bloqid;
    private $nombloq;
    private $empid;

    public function getBloqid(){
        return $this->bloqid;
    }    
    public function getNombloq(){
        return $this->nombloq;
    }
    public function getEmpid(){
        return $this->empid;
    }

    public function setBloqid($bloqid){
        $this->bloqid = $bloqid;
    }    
    public function setNombloq($nombloq){
        $this->nombloq = $nombloq;
    }
    public function setEmpid($empid){
        $this->empid = $empid;
    }

    function getAll(){
        $sql = "SELECT b.bloqid, b.nombloq, b.empid, e.nemp, COUNT(bc.camid) AS can FROM bloque AS b LEFT JOIN blqxcam AS bc ON b.bloqid=bc.bloqid INNER JOIN empresa AS e ON b.empid=e.empid GROUP BY bloqid ORDER BY bloqid";
        $modelo = new conexion();
        $conexion = $modelo->get_conexion();
        $result = $conexion->prepare($sql);
        $result->execute();
        $res = $result->fetchAll(PDO::FETCH_ASSOC);
        return $res;
    }

    function save(){
        try {
            $sql = "INSERT INTO bloque(nombloq, empid) Values (:nombloq, :empid)";
            $modelo = new conexion();
            $conexion = $modelo->get_conexion();
            $result = $conexion->prepare($sql);
            $nombloq = $this->getNombloq();
            $result->bindParam(":nombloq", $nombloq);
            $empid = $this->getEmpid();
            $result->bindParam(":empid", $empid);
            $result->execute();
            return $conexion->lastInsertId();
        } catch (Exception $e) {
            ManejoError($e);
        }
    }

    function saveBxC($bloqid, $camid){
        try {
            $sql = "INSERT INTO blqxcam(bloqid, camid) Values (:bloqid, :camid)";
            $modelo = new conexion();
            $conexion = $modelo->get_conexion();
            $result = $conexion->prepare($sql);
            $result->bindParam(":bloqid", $bloqid);
            $result->bindParam(":camid", $camid);
            $result->execute();
            return $conexion->lastInsertId();
        } catch (Exception $e) {
            ManejoError($e);
        }
    }

    function del(){
        try {
            $sql = "DELETE FROM bloque WHERE bloqid=:bloqid";
            $modelo = new conexion();
            $conexion = $modelo->get_conexion();
            $result = $conexion->prepare($sql);
            $bloqid = $this->getBloqid();
            $result->bindParam(":bloqid",$bloqid);
            $result->execute();
        } catch (Exception $e) {
            ManejoError($e);
        }
    }
    function delBxc(){
        $sql = "DELETE FROM blqxcam WHERE bloqid=:bloqid";
        $modelo = new conexion();
        $conexion = $modelo->get_conexion();
        $result = $conexion->prepare($sql);
        $bloqid = $this->getBloqid();
        $result->bindParam(":bloqid",$bloqid);
        $result->execute();
    }


}

?>