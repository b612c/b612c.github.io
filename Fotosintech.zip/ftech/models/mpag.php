<?php
class Mpag{
	//Atributos Pagina
	private $pagid;
	private $modid;
	private $editpagid;
	private $pagnom;
	private $pagarc;
	private $pagmos;
	private $pagord;
	private $pagmen;
	private $icono;

	//Metodo Get
	function getPagid(){
		return $this->pagid;
	}
	function getModid(){
		return $this->modid;
	}
	public function getEditpagid(){
        return $this->editpagid;
    }
	function getPagnom(){
		return $this->pagnom;
	}
	function getPagarc(){
		return $this->pagarc;
	}
	function getPagmos(){
		return $this->pagmos;
	}
	function getPagord(){
		return $this->pagord;
	}
	function getPagmen(){
		return $this->pagmen;
	}
	function getIcono(){
		return $this->icono;
	}

	//Metodo Set
	function setPagid($pagid){
		$this->pagid = $pagid;
	}
	function setModid($modid){
		$this->modid = $modid;
	}
	public function setEditpagid($editpagid){
        $this->editpagid = $editpagid;
    }
	function setPagnom($pagnom){
		$this->pagnom = $pagnom;
	}
	function setPagarc($pagarc){
		$this->pagarc = $pagarc;
	}
	function setPagmos($pagmos){
		$this->pagmos = $pagmos;
	}
	function setPagord($pagord){
		$this->pagord = $pagord;
	}
	function setPagmen($pagmen){
		$this->pagmen = $pagmen;
	}
	function setIcono($icono){
		$this->icono = $icono;
	}

	public function getAll(){
		$sql = "SELECT p.pagid, p.pagnom, p.pagarc, p.pagmos, p.pagord, p.pagmen, p.icono, p.modid, m.nomod FROM pagina AS p INNER JOIN modulo AS m ON m.modid=p.modid ORDER BY pagord" ;
		$modelo = new conexion();
        $conexion = $modelo->get_conexion();
        $result = $conexion->prepare($sql);
        $result->execute();
        $res = $result->fetchAll(PDO::FETCH_ASSOC);
        return $res;
	}

	public function getAllMos(){
		$sql = "SELECT p.pagid, p.pagnom, p.pagarc, p.pagmos, p.pagord, p.pagmen, p.icono, p.modid FROM pagina AS p WHERE p.pagmos=1";
		$modelo = new conexion();
        $conexion = $modelo->get_conexion();
        $result = $conexion->prepare($sql);
        $result->execute();
        $res = $result->fetchAll(PDO::FETCH_ASSOC);
        return $res;
	}
	public function getOne(){
		$sql = "SELECT pagid, pagnom, pagarc, pagmos, pagord, pagmen, icono, modid FROM pagina WHERE pagid=:pagid";
		$modelo = new conexion();
        $conexion = $modelo->get_conexion();
        $result = $conexion->prepare($sql);
        $pagid = $this->getPagid();
        $result->bindParam(":pagid", $pagid);
        $result->execute();
        $res = $result->fetchAll(PDO::FETCH_ASSOC);
        return $res;
	}

	public function getOneId(){
		$sql = "SELECT pagid, pagnom, pagarc, pagmos, pagord, pagmen, icono, modid FROM pagina WHERE pagid=:pagid";
		$modelo = new conexion();
        $conexion = $modelo->get_conexion();
        $result = $conexion->prepare($sql);
        $pagid = $this->getPagid();
        $result->bindParam(":pagid", $pagid);
        $result->execute();
        $res = $result->fetchAll(PDO::FETCH_ASSOC);
        return $res;
	}

	public function save(){
		try {
			$sql = "INSERT INTO pagina (pagid, pagnom, pagarc, pagmos, pagord, pagmen, icono, modid) VALUES (:pagid, :pagnom, :pagarc, :pagmos, :pagord, :pagmen, :icono, :modid)";

			$modelo = new conexion();
			$conexion = $modelo->get_conexion();
			$result = $conexion->prepare($sql);

			$pagid = $this->getPagid();
			$result->bindParam(":pagid", $pagid);
			$pagnom = $this->getPagnom();
			$result->bindParam(":pagnom", $pagnom);
			$pagarc = $this->getPagarc();
			$result->bindParam(":pagarc", $pagarc);
			$pagmos = $this->getPagmos();
			$result->bindParam(":pagmos", $pagmos);
			$pagord = $this->getPagord();
			$result->bindParam(":pagord", $pagord);
			$pagmen = $this->getPagmen();
			$result->bindParam(":pagmen", $pagmen);
			$icono = $this->getIcono();
			$result->bindParam(":icono", $icono);
			$modid = $this->getModid();
			$result->bindParam(":modid", $modid);
			$result->execute();
		} catch (Exception $e) {
            ManejoError($e);
        }
	}

	public function edit(){
		$sql = "UPDATE pagina SET pagid=:pagid, pagnom=:pagnom, pagarc=:pagarc, pagmos=:pagmos, pagord=:pagord, pagmen=:pagmen, icono=:icono, modid=:modid WHERE pagid=:editpagid";
		$modelo = new conexion();
		$conexion = $modelo->get_conexion();
		$result = $conexion->prepare($sql);
		$pagid = $this->getPagid();
		$result->bindParam(":pagid", $pagid);
		$editpagid = $this->getEditpagid();
		$result->bindParam(":editpagid", $editpagid);
		$pagnom = $this->getPagnom();
		$result->bindParam(":pagnom", $pagnom);
		$pagarc = $this->getPagarc();
		$result->bindParam(":pagarc", $pagarc);
		$pagmos = $this->getPagmos();
		$result->bindParam(":pagmos", $pagmos);
		$pagord = $this->getPagord();
		$result->bindParam(":pagord", $pagord);
		$pagmen = $this->getPagmen();
		$result->bindParam(":pagmen", $pagmen);
		$icono = $this->getIcono();
		$result->bindParam(":icono", $icono);
		$modid = $this->getModid();
		$result->bindParam(":modid", $modid);
		$result->execute();
	}

	public function edmos(){
		$sql = "UPDATE pagina SET pagmos=:pagmos WHERE pagid=:pagid";
		$modelo = new conexion();
		$conexion = $modelo->get_conexion();
		$result = $conexion->prepare($sql);
		$pagid = $this->getPagid();
		$result->bindParam(":pagid", $pagid);
		$pagmos = $this->getPagmos();
		$result->bindParam(":pagmos", $pagmos);
		$result->execute();
		$res = $result->fetchAll(PDO::FETCH_ASSOC);
		return $res;
	}
	public function del(){
		try {
			$sql = "DELETE FROM pagina WHERE pagid=:pagid";
			$modelo = new conexion();
			$conexion = $modelo->get_conexion();
			$result = $conexion->prepare($sql);
			$pagid = $this->getPagid();
			$result->bindParam(":pagid", $pagid);
			$result->execute();
		} catch (Exception $e) {
			ManejoError($e);
		}

	}
	public function getMod(){

		$result = NULL;
		$modelo = new conexion();
		$conexion = $modelo->get_conexion();

		$sql = "SELECT modid, nomod, imgmod, pagid FROM modulo";

		$result = $conexion->prepare($sql);
		$result->execute();
		return $result->fetchall(PDO::FETCH_ASSOC);
	}
	public function getPrf($pagid){
		$modelo = new conexion();
		$conexion = $modelo->get_conexion();

		$sql = "SELECT COUNT(pagid) AS can FROM pgxpef WHERE pagid=:pagid";

		$result = $conexion->prepare($sql);
		$result->bindParam(":pagid", $pagid);
		$result->execute();

		return $result->fetchAll(PDO::FETCH_ASSOC);
	}
	public function getPxP($pagid){
		$modelo = new conexion();
		$conexion = $modelo->get_conexion();
		$sql = "SELECT COUNT(pefid) AS cans FROM perfil WHERE pagid=:pagid";
		$result = $conexion->prepare($sql);
		$result->bindParam(":pagid", $pagid);
		$result->execute();
		return $result->fetchAll(PDO::FETCH_ASSOC);
	}
	public function getTbl(){
		$sql = "SELECT m.modid, m.nomod, p.pagid, p.pagnom FROM modulo AS m LEFT JOIN pagina AS p ON p.modid = m.modid ORDER BY m.modid;";
		$modelo = new Conexion();
		$conexion = $modelo->get_conexion();
		$result = $conexion->prepare($sql);
		$result->execute();
		$res = $result->fetchAll(PDO::FETCH_ASSOC);
		return $res;
	}
}
?>