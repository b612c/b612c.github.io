<?php 
class Mval{
    private $valid;
    private $domid;
    private $nomval;
    private $parval;
    private $actval;
    public function getValid(){
        return $this->valid;    
    }
    public function getDomid(){
        return $this->domid;    
    }
    public function getNomval(){
        return $this->nomval;    
    }
    public function getParval(){
        return $this->parval;    
    }
    public function getActval(){
        return $this->actval;    
    }
    public function setValid($valid){
         $this->valid = $valid;    
    }
    public function setDomid($domid){
         $this->domid = $domid;    
    }
    public function setNomval($nomval){
         $this->nomval = $nomval;    
    }
    public function setParval($parval){
        $this->parval = $parval;    
    }
   public function setActval($actval){
        $this->actval = $actval;    
    }
    function getAll(){
        $sql = "SELECT v.valid, v.domid, v.nomval, v.parval, v.actval, d.nomd FROM valor as v INNER JOIN dominio as d on v.domid = d.domid";
        $modelo = new conexion();
        $conexion = $modelo->get_conexion();
        $result = $conexion->prepare($sql);
        $result->execute();
        $res = $result->fetchall(PDO::FETCH_ASSOC);
        return  $res;
    }
    function getOne(){
        $sql = "SELECT valid, domid, nomval, parval, actval  FROM valor WHERE valid=:valid";
        $modelo = new conexion();
        $conexion = $modelo->get_conexion();
        $result = $conexion->prepare($sql);
        $valid = $this->getValid();
        $result->bindParam(":valid",$valid);
        $result->execute();
        $res = $result->fetchall(PDO::FETCH_ASSOC);
        return  $res;
    }
    function save(){
        try {
            $sql = "INSERT INTO valor(domid, nomval, parval, actval)VALUES(:domid, :nomval, :parval, :actval)";
            $modelo = new conexion();
            $conexion = $modelo->get_conexion();
            $result = $conexion->prepare($sql);
            $domid = $this->getDomid();
            $result->bindParam(":domid",$domid);
            $nomval = $this->getNomval();
            $result->bindParam(":nomval",$nomval);
            $parval = $this->getParval();
            $result->bindParam(":parval",$parval);
            $actval = $this->getActval();
            $result->bindParam(":actval",$actval);
            $result->execute();
        } catch (Exception $e) {
            ManejoError($e);
        }
    }
    function edit(){
        $sql = "UPDATE valor SET domid=:domid, nomval=:nomval, parval=:parval, actval=:actval WHERE valid=:valid";
        $modelo = new conexion();
        $conexion = $modelo->get_conexion();
        $result = $conexion->prepare($sql);
        $valid = $this->getValid();
        $result->bindParam(":valid",$valid);
        $domid = $this->getDomid();
        $result->bindParam(":domid",$domid);
        $nomval = $this->getNomval();
        $result->bindParam(":nomval",$nomval);
        $parval = $this->getParval();
        $result->bindParam(":parval",$parval);
        $actval = $this->getActval();
        $result->bindParam(":actval",$actval);
        $result->execute();
    }
    public function del(){
        try {
            $sql = "DELETE FROM valor WHERE valid=:valid";
            $modelo = new conexion();
            $conexion = $modelo->get_conexion();
            $result = $conexion-> prepare($sql);
            $valid = $this->getValid();
            $result->bindParam(":valid",$valid);
            $result->execute();
        } catch (Exception $c) {
            ManejoError($c);
        }
    }
    function Actval(){
        $sql = "UPDATE valor SET actval=:actval WHERE valid=:valid";
        $modelo = new conexion();
        $conexion = $modelo->get_conexion();
        $result = $conexion->prepare($sql);
        $valid = $this->getValid();
        $result->bindParam(":valid",$valid);
        $actval = $this->getActval();
        $result->bindParam(":actval",$actval);
        $result->execute();
    }

}
?>