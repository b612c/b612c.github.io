<?php
include('controllers/cmod.php');
?>
<div class="content">
	<div style="display: inline-block !important;width: 100%;">
		<form class="formulario" id="omfg" action="home.php?pg=701" method="POST" enctype="multipart/form-data">
			<div class="row">
				<div class="form-group col-md-6">
				<label for="nomod">Nombre Módulo:</label>
				<input class="form-control" type="text" id="nomod" name="nomod" value="<?php if($datOne) echo $datOne[0]['nomod']; ?>" required>
				</div>
				<div class="form-group col-md-6">
					<label for="arcimg">Imagen:</label>
					<input class="form-control" type="file" id="arcimg" name="arcimg" accept="image/jpeg, image/png, image/gif">
				</div>
				<div class="form-group col-md-6">
					<label for="actmod" class="titulo">Activar:</label>
					<select name="actmod" id="actmod" class="form form-select" value="<?php if ($datOne && $datOne['actmod'] == 1)
							echo 'Si';
								elseif ($datOne && $datOne['actmod'] == 2)
							echo 'No'; ?>" required>
						<option value="none" selected disabled hidden>Selecione una opción</option>
						<option value="1" <?php if($datOne && $datOne[0]['actmod']==1)
							echo ' selected '; ?>>Si</option>
						<option value="2" <?php if(!$datOne || ($datOne && $datOne[0]['actmod']!=1))
							echo ' selected '; ?>>No</option>
					</select>
				</div>
				<div class="form-group col-md-6">
					<label for="pagid">Página:</label>
					<select name="pagid" id="pagid" class="form form-select" required>
    		        <?php if($datPag){foreach($datPag AS $dpg){?>
    		          	<option value="<?=$dpg['pagid'];?>" <?php if($datOne && $dpg['pagid']==$datOne[0]['pagid']) 
    		              	echo " selected ";?>><?=$dpg['pagnom'];?>
    		          	</option>
    		        <?php }}?>
    		      	</select>
				</div>
				<div class="form-group col-md-12 text-center">
					<br><br>
					<button type="submit" value="Registrar"  class="btn btn-prin col-12 col-sm-4 col-lg-3"><?= $ope == "edit" ? "Actualizar" : "Registrar" ?></button>
					<input type="hidden" name="ope" value="save">
					<input type="hidden" name="modid" value="<?php if($datOne) echo $datOne[0]['modid']; ?>">
				</div>
			</div>
		</form>
	</div>

	<table id="mytable" class="table w-full table-striped dt-responsive">
		<thead>
			<tr>
				<th scope="col"></th>
				<th scope="col">Módulo</th>
				<th scope="col">Activar</th>
				<th scope="col"></th>
				<th scope="col"></th>
			</tr>
		</thead>
		<tbody>
			<?php if($datAll)  {
				foreach($datAll as $dta) { ?>
			<tr>
				<td width="170px">
					<?php if(file_exists($dta['imgmod'])) { ?>
						<img src="<?=$dta['imgmod'];?>" alt="Logo módulo <?=$dta['nomod'];?>" style="width: 150px; height: 150px;">
					<?php }else{ ?>
						<img src="img\noimage.png" style="width: 150px; height: 150px;">
					<?php } ?>
				</td>
				<td>
					<BIG><strong><?= $dta['modid'] . " - " . $dta['nomod']; ?></strong></BIG><br><strong>Página Principal: </strong><?= $dta['pagnom']; ?>
				</td>
				<td>
					<?php if($dta['actmod']==1) { ?>
						<a class="form-boton" type="button" href="home.php?pg=701&modid=<?=$dta['modid'];?>&ope=act&actmod=2">
							<i class="fa-solid fa-circle-check fa-2x" style="color:#00bb00;"></i>
						</a>
					<?php }else{ ?>
						<a class="form-boton" type="button" href="home.php?pg=701&modid=<?=$dta['modid'];?>&ope=act&actmod=1">
							<i class="fa-solid fa-circle-xmark fa-2x" style="color:#f00;"></i>
						</a>
					<?php } ?>
				</td>
				 <td style="text-align: right;">
				 	<a class="edi" type="button" href="home.php?pg=701&modid=<?= $dta['modid']; ?>&ope=edit">
						<i class="fa fa-pen"></i>
					</a>
					<?php 
						$ct = $mmod->getMxP($dta['modid']);
					?>
					<button class="form-boton eli" title="Borrar" onclick="alertaSuave('home.php?pg=701&modid=<?= $dta['modid'];?>&ope=del')" type="button" <?php if ($ct && $ct[0]['can'] !=0) echo ('disabled style="background:#49459c50;"') ?>>
						<i class="fa fa-trash-can"></i>
					</button>
				 </td>
				 <td></td>
			</tr>
			<?php } 
				} ?>
		</tbody>
		<tfoot>
			<tr>
				<th scope="col"></th>
				<th scope="col">Módulo</th>
				<th scope="col">Activar</th>
				<th scope="col"></th>
				<th scope="col"></th>
			</tr>
		</tfoot>
	</table>
</div>