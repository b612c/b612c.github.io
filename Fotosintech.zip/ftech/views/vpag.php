<?php 
require_once ('controllers/cpag.php');
?>

<div class="content">
	<div class="insert" style="display: inline-block !important; width: 100%;">
		<form action="home.php?pg=501" class="formulario" id="omfg" method="POST">
			<div class="row">
				<div class="form-group col-md-6">
					<label for="pagid">Id Pagina</label>
					<input type="text" name="pagid" id="pagid" maxlength="70" placeholder="Id de la pagina" class="form-control" value="<?php if($datOne) echo $datOne[0]['pagid']; ?>" required>
				</div>

				<div class="form-group col-md-6">
					<label for="pagnom">Nombre de la Pagina</label>
					<input type="text" name="pagnom" id="pagnom" maxlength="70" placeholder="Nombre de la pagina" class="form-control" value="<?php if($datOne) echo $datOne[0]['pagnom']; ?>" required>
				</div>

				<div class="form-group col-md-6">
					<label for="pagarc">Ruta</label>
					<input type="text" name="pagarc" id="pagarc" maxlength="70" placeholder="" class="form-control" value="<?php if($datOne) echo $datOne[0]['pagarc']; ?>" required>
				</div>

				<div class="form-group col-md-6">
					<label for="pagmos">Mostrar</label>
					<select name="pagmos" id="pagmos" class="form-select" onchange="showHideDiv()">
                        <option value="1" <?php if ($datOne && $datOne[0]['pagmos'] == 1) echo " selected "; ?>>Mostrar</option>
                        <option value="2" <?php if ($datOne && $datOne[0]['pagmos'] == 2) echo " selected "; ?>>No mostrar</option>
                    </select>
				</div>

				<div id="icon" class="form-group col-md-6">
					<label for="arcimg">Icono</label>
					<input class="form-control" type="file" id="arcimg" name="arcimg" accept="image/jpeg, image/png, image/gif">
				</div>

				<script>
					function showHideDiv(){
						var select = document.getElementById("pagmos");
						var div = document.getElementById("icon");
						if(select.value === "1") {
							div.style.display = "block";
						}else{
							div.style.display = "none";
						}
					}
				</script>

				<div class="form-group col-md-6">
					<label for="modid">Módulo</label>
					<select name="modid" id="modid" class="form-select">
						<?php if ($datmod) {
							foreach ($datmod as $dtm) { ?>
								<option value="<?= $dtm['modid']; ?>" <?php if ($datOne && $datOne[0]['modid'] == $dtm['modid']) echo " selected "; ?>><?= $dtm['nomod']; ?></option>
						<?php }
						} ?>
					</select>
				</div>

				<div class="form-group col-md-6">
					<label for="pagord">Ordenar</label>
					<input type="number" name="pagord" id="pagord" maxlength="70" placeholder="Orden de pagina" class="form-control" value="<?php if($datOne) echo $datOne[0]['pagord']; ?>" required>
				</div>


				<div class="form-group col-md-6">
					<label for="pagmen">Ruta a menu</label>
					<input type="text" name="pagmen" id="pagmen" maxlength="70" placeholder="home.php" class="form-control" value="<?php if($datOne) echo $datOne[0]['pagmen']; ?>" required>
				</div>

				<br>
				<div class="mybtn form-group col-md-12 text-center">
					<button type="submit" value="Registrar"  class="btn btn-prin col-12 col-sm-4 col-lg-3"><?= $ope == "edit" ? "Actualizar" : "Registrar" ?></button>
					<input type="hidden" name="ope" value="save">
					<input type="hidden" name="editpagid" value="<?php if ($datOne) echo $datOne[0]['pagid'];?>">
				</div>
			</div>
		</form>
	</div>
	<table id="example" class="table w-full table-striped dt-responsive">
		<thead>
			<tr>
				<th scope="col">Icono</th>
				<th scope="col">Página</th>
				<th scope="col">Ordenar</th>
				<th scope="col">Mostrar</th>
				<th scope="col"></th>
				<th></th>
			</tr>
		</thead>
		<tbody>
			<?php if ($datAll) { 
				foreach ($datAll as $dta) { ?>
					<tr>
						<td>
							<?php if ( $dta['pagmos']==1) { ?>
									<img src="img/icon/<?=$dta['icono'];?>" style="width: 35px; height: 35px;">
							<?php } elseif ($dta['pagmos']== 2) { ?>
									<i class="<?=$dta['icono'];?> fa-2x"></i>
							<?php } else echo "Valor de act no válido"; ?>
						</td>
						<td style="width: 20%;"> 
							<strong><?= $dta['pagid'] . " - " . $dta['pagnom']; ?></strong><br>
							<small>
								<strong>Ruta: </strong> <?= $dta['pagarc']; ?>
							</small>
						</td>
						<td>
                            <?= $dta['pagord']; ?><br>
                        </td>
                        <td style="text-align: left;">
                            <?php if ($dta['pagmos'] == 1) { ?>
                            	<a class="form-boton" type="button" href="home.php?pg=501&pagid=<?=$dta['pagid'];?>&ope=mos&pagmos=2">
                            		<i class="fa-solid fa-circle-check fa-2x" style="color:#00bb00;"></i>
                            	</a>
                            <?php } else { ?>
                            	<a class="form-boton" type="button" href="home.php?pg=501&pagid=<?=$dta['pagid'];?>&ope=mos&pagmos=1">
                            		<i class="fa-solid fa-circle-xmark fa-2x" style="color:#f00;"></i>
                            	</a>
                            <?php } ?>
                        </td>

                        <td style="text-align: right;">
                            <a class="edi" type="button" href="home.php?pg=501&editpagid=<?= $dta['pagid'] ?>&ope=edit">
                                <i class="fa fa-pencil"></i>
                            </a>
                            <?php
								$pf = $mpag->getPrf($dta['pagid']);
								$pxp = $mpag->getPxP($dta['pagid']);
							?>
							<a>
								<button class="form-boton eli" title="Eliminar" onclick="alertaSuave('home.php?pg=501&pagid=<?= $dta['pagid'] ?>&ope=delete')" type="button" <?php if ($pf && $pf[0]['can'] != 0) echo ('disabled style="background:#49459c50;"') ?>    
								<?php if ($pxp && $pxp[0]['cans'] != 0) echo ('disabled style="background:#49459c50;"') ?>>
									<i class="fa fa-trash-can"></i>
								</button>
							</a>
                        </td>
                        <td></td>
					</tr>
			<?php } 
			} ?>
		</tbody>
		<tfoot>
			<tr>
				<th scope="col">Icono</th>
				<th scope="col">Página</th>
				<th scope="col">Ordenar</th>
				<th scope="col">Mostrar</th>
				<th scope="col"></th>
				<th></th>
			</tr>
		</tfoot>
	</table>
</div>
