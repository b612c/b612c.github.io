<?php
require_once("controllers/cpos.php");


$pg = $_GET['pg'] ?? '';

?>

<div class="content">
  <section style="display: inline-block !important;width: 100%;">
    <form action="home.php?pg=<?=$pg;?>" role="form" style="align-items: left;" id="omfg" method="POST"> 
        <fieldset>
          <div class="row">
          <div class="form-group col-md-6">
              <label class="form-label" for="bloqid">Bloque</label>
              <select name="bloqid" id="bloqid" onChange="recVariedad(this.value)" class="form form-select" value="<?php if ($datOne) echo $datOne[0]['bloqid']; ?>" >
              <?php if ($datMbloq) {
                foreach ($datMbloq as $dmt) { ?>
                  <option value="<?= $dmt['bloqid']; ?>" <?php if ($datOne && $dmt['bloqid'] == $datOne[0]['bloqid']) echo "selected"; ?>> <?= $dmt['nombloq']." ".$dmt['bloqid']; ?>
                  </option>
              <?php }
              } ?>
              </select>
            </div>
            <div class="form-group col-md-6"> 
                <label class="form-label" for="tam">Selecciona longitud de la flor:</label>
                <select name="tam" id="tam" class="form-select">
                  <?php if ($datVal) {
                    foreach ($datVal as $dtv) {
                      if ($dtv['domid'] == 204) { ?>
                        <option value="<?= $dtv['valid']; ?>" <?php if ($datOne && $dtv['valid'] == $datOne[0]['tam']) echo 'selected'; ?>>
                          <?= $dtv['nomval']; ?>
                        </option>
                  <?php }
                    }
                  }; ?>
                </select>
            </div>
            <div class="form-group col-md-6"> 
                <label class="form-label" for="emp"> Tipo de Empaque</label>
                <select name="emp" id="emp" class="form-select">
                <?php if ($datVal) {
                  foreach ($datVal as $dtv) {
                    if ($dtv['domid'] == 101) { ?>
                      <option value="<?= $dtv['valid']; ?>" <?php if ($datOne && $dtv['valid'] == $datOne[0]['emp']) echo 'selected'; ?>>
                        <?= $dtv['nomval']; ?>
                      </option>
                <?php }
                  }
                }; ?>
              </select>
            </div>
                  
            <div class="form-group col-md-6">
                <label class="form-label"for="ncajas" id="cantidadDeLabel">Cantidad De</label>
                <input type="number" name="ncajas" id="ncajas" class="form-control" value="<?php if ($datOne) echo $datOne[0]['ncajas']; ?>" >
            </div>
                  
            <div class="form-group col-md-6">
                <label class="form-label" for="cant" id="cantidadDeFloresLabel">Cantidad De Flores por</label>
                <input type="number" name="cant" id="cant" class="form-control" value="<?php if ($datOne) echo $datOne[0]['cant']; ?>" >
            </div>
            <script>
                $(document).ready(function() {
                    // Función para actualizar los textos de "Cantidad De" y "Cantidad De Flores por" cuando cambia la selección.
                    function updateTexts() {
                var selectedEmpaqueText = $("#emp option:selected").text();
                var cantidadDe = "Cantidad De " + selectedEmpaqueText;
                var cantidadDeFloresPor = "Cantidad De Flores por " + selectedEmpaqueText;
                    
                // Actualiza los textos de los labels.
                $("#cantidadDeLabel").text(cantidadDe);
                $("#cantidadDeFloresLabel").text(cantidadDeFloresPor);
              }
                    // Llama a la función inicialmente para que los textos coincidan con la selección inicial.
                    updateTexts();
                    // Escucha el evento de cambio en el select "Tipo de Empaque".
                    $("#emp").on("change", function() {
                        updateTexts();
                    });
                });
            </script>
           
            <div class="form-group col-md-6">
                <label class="form-label"for="florid">Variedad</label>
                <div id='reloadVar'>
                  <select name="florid" id="florid" class="form form-select">
                    <option>Seleccione Primero un bloque
                    </option>
                </select>
              </div>
         </div>
         <div class="form-group col-12 text-center">
    			<button type="submit" value="Registrar" class="btn btn-prin col-12 col-sm-4 col-lg-3"><?= $ope == "edit" ? "Actualizar" : "Registrar" ?></button>
    			<input type="hidden" name="ope" value="save">
    			<input type="hidden" name="quimid" value="<?php if ($datOne) echo $datOne[0]['cosecid']; ?>">
    		</div>
        </fieldset>
      </form>
      
  </section>
  <div style="display: inline-block !important;width: 100%;">
  <a class="edi" type="button" href="views/pdfpos.php" target="_blank" title="Imprimir">
          <i class="fa-solid fa-print"></i>
        </a> <table class="table w-full table-striped dt-responsive">
        <thead>
          <tr>
            <th>Flor</th>
            <th>Información</th>
            <th style="text-align:right;" ></th>
            <th ></th>
          </tr>
        </thead>
      
      <tbody>
        <?php if ($datAll) {
          foreach ($datAll as $dta) { 
            if ($dta["elival"] != 1)  {
              ?>
            <tr>
              <td>
                <strong> Color: <?=($dta["color"]); ?></strong> <br><br>
               
                  <strong>Variedad:  </strong>
                    <?=($dta["desf"]); ?><br><br>
                   
                 <strong> Tipo de empaque:</strong>
                    <?= ($dta["nomval"]); ?><br><br>
                   
              </td>
              <td> <br>Total Tallos: <?=   $dta["cant"] * $dta["ncajas"] ?><br>  
              <br>
                    <strong> Registrado Por:</strong>
                    <?= ($dta["nomper"]); ?>&nbsp;<?= ($dta["apper"]); ?>
                    <br><br><br>Fecha:
                    <?= ($dta["fech"]); ?><br>
                   
              </td>
              <td style="text-align: right;">
                <!-- <a type="button" class="edi" href="home.php?pg=303&cosecid=&ope=edit">
                    <i class="fa-solid fa-pencil"></i>
                  </a> -->
                  <a  type="button" class="eli" href="home.php?pg=303&cosecid=<?= $dta['cosecid']; ?>&ope=eli">
                    <i class="fa fa-trash"></i>
                  </a>
              </td>
              <td></td>
            </tr>
         <?php
            } 
          }
        } 
         ?>
      </tbody>
      <tfoot>
        <tr>
            <th>Flor</th>
            <th>Información</th>
            <th style="text-align:right;" ></th>
            <th ></th>
        </tr>
      </tfoot>
    </table>  
  </div>  
</div>
