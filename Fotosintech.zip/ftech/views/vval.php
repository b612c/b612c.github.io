<?php
include("controllers/cval.php");
?>
<div class="content">
  <div style="display: inline-block !important;width: 100%;">
    <form action="home.php?pg=605" method="post" id="omfg" class="formulario">
      <div class="row">
        <div class="form-group col-sm-12 col-md-6">
          <label class="form-label" for="nomval">Nombre del Valor:</label>
          <input id="nomval" required name="nomval" type="text" class="form-control"
            value="<?php if ($datOne) echo $datOne[0]['nomval'] ?>">
        </div>
        <div class="form-group col-sm-12 col-md-6">
          <label for="domid" class="form-label">Dominio</label>
          <select name="domid" id="domid" class="form form-select">
              <?php if ($datDom) {
                  foreach ($datDom as $ddo) { ?>
                      <option value="<?= $ddo['domid']; ?>" <?php if ($datOne && $ddo['domid'] == $datOne[0]['domid']) echo "selected"; ?>>
                          <?= $ddo['nomd']; ?>
                      </option>
              <?php }
              } ?>
          </select>
        </div>
        <div class="form-group col-md-6">
                <label class="form-label" for="actval">Estado: </label>
                <select name="actval" id="actval" class="form-control form-select">
                    <option value="1" <?php if($datOne && $datOne[0]['actval']==1) echo " selected "; ?>>Si</option>
                    <option value="2" <?php if($datOne && $datOne[0]['actval']==2) echo " selected "; ?>>No</option>
                </select>
            </div>
        <div class="form-group col-12 text-center">
          <br>
          <button type="submit" value="Registrar"  class="btn btn-prin col-12 col-sm-4 col-lg-3"><?= $ope == "edit" ? "Actualizar" : "Registrar" ?></button>
          <input type="hidden" name="ope" value="save">
          <input type="hidden" name="valid" value="<?php if ($datOne) echo $datOne[0]["valid"]; ?>">
        </div>
      </div>
    </form>
  </div>

  <div style="display: inline-block !important;width: 100%;">
    <table id="mytable" class="table table-striped" style="width:100%">
        <thead>
            <tr>
                <th>Datos</th>
                <th>Estado</th>
                <th></th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            <?php if ($datAll) { foreach ($datAll as $dta) { ?>
              <tr>
                <td>
                  <strong> <?=number_format ($dta['valid'])." - ".$dta['nomval'];?></strong> 
                  <br>
                  <small>
                      <?php if($dta['parval']){ ?>
                      <strong>Parametro:</strong> <?= $dta['parval']; ?>  
                      <?php } ?>
                      <strong>Dominio:</strong> <?= $dta['domid']; ?>. 
                      <?php 
                      if($datDom){
                          foreach ($datDom as $dtd){
                              if ($dtd['domid']==$dta['domid']){
                                  echo $dtd['nomd'];
                              }
                          }
                      }
                      ?> 
                  </small>
                </td>
                <td>
                  <?php if($dta['actval']== 1) { ?>
                    <a class="form-boton" type="button" href="home.php?pg=605&valid=<?=$dta['valid'];?>&ope=act&actval=2">
                      <i class="fa-solid fa-circle-check fa-2x" style="color:#00bb00;"></i>
                    </a>
                  <?php }else{ ?>
                    <a class="form-boton" type="button" href="home.php?pg=605&valid=<?=$dta['valid'];?>&ope=act&actval=1">
                      <i class="fa-solid fa-circle-xmark fa-2x" style="color:#f00;"></i>
                    </a>
                  <?php } ?>
                </td>
                <td style="text-align: center; ">
                  <a class="edi" type="button" href="home.php?pg=605&valid=<?= $dta['valid']; ?>&ope=edit">
                    <i class="fa fa-pen"></i>
                  </a>
                  <a>
                  <button class="form-boton eli" title="Editar" onclick="alertaSuave('home.php?pg=605&valid=<?= $dta['valid'];?>&ope=eli')"
                  type="button">
                    <i class="fa fa-trash"></i>
                  </button>
                </td>
                <td></td>
              </tr>
            <?php }} ?>
        </tbody>
        <tfoot>
            <tr>
                <th>Datos</th>
                <th>Estado</th>
                <th style="text-align:right;"> </th>
                <th></th>
            </tr>
        </tfoot>
</table>
  </div>
</div>
