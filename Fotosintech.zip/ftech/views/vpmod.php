<?php require_once ('controllers/cpmod.php'); ?>
<br><br><br>
<div class="secmod">
	<?php if($datAll){foreach ($datAll as $dt){
		$modact = "No";
		if($datPrPf){foreach ($datPrPf as $dtfp){
			if($dt['modid'] == $dtfp['modid']){
				$modact = "Si";
			}
		}}
	if($modact == "Si"){?>
		<form action="pmod.php" method="POST">
			<button type="submit" class="modulo">
				<?php if (file_exists($dt['imgmod'])) { ?>
					<img class="logmod" src="<?=$dt['imgmod'];?>" alt="Logo módulo <?= $dt['nomod']; ?>" />
				<?php }else{ ?>
					<img class="logmod" src="img/noimage.png" alt="Logo módulo <?= $dt['nomod']; ?>" />
				<?php } ?>
				<br>
				<?=$dt['nomod'];?>
			</button>	
			<input type="hidden" name="modid" value="<?=$dt['modid'];?>">
			<input type="hidden" name="ope" value="dircc">
		</form>
	<?php } else { ?>
		<button class="modulo1" style="display:none;">
			<?php if (file_exists($dt['imgmod'])) { ?>
				<img class="logmod" src="<?=$dt['imgmod'];?>" alt="Logo módulo <?= $dta['nomod']; ?>" />
			<?php }else{ ?>
				<img class="logmod" src="img/noimage.png" alt="Logo módulo <?= $dt['nomod']; ?>" />
			<?php } ?>
			<br>
			<?=$dt['nomod'];?>
		</button>
	<?php	}
		}
	} ?>
</div>
<style>
	.secmod{
	    display: flex;
	    grid-template-columns: repeat(3, 1fr);
	    gap: 15px;
	    width: 70%;
		margin: auto;
		justify-content: center;
	    align-items: center;
	    text-align: center;
		height: 700px;

	}

	.modulo, .modulo1{
	    background-color: white;
	    padding: 15px;
	    border-radius: 30px;
	    justify-content: center;
	    align-items: center;
	    text-align: center;
	    box-shadow: 0px 0px 5px #2e7e95;
	}

	.logmod{
		width: 50%;
		margin: 15px;
	}

	img.logmod{
		width: 200px;
		height: 200px;
	}

	.modulo:hover{
		box-shadow: 0px 0px 2px #3f3f39;
		background-color: #afdadd;
	}
	.pie{
		display: block;
		width: 100%;
		background-color: var(--color1);
		color: var(--white);
		bottom: 0px;
		right: 0px;
		left: 0px;
		font-size: 15px;
		padding: 10px 0px;
		text-align: center;
		position: fixed;
		border-radius: 0px;
		z-index: 3;
	}

	@media screen and (max-width: 1024px){
    	.secmod{
			width: 90%;
    	}
	}	

	@media screen and (max-width: 600px){
    	.secmod{
    	    display: inline-block;
			justify-content: center;
    		align-items: center;
    		text-align: center;
			width: 100%;
    	}
		.modulo, .modulo1{
			width: 60%;
			margin: 15px 0;
		}

    	.logmod{
    	    height: 50%;
    	}
    	img.logmod{
			width: 150px;
			height: 150px;
		}
		.pie{
			font-size: 10px;
			display: block;
			width: 100%;
			background-color: var(--color1);
			color: var(--white);
			bottom: 0px;
			left: 0px;
			padding: 10px 0px;
			text-align: center;
			position: fixed;
			border-radius: 0px;
			z-index: 3;
		}
	}	
</style>