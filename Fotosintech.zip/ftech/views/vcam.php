<?php
require_once('controllers/ccam.php');
?>
<div class="content">
    <form action="home.php?pg=201" method="POST">
        <div class="row">
            <div class="form-group col-md-6">
                <label class="form-label" for="valid">Tipo De Flor</label>
                <select id="valid"  name="valid" class="form form-select" value="<?php if ($datOne) echo $datOne[0]['valid']; ?>">
                    <?php if ($datMval) {foreach ($datMval as $dmt)
                        if ($dmt['domid'] == 102){ ?>
                            <option value="<?= $dmt['valid']; ?>" <?php if ($datOne && $dmt['valid'] == $datOne[0]['valid']) echo "selected"; ?>>
                                <?= $dmt['nomval']; ?>
                            </option>
                    <?php } }?>
                </select>
            </div>
            <div class="form-group col-md-6">
                <label class="form-label"for="florid">Nombre de la flor:</label>
                <select name="florid" id="florid" class="form form-select" value="<?php if ($datOne) echo $datOne[0]['florid']; ?>" >
                    <?php if ($datFlor) { foreach ($datFlor as $df) {
                        if ($df['florid'])?>
                            <option value="<?= $df['florid']; ?>" data-tipo="<?= $df['valid']; ?>">
                                <?= $df['desf']; ?>
                            </option>
                    <?php } } ?>
                </select>
            </div>  
            <div class="form-group col-12 text-center">
                <input type="submit" class="btn btn-prin col-12 col-sm-4 col-lg-3" value="Registrar" title="Nueva cama">
                <input type="hidden" value="save" name="ope">
                <input type="hidden" value="<?php if($datOne) echo $datOne[0]['camid']; ?>" name="camid">
            </div>
        </div>
    </form>

    <div style="display: inline-block !important;width: 100%;">
        <table class="table w-full table-striped dt-responsive">
            <thead>
                <tr>
                    <th style="text-align: center;">No de cama</th>
                    <th style="text-align: center;">Información de la flor</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php if($datAll){foreach($datAll AS $dta){ ?>
                    <tr>
                        <td>
                           <strong> Cama <?=$dta['camid'];?></strong>
                        </td>
                        <td>
                           <strong>Nombre de la flor: </strong><?=$dta['desf']?><br>
                           <strong>Tipo de la flor: </strong><?=$dta['nomval']?><br>
                           <strong>Color: </strong><?=$dta['color']?>
                        </td>
                        <td  style="text-align: right; ">
                            <a type="button" class="eli" class="form-boton" href="home.php?pg=201&camid=<?=$dta['camid']; ?>&ope=eli"> 
                                <i class="fa-solid fa-trash"></i>
                            </a>
                        </td>
                    </tr>
                <?php }} ?> 
            </tbody>
            <tfoot>
                <tr>
                    <th style="text-align: center;">No de cama</th>
                    <th style="text-align: center;">Información de la flor</th>
                    <th></th>
                </tr>
            </tfoot>
        </table>
    </div>
</div>
<script>
    document.addEventListener("DOMContentLoaded", function() {
        var tipoFlorSelect = document.getElementById("valid");
        var variedadSelect = document.getElementById("florid");
            
        tipoFlorSelect.addEventListener("change", function() {
            var selectedTipoFlor = tipoFlorSelect.value;

            // Mostrar u ocultar las opciones de Variedad según el Tipo de Flor seleccionado
            variedadSelect.querySelectorAll("option").forEach(function(option) {
                if (selectedTipoFlor === "" || selectedTipoFlor === option.getAttribute("data-tipo")) option.style.display = "block";
                else option.style.display = "none";
            });
                  
            // Reiniciar el valor del select de Variedad
            variedadSelect.value = "";
        });
    });
</script>