<?php
  include("controllers/cpar.php");

  function escapeOutput($data){
    return htmlspecialchars($data, ENT_QUOTES, 'UTF-8');
  }
?>
<section style="display: inline-block !important;width: 100%;">
  <div>
    <form action="home.php?pg=<?=$pg;?>" role="form" style="align-items: left;" id="omfg" method="POST">
      <fieldset>
        <div class="row">
          <div class="form-group col-md-6">
            <label for="idtpr" class="titulo">Categoría</label>
            <select name="idtpr" id="idtpr" class="form form-select">
            <?php if ($datMtpa) {
              foreach ($datMtpa as $dmt) { ?>
                <option value="<?= $dmt['idtpr']; ?>" <?php if ($datOne && $dmt['idtpr'] == $datOne[0]['idtpr']) echo "selected"; ?>>
                  <?= $dmt['nomtpr']; ?>
                </option>
            <?php }
            } ?>
            </select>
          </div>
          <div class="form-group col-md-6">
            <label for="nompar">Nombre del parámetro</label>
            <input type="text" name="nompar" id="nompar" class="form-control" value="<?php if ($datOne) echo $datOne[0]['nompar']; ?>" required>

          </div>
          <div class="form-group col-md-6">
            <label for="actpar" class="titulo">Estado Activo:</label>
            <select name="actpar" id="actpar" class="form form-select" value="<?php if ($datOne && ($datOne[0]['actpar']) == 1) echo 'Si'; elseif ($datOne && ($datOne[0]['actpar']) == 2) echo 'No'; ?>" required>
              <option selected disabled hidden>Selecione una opción</option>
              <option value="1" <?php if ($datOne && $datOne[0]['actpar'] == 1) echo "selected"; ?>>Si</option>
              <option value="2" <?php if ($datOne && $datOne[0]['actpar'] == 2) echo "selected"; ?>>No</option>
            </select>
          </div>
            <div class="form-group col-md-6">
              <label for="codval">Tipo de valor</label>
                <select name="codval" id="codval" class="form form-select"> <?php if ($datMval) {
              foreach ($datMval as $dmt) 
              if ($dmt['iddom'] == 6) { ?>
                <option value="<?= $dmt['codval']; ?>" <?php if ($datOne && $dmt['codval'] == $datOne[0]['codval']) echo "selected"; ?>>
                  <?= $dmt['nom_val']; ?>
                </option>
            <?php }
            } ?>
              </select>
            </div>
        </div>
        <div class="form-group col-md-6">
          <br>
          <button type="submit" class="boton"><?= $ope == "edit" ? "Actualizar" : "Registrar" ?></button>
          <input type="hidden" name="ope" value="save">
          <input type="hidden" name="idpar" id="idpar" value="<?php if ($datOne) echo $datOne[0]['idpar']; ?>">
        </div>
      </fieldset>
    </form>
  </div>
  <br><br>
  <table class="table w-full table-striped dt-responsive" style="width:100%">
    <thead>
      <th>Parametro</th>
      <th></th>
      <th></th>
    </thead>
    <tbody>
      <?php if ($datAll) {
        foreach ($datAll as $dta) { ?>
          <tr>
            <td>
              <strong> <?=escapeOutput($dta["nompar"]); ?></strong><br>
              <small>
                <strong> Categoria: </strong>
                  <?= escapeOutput($dta["nomtpr"]); ?>
                <br>
               <strong> Tipo de valor:</strong> 
                  <?= escapeOutput($dta["nom_val"]); ?>
                <br>
              </small>
            </td>

            <td>
              <a>
                <?php if ($dta['actpar'] == 1) { ?>
                  <i class="fa-solid fa-circle-check fa-2x" style="color:#00bb00;"></i>
                <?php } ?>
                <?php if ($dta['actpar'] == 2) { ?>
                  <i class="fa-solid fa-circle-xmark fa-2x" style="color:#f00;"></i>
                <?php } ?>
              </a>
              <a class="ediBtn form-boton" href="home.php?pg=313&idpar=<?= $dta['idpar']; ?>&ope=edit">
                <i class="fa-solid fa-pencil"></i>
              </a>
              <?php
              $pc = $mpar->getPxC($dta['idpar']);
              if ($pc and $pc[0]['can'] == 0) {
                $ph = $mpar->getPxH($dta['idpar']);
                if ($ph and $ph[0]['ca'] == 0) { 
              ?>
                  <button class="form-boton" onclick="alertaSuave('?pg=313&idpar=<?= $dta['idpar']; ?>&ope=eli')">
                    <i class="fa-solid fa-trash-can"></i>
                  </button>
                <?php }} ?>
            </td>
            <td></td>
          </tr>
    <?php     
            }
          } ?>
    </tbody>
    <tfoot>
      <th>Parametro</th>
      <th></th>
      <th></th>
    </tfoot>
  </table>
</section>

<figure class="highcharts-figure">
    <div id="container"></div>
</figure>
<div>
    <?php
    $dtGf = array();

    foreach ($datGra as $dg) 
         if ($dg['can'] > 0) { 
            $dtGf[] = array(
                'name' => $dg['nomtpr'],
                'z' => (int)$dg['can'],
                'y' => (int)$dg['can'],
            );
        }
    
    ?>
</div>
<script>
    Highcharts.chart('container', {
        chart: {
            type: 'variablepie'
        },
        title: {
            text: '<h1>Cantidad De Parametros Por Categoria</h1><br>' ,
            align: 'center'
        },
        tooltip: {
            headerFormat: '',
            pointFormat: '<span style="color:{point.color}">\u25CF</span> <b> {point.name}</b><br/>' + 'Cantidad de parametros: <b>{point.z}</b><br/>'
        },
        series: [{
            minPointSize: 10,
            innerSize: '20%',
            zMin: 0,
            name: 'Paginas',
            borderRadius: 5,
            data: <?php echo json_encode($dtGf); ?>,
            colors: [
                '#4caefe',
                '#3dc3e8',
                '#2dd9db',
                '#1feeaf',
                '#0ff3a0',
                '#00e887',
                '#23e274'
            ]
          }]
          
        });
</script>
<style>
    #container {
        height: 500px;
    }

    .highcharts-figure,
    .highcharts-data-table table {
        min-width: 320px;
        max-width: 700px;
        margin: 1em auto;
    }

    .highcharts-data-table table {
        font-family: Verdana, sans-serif;
        border-collapse: collapse;
        border: 1px solid #ebebeb;
        margin: 10px auto;
        text-align: center;
        width: 100%;
        max-width: 500px;
    }

    .highcharts-data-table caption {
        padding: 1em 0;
        font-size: 1.2em;
        color: #555;
    }

    .highcharts-data-table th {
        font-weight: 600;
        padding: 0.5em;
    }

    .highcharts-data-table td,
    .highcharts-data-table th,
    .highcharts-data-table caption {
        padding: 0.5em;
    }

    .highcharts-data-table thead tr,
    .highcharts-data-table tr:nth-child(even) {
        background: #f8f8f8;
    }

    .highcharts-data-table tr:hover {
        background: #f1f7ff;
    }
</style>

