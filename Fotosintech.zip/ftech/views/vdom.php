<?php
require_once("controllers/cdom.php");
?>
<div  class="content">
  <div style="display: inline-block !important;width: 100%;">
    <form action="home.php?pg=604" method="post" id="omfg" class="formulario">
      <div class="row">
        <div class="form-group col-sm-12 col-md-6">
          <label for="nomd" class="form-label">Nombre del dominio:</label>
          <input id="nomd" required name="nomd" type="text" class="form-control"
            value="<?php if ($datOne) echo $datOne[0]['nomd'] ?>">
        </div>
        <div class="form-group col-12 text-center">
          <button type="submit" class="btn btn-prin col-12 col-sm-4 col-lg-2"><?= $ope == "edit" ? "Actualizar" : "Registrar" ?></button><input type="hidden" name="ope" value="save">
          <input type="hidden" name="domid" value="<?php if ($datOne) echo $datOne[0]["domid"]; ?>">
        </div>
      </div>
    </form>
  </div>

  <div style="display: inline-block !important;width: 100%;">
    <table id="table" class="table w-full table-striped dt-responsive">
      <thead>
        <tr>
          <th scope="col">Dominios</th>
          <th scope="col" style="text-align:right;"></th>
          <th></th>
        </tr>
      </thead>
      <tbody>
        <?php if ($datAll) {
          foreach ($datAll as $dta) { ?>
        <tr>
          <td>
            <?= $dta['domid'].". ".$dta['nomd']; ?>
          </td>
          <td style="text-align: right;">
            <a type="button" class="edi" href="home.php?pg=604&domid=<?= $dta['domid'] ?>&ope=edit">
              <i class="fa-solid fa-pencil"></i>
            </a>
            <a  type="button" class="eli" href="home.php?pg=604&domid=<?= $dta['domid']; ?>&ope=eli">
                <i class="fa fa-trash"></i>
            </a>
          </td>
          <td></td>
        </tr>
        <?php }} ?>
      </tbody>
      <tfoot>
        <tr>
          <th scope="col">Dominios</th>
          <th scope="col" style="text-align:right;"></th>
          <th></th>
        </tr>
      </tfoot>
    </table>
  </div>
</div>