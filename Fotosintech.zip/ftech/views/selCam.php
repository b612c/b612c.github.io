<?php 
	include '../models/mcam.php';
	$valor = $_REQUEST['valor'];
	$mcam = new Mcam();
    $dat = $mcam->getBxcama($valor);
    $html = '<div id="reloadCam">';
$html .= '<select name="ncamas" id="ncamas" class="form form-select" required>';
$html .= '<option velue=0>Seleccione la cantidad de camas
                </option>';
if ($dat) {
    foreach ($dat as $do) {
        for ($i = 1; $i <= $do['cant']; $i++) {
            $html .= '<option value="' . $do['bloqid'] . '">' . $i . '</option>';
        }

        $html .= '</option>';
    }
}

$html .= '</select>';
$html .= '</div>';


	echo $html;
    ?>