<?php
include("controllers/cfum.php");


$pg = $_GET['pg'] ?? '';

function escapeOutput($data)
{
  return htmlspecialchars($data, ENT_QUOTES, 'UTF-8');
}

?>
<div class="content">
  <section style="display: inline-block !important;width: 100%; ">
    <form action="home.php?pg=<?= $pg; ?>" class="formulario" role="form" id="omfg" method="POST">
      <fieldset>
        <div class="row">
        <div class="form-group col-md-6">
              <label class="form-label" for="bloqid">Bloque</label>
              <select name="bloqid" id="bloqid" onChange="recCama(this.value)" class="form form-select" value="<?php if ($datOne) echo $datOne[0]['bloqid']; ?>" required>
              <?php if ($datMbloq) {
                foreach ($datMbloq as $dmt) { ?>
                  <option value="<?= $dmt['bloqid']; ?>" <?php if ($datOne && $dmt['bloqid'] == $datOne[0]['bloqid']) echo "selected"; ?>> <?= $dmt['nombloq']." ".$dmt['bloqid']; ?>
                  </option>
              <?php }
              } ?>
              </select>
            </div>
            <div class="form-group col-md-6">
              <label for="fitoid" class="form-label">Fitopatologia a erradicar:</label>
              <select name="fitoid" id="fitoid" class="form form-select" onChange="recQuim(this.value)" required>
                <?php if ($datMfit) {
                  foreach ($datMfit as $dmq) { ?>
                    <option value="<?= $dmq['fitoid']; ?>" <?php if ($datOne && $dmq['fitoid'] == $datOne[0]['fitoid']) echo "selected"; ?>>
                      <?= $dmq['nomfito']; ?>
                    </option>
                <?php }
                } ?>
              </select>
            </div>
         
          <div class="form-group col-md-6">
            <label class="form-label" for="quimid">Quimico a Utilizar:</label>
            <div id='reloadQuim'>
              <select name="quimid" id="quimid" class="form form-select" required>
                
              </select>
            </div>
          </div>
          
          <div class="form-group col-md-6">
            <label class="form-label" for="ncamas">Numero de camas a fumigar:</label>
            <div id='reloadCam'>
              <select name="ncamas" id="ncamas" class="form form-select" required>
                
              </select>
            </div>
          </div>
          
          <div class="form-group col-md-6">
            <label for="totagua"> Total Agua Utilizada (litros): </label>
            <input type="number" step="any" name="totagua" id="totagua" class="form-control" required placeholder="Total litros de agua para la asperción"  required>
          </div>
       
          <div class="form-group col-md-6">
            <label for="totquim" id="tq"> Total quimico (litros): </label>
            <input type="number" step="any" name="totquim" id="totquim" class="form-control" required placeholder="Total litros de quimico para la asperción" required>
          </div>
        <div class="form-group col-12 text-center">
          <br>
          <button type="submit" class="btn btn-prin col-12 col-sm-4 col-lg-2"><?= $ope == "edit" ? "Actualizar" : "Registrar" ?></button>
          <input type="hidden" name="ope" value="save">
          <input type="hidden" name="fumid" id="fumid" value="<?php if ($datOne) echo $datOne[0]['fumid']; ?>">
        </div>
      </fieldset>
    </form>
  </section>
  <div style="display: inline-block !important;width: 100%;">
    <a class="edi" type="button" href="views/pdffum.php" target="_blank" title="Imprimir">
      <i class="fa-solid fa-print"></i>
    </a>
    <table class="table w-full table-striped dt-responsive" style="width:100%" id="table">
      <caption></caption>
      <thead>
        <th>Fecha De Fumigación</th>
        <th>Infomación Bloque</th>
        <th>Informacion Asperción</th>
        <th></th>
        <th></th>
      </thead>
      <tbody>
        <?php if ($datAll) {
          foreach ($datAll as $dtf) {
            if ($dtf["elival"] != 1) {
        ?>
              <tr>
                <td>
                  <strong> <?= escapeOutput($dtf["fecha"]); ?></strong><br><br><br>
                  <small>Registrado Por:
                  <?= ($dtf["nomper"]); ?>&nbsp;<?= ($dtf["apper"]); ?>
                  </small>
                </td>

                <td>
                  <strong>Bloque: </strong><?= escapeOutput($dtf["nombloq"]); ?> <?= escapeOutput($dtf["bloqid"]); ?> <br><br>
                  <strong>Numero de camas a fumigar: </strong><?= escapeOutput($dtf["ncamas"]); ?><br><br>
                  <strong>Fitopatologia a erradicar: </strong><?= escapeOutput($dtf["nomfito"]); ?>
                </td>
                <td>
                  <strong> Quimico utilizado: </strong>
                  <?= escapeOutput($dtf["nomquim"]); ?>
                  <br><br>
                  <strong> Cantidad De Agua Utilizada:</strong>
                  <?= escapeOutput($dtf["totagua"]); ?> Litros
                  <br><br>
                  <strong> Cantidad De Quimico Utilizado:</strong>
                  <?= escapeOutput($dtf["totquim"]); ?> Litros
                  <br><br>
                </td>
                <td style="text-align:right;">
                  <a type="button" class="eli" href="home.php?pg=304&fumid=<?= $dtf['fumid']; ?>&ope=eli">
                    <i class="fa fa-trash"></i>
                  </a>
                </td>
                <td></td>
              </tr>
        <?php
            }
          }
        } ?>
      </tbody>
      <tfoot>
        <th>Fecha De Fumigación</th>
        <th>Infomación Bloque</th>
        <th>Informacion Asperción</th>
        <th></th>
        <th></th>
      </tfoot>
    </table>
  </div>
</div>