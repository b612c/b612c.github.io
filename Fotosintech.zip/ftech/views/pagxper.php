<?php
require_once ('controllers/cper.php');
?>

<div class="content">
	<?php //echo titulo ("<i class='".$ico."'></i> Perfil"); ?>
	<div class="inser">
		<form name="frm1" action="home.php?pg=<?=$pg;?>" method="POST">
			<div class="row" style="margin-bottom: 50px">
				<div class="form-group col-md-6">
					<label for="nomper">Nombre de perfil</label>
					<input type="text" name="nomper" id="nomper" class="form-control" required value="<?php if($datOne) echo $datOne[0]['nomper']; ?> ">
				</div>
				<div class="form-group col-md-6">
					<label for="pagp">Pagina Inicial</label>
					<select name="pagp" id="pagp" class="form-select form-select-lg">
						<?php if($datpag) { 
							foreach ($datpag as $dt) { ?>
								<option value="<?=$dt['pagid'];?>" <?php if($datOne && $datOne[0]['pagp']==$dt['pagid']) echo " selected "; ?>>
									<?=$dt['pagnom']." (".$dt['nommod'].")";?>
								</option>
						<?php } 
							} ?>
					</select>
				</div>
				<div class="form-group col-md-6">
					<label for="idmod">Módulo</label>
					<select name="idmod" id="idmod" class="form-select">
						<?php if($datmod){ foreach ($datmod as $dtm) { ?>
							<option value="<?=$dtm['idmod'];?>" <?php if($datOne && $datOne[0]['idmod']==$dtm['idmod']) echo " selected "; ?>> <?=$dtm['nommod'];?> </option>
						<?php }} ?>
					</select>
				</div>
				<div class="form-group col-md-6">
					<br>
					<input type="hidden" name="idper" id="idper" value="<?php if($datOne) echo $datOne[0]['idper']; ?> ">
					<input type="hidden" name="opera" value="<?php if($datOne) echo "Actualizar"; else echo "Insertar"; ?>">
					<input type="submit" class="btn btn-primary" style="margin-top: 0px;" value="<?php if($datOne) echo "Actualizar"; else echo "Registrar" ?>">
				</div>
			</div>
		</form>
	</div>
</div>