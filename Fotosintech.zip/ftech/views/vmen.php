<?php
include 'controllers/cmen.php';
?>

<aside id="sidebar">
  <nav class="">
    <section  id="menu" class="borde">
      <a href="pmod.php" title="Inicio" class="nav-item <?php echo (!isset($_GET['pg'])) ? 'activ' : '' ?>">
        <img class="img" src="img/icon/house-solid.svg"><span>Inicio</span>
      </a>
      <?php if ($dat) {
        $pagina = isset($_GET['pg']) ? $_GET['pg'] : null;
        foreach ($dat as $dt) { ?>
          <a href="home.php?pg=<?= $dt['pagid']; ?>" title="<?= $dt['pagnom']; ?>" class=" nav-item <?php echo ($pagina == $dt['pagid']) ? 'activ' : ''; ?>">
            <img class="img" src="img/icon/<?=$dt['icono']; ?>"><span><?= $dt['pagnom']; ?></span>
          </a>
        <?php }} ?>
    </section>
  </nav>
</aside>
<SCRIPt>
  // const container = document.querySelector('#sidebar');
  // const scrollbar = document.querySelector('.scrollbar');

  // container.addEventListener('scroll', () => {
  //   if (container.scrollTop > 0) {
  //     scrollbar.classList.add('show');
  //   } else {
  //     scrollbar.classList.remove('show');
  //   }
  // });
</SCRIPt>