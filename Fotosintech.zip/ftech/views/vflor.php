+<?php
require_once('controllers/cflor.php');
?>

<div class="content">
    <form action="home.php?pg=603" method="POST" enctype="multipart/form-data">
        <div class="row">
            <div class="form-group col-12 col-md-6">
                <label for="desf" class="form-label">Nombre de la flor:</label>
                <input type="text" name="desf" class="form-control" value="<?php if ($datOne) echo $datOne[0]['desf']; ?>" required>
            </div>
            <div class="form-group col-12 col-md-6">
                <label for="valid" class="form-label">Seleccione el tipo de flor: </label><br>
                <select name="valid" class="form-select" style="text-transform: uppercase;">
                    <option></option>
                    <?php if($datTpF){foreach($datTpF AS $dtf){ ?>
                        <option value="<?=$dtf['valid'];?>" <?php if($datOne && $dtf['valid']==$datOne[0]['valid']) echo 'selected';?>>
                            <?=$dtf['nomval'];?>
                        </option>
                    <?php }} ?>
                </select>
            </div>
            <div class="form-group col-md-6">
              <label for="color" class="form-label">Color de la flor:</label>
              <select name="color" id="color" class="form form-select">
                <option></option>
                    <?php if($datClF){foreach($datClF AS $dtcl){ ?>
                        <option value="<?=$dtcl['color'];?>" <?php if($datOne && $dtcl['color']==$datOne[0]['color']) echo 'selected';?>>
                            <?=$dtcl['color'];?>
                        </option>
                    <?php }} ?>
              </select>
            </div>
            <div class="form-group col-12 col-md-6">
                <label for="arcimg" class="form-label">Imagen de la flor:</label>
                <input type="file" name="arcimg" id="arcimg" class="form-control"  accept="image/jpeg, image/jpg, image/avif, image/png, image/gif">
            </div>
            <div class="form-group col-12 col-md-6">
                <label for="cuidaf" class="form-label">Descripción  de la flor:</label>
                <textarea name="cuidaf" class="form-control" cols="20" rows="5"><?php if ($datOne) echo $datOne[0]['cuidaf']; ?></textarea>
            </div>
            <div class="form-group col-12 text-center">
                <?php if($florid){ ?>
                    <input type="submit"  class="btn btn-prin col-12 col-sm-4 col-lg-3" value="Actualizar">
                <?php }else{ ?>
                        <input type="submit"  class="btn btn-prin col-12 col-sm-4 col-lg-3" value="Registrar">
                <?php } ?>
                <input type="hidden" value="save" name="ope">
                <input type="hidden" name="florid" value="<?php if ($datOne) echo $datOne[0]['florid']; ?>">

            </div>
        </div>
    </form>

    <table class="table w-full table-striped dt-responsive">
        <thead>
            <tr>
                <th style="text-align: center;">Foto</th>
                <th style="text-align: center;">Info flor</th>
                <th style="text-align: center;">Descripción de la flor</th>
                <th></th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            <?php if($datAll){foreach($datAll AS $dta){ ?>
                <tr>
                    <td style="width: 20%">
                        <?php if(file_exists($dta['imgf'])) { ?>
                            <img src="<?=$dta['imgf'];?>" alt="Foto flor <?=$dta['desf'];?>" style="width: 120px;height: 120px;">
                        <?php }else{ ?>
                            <img src="img\noimage.png" style="width: 120px;height: 120px;">
                        <?php } ?>
                    </td> 
                    <td style="width: 30%">
                        <strong><?=$dta['florid'];?>- Nombre: </strong><?=$dta['desf'];?><br>
                        <strong>Tipo: </strong><?=$dta['nomval'];?><br>
                        <strong>Color: </strong><?=$dta['color'];?>
                    </td>
                    <td style="width: 30%; text-align: center;">
                        <p><?=$dta['cuidaf'];?></p>
                    </td>
                    <td  style="text-align: center; ">
                        <a type="button" class="edi" href="home.php?pg=603&florid=<?=$dta['florid']; ?>&ope=edi" title="Editar">
                            <i class="fa fa-pencil"></i>
                        </a>
                        
                        <?php
                            $fp = $mflor->getFxp($dta['florid']);
                            $fc = $mflor->getFxc($dta['florid']);
                        ?>
                        <a>
                            <button class="form-boton eli" title="Editar" onclick="alertaSuave('home.php?pg=603&florid=<?= $dta['florid'];?>&ope=eli')" type="button" <?php if ($fp && $fp[0]['co'] != 0) echo ('disabled style="background:#49459c50;"') ?>    
                            <?php if ($fc && $fc[0]['ca'] != 0) echo ('disabled style="background:#49459c50;"') ?>>
                                <i class="fa fa-trash-can"></i>
                            </button>
                        </a>
                    </td>
                    <td></td>
                </tr>
            <?php }} ?> 
        </tbody>
        <tfoot>
            <tr>
                <th style="text-align: center;">Foto</th>
                <th style="text-align: center;">Info flor</th>
                <th style="text-align: center;">Descripción de la flor</th>
                <th></th>
                <th></th>
            </tr>
        </tfoot>
    </table><br><br>
</div>