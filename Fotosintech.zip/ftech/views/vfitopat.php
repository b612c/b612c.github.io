<?php
include("controllers/cfit.php");


$pg = $_GET['pg'] ?? '';

function escapeOutput($data)
{
  return htmlspecialchars($data, ENT_QUOTES, 'UTF-8');
}

?>
<div class="content">
  <section style="display: inline-block !important;width: 100%;">
    <div>
      <form action="home.php?pg=<?=$pg;?>" role="form" style="align-items: left;" id="omfg" method="POST">
        <fieldset>
          <div class="row">
            <div class="form-group col-md-6">
              <label for="nomfito" class="form-label">Nombre De La Fitopatología:</label>
              <input type="text" name="nomfito" id="nomfito" class="form-control" value="<?php if ($datOne) echo $datOne[0]['nomfito']; ?>" required>
            </div>
            <div class="form-group col-md-6">
              <label for="tpfito"  class="form-label" >Tipo De Fitopatologia</label>
              <select class="form form-select" name="tpfito" id="tpfito" value="<?php if ($datOne) echo $datOne[0]['tpfito']; ?>" >
              <option value="Enfermedades Abioticas">Enfermedades Abioticas(Hongos, bacterias, virus, insectos)</option>
              <option value="Enfermedades Bioticas">Enfermedades Bioticas (Clima, Suelo, Temperatura, Agua)</option>
              </select>
            </div>
        <div class="form-group col-12 text-center">
    			<button type="submit" value="Registrar" class="btn btn-prin col-12 col-sm-4 col-lg-3"><?= $ope == "edit" ? "Actualizar" : "Registrar" ?></button>
    			<input type="hidden" name="ope" value="save">
    			<input type="hidden" name="fitoid" value="<?php if ($datOne) echo $datOne[0]['fitoid']; ?>">
    		</div>
        </fieldset>
      </form>
    </div>
    <br><br>
    <table class="table w-full table-striped dt-responsive" style="width:100%">
      <thead>
        <th>Tipo De Fitopatología</th>
        <th style="text-align:right;" scope="col"> </th>
        <th></th>
      </thead>
      <tbody>
        <?php if ($datAll) {
          foreach ($datAll as $dta) { ?>
            <tr>
              <td>
                <strong> <?=escapeOutput($dta["nomfito"]); ?></strong><br>
                <small>
                <strong> Tipo de patología: </strong>
                  <?= escapeOutput($dta["tpfito"]); ?>
                </small>
              </td>

              <td style="text-align: right;">
                  <a type="button" class="edi" href="home.php?pg=503&fitoid=<?=$dta['fitoid']; ?>&ope=edit">
                    <i class="fa-solid fa-pencil"></i>
                  </a>
                  <?php
              $fq = $mfit->getFxq($dta['fitoid']);
              ?>
              <a>
                <button class="form-boton eli" title="Eliminar" onclick="alertaSuave('home.php?pg=503&fitoid=<?= $dta['fitoid'];?>&ope=eli')"
                type="button" 
                <?php 
                if ($fq && $fq[0]['qui'] != 0) echo ('disabled style="background:#49459c50;"') ?>>
                  <i class="fa fa-trash"></i>
                </button>
              </td>
              <td></td>
            </tr>
            <?php }} ?>
      </tbody>
      <tfoot>
        <th>Tipo De Patología</th>
        <th style="text-align:right;" scope="col"> </th>
        <th></th>
      </tfoot>
    </table>
  </section>
</div>
          