<div class="container" id="container">
		<div class="">
			
<div style="display: flex; align-items: center; justify-content: center; height: 100vh;">
    <form role="form" action="models/control.php" method="POST">
        <img class="logo" src="img/icon/logo-ftch.svg" style="width: 100px; height: 100px;">
        <h2>- Inicio sesión -</h2>
        <!-- <div class="social-icons">
            <a href="#" class="icon"><i class="fa-brands fa-instagram"></i></a>
            <a href="#" class="icon"><i class="fa-brands fa-facebook-f"></i></a>
            <a href="#" class="icon"><i class="fa-brands fa-linkedin"></i></a>
        </div> -->
        <span>Nueva Clave</span>
        <input type="email" class="input" name="username" id="username" placeholder="Nueva Clave" required>
        
        <span>Confirmar Clave</span>
        <input type="password" placeholder="Ingresa nuevamente la clave" class="input" name="password" id="password" required>
        <input type="submit" class="btn" value="Recuperar Ahora">
    </form>
</div>
		</div>
	</div>