<?php 
	include '../models/mfit.php';
	$valor = $_REQUEST['valor'];
	$mfit = new Mfit();
    $dat = $mfit->getQxf($valor);
    
	$html = '<div id="reloadQuim">';
		$html .= '<select name="quimid"  class="form form-select">';
			$html .= '<option value=0>Seleccione el quimico</option>';
			if($dat){
				foreach ($dat as $do){
	                $html .= '<option value="'.$do['quimid'].'">';
	                	$html .= $do['nomquim'];
	                $html .= '</option>';
	            }
	        }
	            
		$html .= '</select>';
	$html .= '</div>';

	echo $html;