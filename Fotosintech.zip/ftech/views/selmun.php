<?php
	include '../models/muni.php';
	$valor = $_REQUEST['valor'];
	$muni = new Muni();
	$dat = $muni->getMun($valor);

	$html = '<div id="reloadMun">';
		$html .= '<select name="ubid" id="ubid" class="form form-select">';
			$html .= '<option value=0>Seleccione un Municipio</option>';
			if($dat){
				foreach ($dat as $do){
	                $html .= '<option value="'.$do['ubid'].'">';
	                	$html .= $do['nomubi'];
	                $html .= '</option>';
	            }
	        }
	            
		$html .= '</select>';
	$html .= '</div>';

	echo $html;
?>