<?php 
    require_once("controllers/cbloq.php");
?>
<div class="content">
    <form action="home.php?pg=103" method="POST">
        <div class="row">
            <div class="form-group col-12 col-md-6" >
                <label for="nombloq" class="form-label">Nombre del bloque</label>
                <input type="text" name="nombloq" id="nombloq" class="form-control" value="Bloque">
            </div>
            <div class="col-12 col-md-6 form-group">
                <label for="empid" class="form-label">Empresa</label>
                <select name="empid" id="empid" class="form-select">            
                    <?php if($datEmp){foreach($datEmp AS $dtem){ ?>
                        <option value="<?=$dtem['empid'];?>" <?php if($datOne && $dtem['empid']==$datOne[0]['empid']) echo 'selected';?>>
                            <?=$dtem['nemp'];?>
                        </option>
                    <?php }} ?>
                </select>
            </div>
            <div class="row form-group col-12" id="cont-select"></div>
            <div class="form-group col-12 text-center">
                <input type="button" value="+" id="boton" class="btn btn-mas col-2 col-md-1" title="Añadir cama">
                <input type="submit" name="boton1" id="guardar" class="btn btn-prin col-12 col-sm-4 col-lg-3" value="Registrar" title="Nuevo bloque">
                <input type="hidden" value="save" name="ope">
            </div>
        </div>
    </form>

    <table class="table w-full table-striped dt-responsive">
        <thead>
            <tr>
                <th style="text-align: center;">Info Bloque</th>
                <th style="text-align: center;">Camas</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            <?php if($datAll){foreach($datAll AS $dta){ ?>
                <tr>
                    <td style="width: 20%">
                        <big><strong><?=$dta['nombloq']." ".$dta['bloqid'];?></strong></big>
                    </td>
                    <td>
                        <strong>Cantidad: </strong><?=$dta['can']?>
                    </td>
                    <td  style="text-align: center; ">
                        <a type="button" class="eli" href="home.php?pg=103&bloqid=<?=$dta['bloqid']; ?>&ope=eli">
                            <i class="fa-solid fa-trash"></i>
                        </a>
                    </td>
                </tr>
            <?php }} ?> 
        </tbody>
        <tfoot>
            <tr>
                <th style="text-align: center;">Info Bloque</th>
                <th style="text-align: center;">Camas</th>
                <th></th>
            </tr>
        </tfoot>
    </table><br><br>
</div>

<script>
   $(document).ready(function() {
        $("#cont-select").append(`
            <div class="form-group col-12 col-md-6">
                <label for="camid" class="form-label">Seleccione la cama: </label>
                <select name="camid[]" class="form-select" style="text-transform: uppercase;">
                    <option></option>
                    <?php if($datCam){foreach($datCam AS $dtc){ ?>
                        <option value="<?=$dtc['camid'];?>" <?php if($datOne && $dtc['camid']==$datOne[0]['camid']) echo 'selected';?>>
                            <?=$dtc['desf']." - ".$dtc['color'];?>
                        </option>
                    <?php }} ?>
                    </select>
            </div>
        `);
        $("#boton").click(function() {
            var selectHtml = `
            <div class="form-group col-12 col-md-6">
                <label for="camid" class="form-label">Seleccione la cama: </label>
                <select name="camid[]" class="form-select" style="text-transform: uppercase;">
                    <option></option>
                    <?php if($datCam){foreach($datCam AS $dtc){ ?>
                    <option value="<?=$dtc['camid'];?>" <?php if($datOne && $dtc['camid']==$datOne[0]['camid']) echo 'selected';?>>
                        <?=$dtc['desf']." - ".$dtc['color'];?>
                    </option>
                    <?php }} ?>
                </select>
            </div>
            `;
            $("#cont-select").append(selectHtml);
        });
    });
</script>
