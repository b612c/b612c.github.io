<?php
require_once("../models/seguridad.php");
include("../models/conexion.php");
include("../models/mpos.php");
ini_set('memory_limit', '4096M');
require_once '../dompdf/autoload.inc.php';
use Dompdf\Dompdf;
$mpos = new Mpos();
$pdf = isset($_REQUEST['pdf']) ? $_REQUEST['pdf']:NULL;
function urlimg($url){
    $imagenBase64 = "data:image/png;base64," . base64_encode(file_get_contents($url));
    return $imagenBase64;
  }
    $dPar = $mpos->getOne();
    $datImpr = $mpos->Impr();
    $cant   = $mpos->Cant();
    $Totalt = $mpos->Total();
    $anctbl = 900;
    $alttbl = 100;
    $html = '';
    
    $html .= '<head>';
    $html .= '<meta charset="UTF-8">';
    $html .= '<meta name="viewport" content="width=device-width, initial-scale=1.0">';
    $html .= '<style>';
    $html .= 'table {';
    $html .= '    border-collapse: collapse;';
    $html .= '    width: 100%;';
    $html .= '    border: 2px solid #062947; /* Borde de la tabla */';
    $html .= '}';
    $html .= 'th, td {';
    $html .= '    border: 2px solid #062947; /* Borde de las celdas */';
    $html .= '    padding: 8px; /* Espaciado interno de las celdas */';
    $html .= '    text-align: left;';
    $html .= '}';
    $html .= '.logo img {';
    $html .= '    width: 100px; /* Ajusta el tamaño de la imagen según tus necesidades */';
    $html .= '    border-radius: 50%; /* Puedes ajustar el redondeo de la esquina de la imagen */';
    $html .= '}';
    $html .= '.n {';
    $html .= '    border: 0px solid #062947;';
    $html .= '}';
    $html .= 'strong {';
    $html .= '    font-weight: bold; /* Hace que el texto dentro de las etiquetas strong sea en negrita */';
    $html .= '}';
    $html .= '.container1 {';
    $html .= '    position: relative;';
    $html .= '    height: 5vh; /* Altura total del viewport */';
    $html .= '}';
    $html .= '.container {';
        $html .= '    position: relative;';
        $html .= '    height: 5vh; /* Altura total del viewport */';
        $html .= '}';
    $html .= '.t {';
    $html .= '    border-collapse: collapse;';
    $html .= '    width: 50%; /* Puedes ajustar el ancho de la tabla según tus necesidades */';
    $html .= '    margin: 10px; /* Añadido para un mejor espaciado alrededor de la tabla */';
    $html .= '    position: absolute;';
    $html .= '    bottom: 10px; /* Ajusta la distancia desde la parte inferior */';
    $html .= '    right: 10px; /* Ajusta la distancia desde la derecha */';
    $html .= '}';
    $html .= '.td {';
    $html .= '    border: 1px solid #062947;';
    $html .= '    padding: 4px; /* Ajusta el espaciado interno de las celdas */';
    $html .= '    text-align: left;';
    $html .= '    font-size: 12px; /* Puedes ajustar el tamaño de la fuente según tus necesidades */';
    $html .= '}';
    $html .= '</style>';
    $html .= '<title>Registro_Postcosecha</title>';
    $html .= '</head>';
    $html .= '<body>';
    $html .= '<div>';
    $html .= '    <table>';
    $html .= '        <tr>';
    $html .= '            <td class="n logo" style="text-align: CENTER;" colspan="3"><img src="../img/logo-ftech.png" alt="Logo"></td>';
    $html .= '        </tr>';
    $html .= '        <tr>';
    $html .= '            <td class="n" style="text-align: CENTER;" colspan="3">Registro Postcosecha</td>';
    $html .= '        </tr>';
    $html .= '    </table>';
    $html .= '    </div>';
    $html .= '<br><br><br>';
    if($datImpr) { foreach($datImpr as $dti) {
    $html .= '    <div>';
    $html .= '    <table>';
    $html .= '        <tr>';
    $html .= '            <td class="n">Nombre Del Supervisor: <strong>'.$dti['nomper'].'&nbsp;'.$dti['apper'].'</strong></td>';
    $html .= '            <td class="n">Fecha Registro <strong>'.$dti['fech'].'</strong></td>';
    $html .= '        </tr>';
    $html .= '    </table>';
    $html .= '</div>';
    $html .= '<br>';
    $html .= '<div>';
    $html .= '    <table>';
    $html .= '        <tr><td colspan="4" style="text-align: CENTER;" class="n"><strong>'.$dti['nombloq'].'&nbsp;'.$dti['bloqid'].'</strong></td></tr>';
    
    $html .= '        <tr>';
    $html .= '            <td style="background-color: #2e7e95;"> <strong>Cantidad de '.$dti['nomval'].' </strong></td>';
    $html .= '            <td style="background-color: #2e7e95;"><strong>Tipo Empaque</strong></td>';
    $html .= '            <td style="background-color: #2e7e95;"><strong>Información Flor</strong></td>';
    $html .= '            <td style="background-color: #2e7e95;"><strong>Total Tallos</strong></td>';
    $html .= '        </tr>';
    $html .= '        <tr>';
    $html .= '            <td>'.$dti['ncajas'].'</td>';
    $html .= '            <td>'.$dti['nomval'].'</td>';
    $html .= '            <td>'.$dti['desf'].'&nbsp;('.$dti['color'].')</td>';    
    $html .= '            <td style="text-align: right;">'.$dti['tot_cant'].'</td>';
    $html .= '        </tr>';
    $html .= '    </table>';
    $html .= '    <br><br>';
 
    $html .= '</div>';
    $html .='<hr>';
}}
if($Totalt) { foreach($Totalt as $tt) {
    $html .= '<div class="container">';
    $html .= '    <table class="t">';
$html .= '        <tr class="n">';
$html .= '            <td class="n">TOTAL TALLOS</td>';
$html .= '            <td class="n" style="text-align: right;">'.$tt['tot'].'</td>';
$html .= '        </tr>';
$html .= '    </table>';
$html .= '</div>';

$html .= '<br><br>';
}}
    $html .= '<div class="container1">';
    $html .= '    <table class="t">';
    $html .= '        <tr class="td">';
    $html .= '            <td class="td" style="background-color: #2e7e95;"><strong>DESCRIPCIÓN</strong></td>';
    $html .= '            <td class="td" style="text-align: right; background-color: #2e7e95;"><strong>Total X Empaque General</strong></td>';
    $html .= '        </tr>';
    $html .= '    </table>';
    $html .= '</div>';
    if($cant) { foreach($cant as $can) {
    $html .= '<div class="container">';
    $html .= '    <table class="t">';
    $html .= '        <tr class="n">';
    $html .= '            <td class="n">'.$can['cant'].'</td>';
    $html .= '            <td class="n" style="text-align: right;">'.$can['te'].'</td>';
    $html .= '        </tr>';
    $html .= '    </table>';
    $html .= '</div>';}}
    $html .= '</body>';
    
if($pdf=="54321"){
    $dompdf = new Dompdf();
    $paper_size = array(0,0,612,792);
    
    $dompdf->loadHtml($html); 
    
    //$dompdf->setPaper('Letter', 'landscape');
    $dompdf->render(); 
    $dompdf->stream("RegisPost.".date('Y-m-d') . ".pdf");
}else{
    echo $html;
    echo "<script type='text/javascript'>window.print();</script>";
}
?>