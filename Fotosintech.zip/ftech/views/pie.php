<div class="pie">
    Centro agroempresarial Chía <br>
    Fotosintech &copy;, todos los derechos reservados 
    2023

</div>