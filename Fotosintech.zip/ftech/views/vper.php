<!-- <main class="z-0 float-right p-3 overflow-auto w-10/12 h-9/12 md:h-10/12"> -->
<?php

require_once('controllers/cper.php');
?>
<div class="content">
  <form action="home.php?pg=502" method="POST" enctype="multipart/form-data">
    <div class="row form-group">
      <div class="col-md-6">
      <label for="tipdper">Tipo de Documento</label>
        <select name="tipdper" id="tipdper" class="form-select">
          <?php if ($datVal) {
            foreach ($datVal as $dtv) {
              if ($dtv['domid'] == 2) { ?>
                <option value="<?= $dtv['valid']; ?>" <?php if ($datOne && $dtv['valid'] == $datOne[0]['tipdper']) echo 'selected'; ?>>
                  <?= $dtv['nomval']; ?>
                </option>
          <?php }
            }
          }; ?>
        </select>
      </div>
      <div class="col-md-6">
        <label for="ndper" class="form-label">No. Documento</label>
        <input type="text" name="ndper" id="ndper" class="form-control" value="<?php if($datOne) echo $datOne[0]['ndper'];?>">
      </div>
      <div class="col-md-6">
        <label for="nomper" class="form-label">Nombre</label>
        <input type="text" id="nomper" name="nomper" class="form-control" value="<?php if($datOne) echo $datOne[0]['nomper'];?>">
      </div>
      <div class="col-md-6">
        <label for="apper" class="form-label">Apellido</label>
        <input type="text" name="apper" id="apper" class="form-control" value="<?php if($datOne) echo $datOne[0]['apper'];?>">
      </div>
      <div class="col-md-6">
        <label for="emaper" class="form-label">Correo electrónico</label>
        <input type="text" name="emaper" id="emaper" class="form-control" value="<?php if($datOne) echo $datOne[0]['emaper'];?>">
      </div>
      <div class="col-md-6">
        <label for="passper" class="form-label">Contraseña</label>
        <input type="password" name="passper" id="passper" class="form-control" value="<?php if($datOne) echo $datOne[0]['passper'];?>">
      </div>
      <div class="col-md-6">
        <label for="telper" class="form-label">Teléfono</label>
        <input type="text" name="telper" id="telper" class="form-control" value="<?php if($datOne) echo $datOne[0]['telper'];?>">
      </div>
      <div class="col-md-6">
      <label for="estper">Estado Civil</label>
        <select name="estper" id="estper" class="form-select">
          <?php if ($datVal) {
            foreach ($datVal as $dtv) {
              if ($dtv['domid'] == 6) { ?>
                <option value="<?= $dtv['valid']; ?>" <?php if ($datOne && $dtv['valid'] == $datOne[0]['estper']) echo 'selected'; ?>>
                  <?= $dtv['nomval']; ?>
                </option>
          <?php }
            }
          }; ?>
        </select>
      </div>
      <div class="col-md-6">
        <label for="dirper" class="form-label">Dirección</label>
        <input type="text" name="dirper" id="dirper" class="form-control" value="<?php if($datOne) echo $datOne[0]['dirper'];?>">
      </div>
      <div class="form-group col-md-6">
        <label for="codDep" class="form-label">Departamento</label>
        <select name="codDep" id=codDep class="form-select" required onchange="javascript:recCiudad(this.value);">
          <option value="" selected>Seleccione un Departamento</option>
            <?php $deps = getDep("0");
              if ($deps) {foreach ($deps as $dp) {
              ?>
               <option value="<?= $dp["ubid"]; ?>" <?php if ($datOne && $dp['ubid'] == $datOne[0]['depubi']) echo 'selected'; ?>> <?= $dp["nomubi"]; ?></option>
            <?php }}?>
          </select>
        </div>
        <div class="form-group col-md-6">
          <label for="ubid" class="form-label" required>Municipio</label>
          <div id="reloadMun">
            <select name="ubid" id="ubid" class="form-select" reuired>
              <option value="" selected>Seleccione un Municipio</option>
              <?php $deps = getDep($datOne[0]['depubi']);
              if ($deps) {
                foreach ($deps as $dp) {
              ?>
                <option value="<?= $dp["ubid"]; ?>" <?php if ($datOne && $dp['ubid'] == $datOne[0]['ubid']) echo 'selected'; ?>> <?= $dp["nomubi"]; ?></option>
              <?php }
              } ?>
            </select>
            </div>
          </div>
      <div class="col-md-6">
        <label for="fecnacper" class="form-label">Fecha de Nacimiento</label>
        <input type="date" name="fecnacper" id="fecnacper" class="form-control" min="" max="<?php echo date('Y-m-d',strtotime($nmfl.'- 1 year'));?>" value="<?php if ($datOne) echo $datOne[0]['fecnacper']; ?>">
      </div>
      <div class="col-md-6">
        <label for="ocuper" class="form-label">Ocupación</label>
        <input type="text" name="ocuper" id="ocuper" class="form-control" value="<?php if($datOne) echo $datOne[0]['ocuper'];?>">
      </div>
      <div class="col-md-6">
        <label for="foto" class="form-label">Foto</label>
        <input class="form-control" type="file" id="foto" name="foto" accept="image/jpeg, image/jpg, image/avif, image/png, image/gif">
      </div>
      <div class="col-md-6">
      <label for="actper" class="titulo">Activar</label>
        <select name="actper" id="actper" class="form form-select" value="<?php if ($datOne && $datOne['actper'] == 1) echo 'Si'; elseif ($datOne && $datOne['actper'] == 2) echo 'No'; ?>" required>
          <option value="none" selected disabled hidden>Selecione una opción</option>
          <option value="1" <?php if($datOne && $datOne[0]['actper']==1)
                echo ' selected '; ?>>Si</option>
          <option value="2" <?php if(!$datOne || ($datOne && $datOne[0]['actper']!=1))
                echo ' selected '; ?>>No</option>
        </select>
      </div>
      <div class="col-md-6">
        <label for="empid">Empresa</label>
        <select name="empid" id="empid" class="form-select">            
          <?php if($datEmp){foreach($datEmp AS $dtem){ ?>
            <option value="<?=$dtem['empid'];?>" <?php if($datOne && $dtem['empid']==$datOne[0]['empid']) echo 'selected';?>>
                <?=$dtem['nemp'];?>
            </option>
          <?php }} ?>
        </select>
      </div>
      <div class="col-md-6 form-group row">
        <label for="sexo" class="form-label">Género</label>
        <?php if ($datOne) $sex = $datOne[0]['sexo'];
        else $sex = NULL; ?>
        <div class="form-group col-md-4">
          <input type="radio" class="form-label" name="sexo" value="M" <?php if ($sex != "F") echo 'checked' ?>>
          <span style="display: inherit;margin-top: -30px;margin-left: 35px;">Masculino</span>
        </div>
        <div class="form-group col-md-8">
          <input type="radio" class="form-label" name="sexo" value="F" <?php if ($sex == "F") echo 'checked' ?>>
          <span style="display: inherit;margin-top: -30px;margin-left: 35px;">Femenino</span>
        </div>
      </div>
      <div class="form-group col-12 text-center">
      <?php if($perid){ ?>
        <input type="submit"  class="btn btn-prin col-12 col-sm-4 col-lg-3" value="Actualizar">
      <?php }else{ ?>
        <input type="submit"  class="btn btn-prin col-12 col-sm-4 col-lg-3" value="Registrar">
      <?php } ?>
        <input type="hidden" name="ope" value="save">
        <input type="hidden" name="perid" value="<?php if($datOne) echo $datOne[0]['perid'];?>">
      </div>
    </div>
  </form>

  <table class="table w-full table-striped dt-responsive">
    <thead>
      <tr>
        <th class="text-center">Foto</th>
        <th class="text-center">Datos personales</th>
        <th class="text-center">Información</th>
        <th class="text-center">Activo</th>
        <th></th>
        <th></th>
      </tr>
    </thead>
    <tbody>
      <?php if($datAll){ foreach($datAll AS $dta){ ?>
        <tr>
          <td>
            <?php if(file_exists($dta['foto'])){ ?>
              <img src="<?=$dta['foto'];?>"style="width: 100px;heigth: 100px;">
            <?php } else{ ?>
              <img src="img\noimage.png"style="width: 100px;heigth: 100px;">
            <?php } ?>
          </td>
          <td>
            <?=$dta['ndper']." - ".$dta['nomper']." ".$dta['apper'];?><br>
            <strong>Email:</strong>
              <?=$dta['emaper'];?><br>     
              <strong>Teléfono:</strong>
              <?=$dta['telper'];?><br>
            
          </td>
          <td>
            <strong>Empresa: </strong><?=$dtem['nemp']?><br>
            <strong>Municipio:</strong>
            <?=$dta['nomubi'];?><br>
          </td>
          <td class="text-center">
              <?php if($dta['actper']==1) { ?>
                  <a class="" type="button" href="home.php?pg=502&perid=<?=$dta['perid'];?>&ope=act&actper=2">
                      <i class="fa-solid fa-circle-check fa-2x" style="color:#00bb00;"></i>
                  </a>
              <?php }else{ ?>
                  <a class="" type="button" href="home.php?pg=502&perid=<?=$dta['perid'];?>&ope=act&actper=1">
                      <i class="fa-solid fa-circle-xmark fa-2x" style="color:#f00;"></i>
                  </a>
              <?php } ?>
          </td>
          <td style="text-align: right;">
            <a type="button" class="edi" href="home.php?pg=502&perid=<?= $dta['perid'];?>&ope=edi">
              <i class="fa fa-pencil"></i>
            </a>
            <a class="view" type="button" href="#" data-bs-toggle="modal" data-bs-target="#<?= "mcmb" .$dta['perid']?>" title="Perfil-Persona">
              <i class="fa-solid fa-list-check"></i>
            </a>
              <?php
                $mper->setPerid($dta['perid']);
                $dga = $mper->getOnePxF();
                $dm = arrstr($dga);
                mcmb("mcmb", $dta['perid'], $dta['nomper'] . " " . $dta['apper'], $mod, $pg, $dm);
              ?>
  
            <a type="button" class="eli" href="home.php?pg=502&perid=<?=$dta['perid'];?>&ope=eli">
              <i class="fa-solid fa-trash"></i>
            </a>
          </td>
          <td></td>
        </tr>
        <?php }} ?>
      </tbody>
      <tfoot>
      <tr>
        <th class="text-center">Foto</th>
        <th class="text-center">Datos personales</th>
        <th class="text-center">Información</th>
        <th class="text-center">Activo</th>
        <th></th>
        <th></th>
      </tr>
    </tfoot>
  </table>
</div>
