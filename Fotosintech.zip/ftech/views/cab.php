<div class="cabe">
    <div class="user-info">
    <button title="Menu" id="btn-m"><i id="ico" class="fa-solid fa-bars"></i></button>
      <img src="img/icon/logo-ftch.svg" alt="User photo" class="round-image">
      <div class="user-text">
        <p class="user-name"><?=$_SESSION['nomper']." ".$_SESSION['apper']?></p>
        <p><?=$_SESSION['pefnom']?></p>
      </div>
      <a href="#">
          <i class="fa fa-solid fa-question"></i>
      </a>
      <a href="views/vsal.php" class="fa">
          <i class="fa-solid fa-power-off"></i>
      </a>
    </div>
</div>     