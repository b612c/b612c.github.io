<?php 
	include '../models/mcam.php';
	$valor = $_REQUEST['valor'];
	$mcam = new Mcam();
    $dat = $mcam->getBxc($valor);
    
	$html = '<div id="reloadVar">';
		$html .= '<select name="florid"  class="form form-select">';
			$html .= '<option value=0>Seleccione una variedad</option>';
			if($dat){
				foreach ($dat as $do){
	                $html .= '<option value="'.$do['florid'].'">';
	                	$html .= $do['desf'];
	                $html .= '</option>';
	            }
	        }
	            
		$html .= '</select>';
	$html .= '</div>';

	echo $html;