<?php
require_once("controllers/cqui.php");
?>
<?php
$pg = $_GET['pg'] ?? '';
function escapeOutput($data)
{
  return htmlspecialchars($data, ENT_QUOTES, 'UTF-8');
}

?>
<div class="content">
  <section style="display: inline-block !important;width: 100%;">
    <form action="" role="form" class="formulario" method="POST" id="omfg">
      <fieldset>
      <div class="row">
        <div class="form-group col-sm-12 col-md-6">
          <label for="nomquim" class="form-label">Nombre del Quimico</label>
          <input type="text" class="form-control" id="nomquim" name="nomquim" value="<?php if ($datOne) echo $datOne[0]['nomquim']; ?>" required>
        </div>
        <div class="form-group col-sm-12 col-md-6">
          <label for="ingreact" class="form-label">Ingrediente Activo</label>
          <input type="text" class="form-control" id="ingreact" name="ingreact" value="<?php if ($datOne) echo $datOne[0]['ingreact']; ?>" required>
        </div>
        <div class="form-group col-sm-12 col-md-6"><br>
                <label class="form-label" for="fitoid">Nombre Fitopatologia</label>
                <select name="fitoid" id="fitoid" class="form-select">
                    <?php if ($datMfit) {
                        foreach ($datMfit as $mf) {
                            if ($mf['fitoid'])
                                ?>
                                <option value="<?= $mf['fitoid']; ?>" data-tipo="<?= $mf['fitoid']; ?>">
                                    <?= $mf['nomfito']; ?>
                                </option>
                                <?php
                        }
                    } ?>
                </select>
        </div>  
        <div class="form-group  col-sm-12 col-md-6">
          <label for="actquim" class="form-label"><br>Estado</label>
          <select name="actquim" id="actquim" class="form-select" value="<?php if($datOne && ($datOne[0]['actquim'])==1)   echo 'Si'; elseif ($datOne && ($datOne[0] ['actquim'])==2) echo 'No'; ?>" required>
            <option selected disabled hidden>Selecione una opción</option>
            <option value="1" <?php if ($datOne && $datOne[0]['actquim']==1) echo "Selected";?>
            >Si</option>
            <option value="2" <?php if ($datOne && $datOne[0]['actquim']==2) echo "Selected";?>
            >No</option>
          </select>
        </div>
        <div class="form-group col-12 text-center">
    			<button type="submit" value="Registrar" class="btn btn-prin col-12 col-sm-4 col-lg-3"><?= $ope == "edit" ? "Actualizar" : "Registrar" ?></button>
    			<input type="hidden" name="ope" value="save">
    			<input type="hidden" name="quimid" value="<?php if ($datOne) echo $datOne[0]['quimid']; ?>">
    		</div>
      </div>
      </fieldset>
    </form>
  </section>
  <div style="display: inline-block !important;width: 100%;">
    <table id="table" class="table w-full table-striped dt-responsive">
      <caption></caption>
      <thead>
        <tr>
          <th scope="col">Nombre Quimico</th>
          <th scope="col">Información</th>
          <th scope="col">Estado</th>
          <th scope="col" style="text-align:right;" > </th>
          <th></th>
        </tr>
      </thead>
      <tbody>
        <?php if ($datAll) {
          foreach ($datAll as $dta) { ?>
            <tr>
              <td>
                <?= escapeOutput($dta["nomquim"]); ?><br>
              </td>
              <td>
              <strong> Fitopatologia:</strong> 
                <?= escapeOutput($dta["nomfito"]); ?><br>
              <strong> Ingrediente Activo:</strong> 
                <?= escapeOutput($dta["ingreact"]); ?><br>
              </td>
              <td>
                <a>
                <?php if($dta['actquim']== 1) { ?>
						<a class="form-boton" type="button" href="home.php?pg=601&quimid=<?=$dta['quimid'];?>&ope=act&actquim=2">
							<i class="fa-solid fa-circle-check fa-2x" style="color:#00bb00;"></i>
						</a>
					<?php }else{ ?>
						<a class="form-boton" type="button" href="home.php?pg=601&quimid=<?=$dta['quimid'];?>&ope=act&actquim=1">
							<i class="fa-solid fa-circle-xmark fa-2x" style="color:#f00;"></i>
						</a>
					<?php } ?>
                </a>
              </td>
              <td style="text-align:right;">
                <a type="button" class="edi" href="home.php?pg=601&quimid=<?= $dta['quimid']; ?>&ope=edit">
                  <i class="fa-solid fa-pencil"></i>
                </a>
                <?php
              $qf = $mqui->getQxf($dta['quimid']);
              ?>
              <a>
                <button class="form-boton eli" title="Editar" onclick="alertaSuave('home.php?pg=601&quimid=<?= $dta['quimid'];?>&ope=eli')"
                type="button" 
                <?php 
                if ($qf && $qf[0]['fu'] != 0) echo ('disabled style="background:#49459c50;"') ?>
                >
                  <i class="fa fa-trash"></i>
                </button>
              </td>
              <td></td>
            </tr>
      <?php }} ?>
      </tbody>
      <tfoot>
        <tr>
        <th scope="col">Nombre Quimico</th>
        <th scope="col">Información</th>
          <th scope="col">Estado</th>
          <th scope="col" style="text-align:right;" > </th>
          <th></th>
        </tr>
      </tfoot>
    </table>
  </div>
</div>
