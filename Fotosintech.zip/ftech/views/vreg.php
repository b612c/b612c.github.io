<?php 
require_once ('controllers/creg.php');
?>

<div class="content">
	<form action="home.php?pg=102" method="POST">
    	<div class="row">
    		<div class="form-group col-md-6">
    			<label for="perid" class="form-label">Persona: </label>
            	<select required name="perid" id="perid" class="form-select">
                	<option value="" selected>--Seleccione Persona--</option>
                	<?php if($datPer){foreach($datPer AS $dpr){?>
						<option value="<?=$dpr['perid'];?><?php if($datOne && $dpr['perid']==$datOne[0]['perid']) echo 'selected';?>">
						<?=$dpr['ndper']." - ".$dpr['nomper']." ".$dpr['apper'];?>
						</option>
					<?php }};?>
				</select> 
    		</div>
    		<div class="form-group col-12 text-center">
    			<input type="submit" value="Registrar" class="btn btn-prin col-12 col-sm-4 col-lg-3">
    			<input type="hidden" name="ope" value="save">
    			<input type="hidden" name="regid" value="<?php if ($datOne) echo $datOne[0]['regid']; ?>">
    		</div>
    	</div>
    </form>

	<table class="table w-full table-striped dt-responsive">
		<thead>
			<tr>
				<th scope="col" style="width: 20%;">Número de registro</th>
				<th scope="col">Datos de Usuario</th>
				<th scope="col"></th>
				<th></th>
			</tr>
		</thead>
		<tbody>
			<?php if ($datAll) {
				foreach ($datAll as $dta) { ?>
					<tr>
						<td>
							<strong><?=$dta['regid'];?></strong>
						</td>
						<td>
							<?=$dta['ndper'];?>
							<?=$dta['nomper'];?>
							<?=$dta['apper'];?><br>
							<small>
								<strong>Teléfono: </strong>
								<?=$dta['telper'];?><br>
								<strong>Email: </strong>
								<?=$dta['emaper'];?><br>
							</small>
						</td>
						<td style="text-align: center;">
							<a type="button" class="eli" onclick="return eliminar()" href="home.php?pg=102&regid=<?= $dta['regid'];?>&ope=eli">
								<i class="fa fa-trash"></i>
							</a>
							<a type="button" class="edi" href="home.php?pg=102&regid=<?= $dta['regid'];?>&ope=edit">
								<i class="fa fa-pencil"></i>
							</a>
						</td>
						<td></td>
					</tr>
			<?php }
			} ?>
		</tbody>
		<tfoot>
			<tr>
				<th scope="col" style="width: 20%;">Número de registro</th>
				<th scope="col">Datos de Usuario</th>
				<th scope="col"></th>
				<th></th>
			</tr>
		</tfoot>
	</table>
</div>
