<?php 
    require_once ('controllers/cemp.php');
?>
<div class="content">
    <form action="home.php?pg=1001" method="POST" enctype="multipart/form-data">
        <div class="row">
            <div class="borde form-group col-12 col-md-6" >
                <label for="nemp" class="form-label">Nombre de la empresa</label>
                <input type="text" name="nemp" id="nemp" class="form-control" value="<?php if($datOne) echo $datOne[0]['nemp'];?>">
            </div>
            <div class="borde form-group col-12 col-md-6" >
                <label for="nitemp" class="form-label">NIT de la empresa</label>
                <input type="text" name="nitemp" id="nitemp" class="form-control" value="<?php if($datOne) echo $datOne[0]['nitemp'];?>">
            </div>
            <div class="borde form-group col-12 col-md-6" >
                <label for="diremp" class="form-label">Dirección de la empresa</label>
                <input type="text" name="diremp" id="diremp" class="form-control" value="<?php if($datOne) echo $datOne[0]['diremp'];?>">
            </div>
            <div class="borde form-group col-12 col-md-6" >
                <label for="email" class="form-label">Email de la empresa</label>
                <input type="text" name="email" id="email" class="form-control" value="<?php if($datOne) echo $datOne[0]['email'];?>">
            </div>
            <div class="borde form-group col-12 col-md-6" >
                <label for="tel" class="form-label">Telefono de la empresa</label>
                <input type="text" name="tel" id="tel" class="form-control" value="<?php if($datOne) echo $datOne[0]['tel'];?>">
            </div>
            <div class="form-group col-12 col-md-6">
                <label for="arcimg" class="form-label">Logo de la empresa</label>
                <input type="file" name="arcimg" id="arcimg" class="form-control"  accept="image/jpeg, image/jpg, image/avif, image/png, image/gif">
            </div>
            <div class="form-group col-md-6">
                <label for="codDep" class="form-label">Departamento</label>
                <select name="codDep" id=codDep class="form-select" required onchange="javascript:recCiudad(this.value);">
                    <option value="" selected>Seleccione un Departamento</option>
                    <?php $deps = getDep("0");
                        if ($deps) {foreach ($deps as $dp) { ?>
                            <option value="<?= $dp["ubid"]; ?>" <?php if ($datOne && $dp['ubid'] == $datOne[0]['depubi']) echo 'selected'; ?>> <?= $dp["nomubi"]; ?></option>
                    <?php }}?>
                </select>
            </div>
            <div class="form-group col-md-6">
                <label for="ubid" class="form-label" required>Municipio</label>
                <div id="reloadMun">
                    <select name="ubid" id="ubid" class="form-select" reuired>
                        <option value="" selected>Seleccione un Municipio</option>
                        <?php $deps = getDep($datOne[0]['depubi']);
                            if ($deps) { foreach ($deps as $dp) {  ?>
                                <option value="<?= $dp["ubid"]; ?>" <?php if ($datOne && $dp['ubid'] == $datOne[0]['ubid']) echo 'selected'; ?>> <?= $dp["nomubi"]; ?></option>
                        <?php } } ?>
                    </select>
                </div>
            </div>
            <div class="form-group col-12 text-center">
                <input type="hidden" value="save" name="ope">
                <input type="hidden" name="empid" value="<?php if($datOne) echo $datOne[0]['empid'];?>">
                <?php if($empid){ ?>
                    <input type="submit"  class="btn btn-prin col-12 col-sm-4 col-lg-3" value="Actualizar">
                <?php }else{ ?>
                    <input type="submit"  class="btn btn-prin col-12 col-sm-4 col-lg-3" value="Registrar">
                <?php } ?>
            </div>
        </div>
    </form>

    <table class="table w-full table-striped dt-responsive">
        <thead>
            <tr>
                <th>Logo</th>
                <th>Info empresa</th>
                <th>Contacto</th>
                <th></th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            <?php if($datAll){foreach($datAll AS $dta){ ?>
                <tr>
                    <td style="width: 20%">
                        <?php if(file_exists($dta['logo'])) { ?>
                            <img src="<?=$dta['logo'];?>" alt="Foto empresa <?=$dta['nemp'];?>" style="width: 140px;height: 100px;">
                        <?php }else{ ?>
                            <img src="img\noimage.png" style="width: 100px;height: 100px;">
                        <?php } ?>
                    </td>
                    <td>
                        <big><strong><?=$dta['empid'].". ".$dta['nemp'];?></strong></big><br>
                        <strong>Dirección: </strong><?=$dta['diremp']?><br>
                        <strong>NIT: </strong><?=$dta['nitemp']?>
                    </td>
                    <td>
                        <strong>Email: </strong><?=$dta['email']?><br>
                        <strong>Telefono: </strong><?=$dta['tel']?><br>
                        <strong>Ubicación: </strong><?=$dta['nomubi']?>
                    </td>
                    <td  style="text-align: center; ">
                        <a type="button" class="edi" href="home.php?pg=1001&empid=<?=$dta['empid']; ?>&ope=edi" title="Editar">
                            <i class="fa fa-pencil"></i>
                        </a>
                        <a type="button" class="eli" href="home.php?pg=1001&empid=<?=$dta['empid']; ?>&ope=eli">
                            <i class="fa-solid fa-trash"></i>
                        </a>
                    </td>
                    <td></td>
                </tr>
            <?php }} ?> 
        </tbody>
        <tfoot>
            <tr>
                <th>Logo</th>
                <th>Info empresa</th>
                <th>Contacto</th>
                <th></th>
                <th></th>
            </tr>
        </tfoot>
    </table><br><br>
</div>