<div class="container" id="container">
	<div class="form-container sign-in">
			<form role="form" action="models/control.php" method="POST">
                <img class="logo" src="img/icon/logo-ftch.svg" style="width: 150px; height: 150px;">
				<h2>- Inicio sesión -</h2>
				<!-- <div class="social-icons">
					<a href="#" class="icon"><i class="fa-brands fa-instagram"></i></a>
					<a href="#" class="icon"><i class="fa-brands fa-facebook-f"></i></a>
					<a href="#" class="icon"><i class="fa-brands fa-linkedin"></i></a>
				</div> -->
				<span>Ingrese su correo y contraseña</span>
				<input type="email" class="input" name="username" id="username" placeholder="Email" required>
				<input type="password" class="input" name="password" id="password" placeholder="Contraseña" required>
				<input type="submit" class="btn" value="Ingresar">
			</form>
	</div>
	<div class="form-container sign-up" id="rccla">
		<form role="form" action="rccla.php" method="post">
				<img class="logo" src="img/icon/logo-ftch.svg" style="width: 150px; height: 150px;">
				<h2>Recuperar su cuenta</h2>
				<!-- <div class="social-icons">
						<a href="#" class="icon"><i class="fa-brands fa-instagram"></i></a>
						<a href="#" class="icon"><i class="fa-brands fa-facebook-f"></i></a>
						<a href="#" class="icon"><i class="fa-brands fa-linkedin"></i></a>
					</div> -->
			
					
							<span>Ingrese su correo para recuperar su cuenta</span>

							<input type="email" name="email" class="input" placeholder="Email" required autocomplete="off" />
						<input type="submit" class="btn" value="ENVIAR" />
				</form>
	</div>
	<div class="toggle-container">
			<div class="toggle">
				<div class="toggle-panel toggle-left">
					<h2>Da click en el enlace para iniciar sesión</h2>
					<p>Ingrese su informacion personal para poder usar nuestro software</p>
					<input type="submit" id="login" value="Iniciar sesion" class="hidden btn">
				</div>
				<div class="toggle-panel toggle-right">
					<h2 id="h2">Bienvenido/a a Fotosintech</h2>
					<p>Si usted no recuerda su información de acceso, por favor dirijase al link "Olvido su contraseña" y siga el proceso</p>
					<input type="submit" id="register" value="¿Olvido su contraseña?" class="hidden btn">
				</div>
			</div>  
	</div>
</div>
