<?php  
include('controllers/cpef.php');
?>

<div class="content">
  <form action="" role="form" method="POST" aria-label="Registro proveedor" class="formulario" id="omfg">

      <div class="row">
        <div class="form-group col-md-6">
          <label for="pefnom">Nombre del perfil</label>
          <input type="text" name="pefnom" id="pefnom" class="form-control" value="<?php if($datOne) echo $datOne[0]['pefnom'];?>" required>
        </div>
        <div class="form-group col-md-6">
          <label for="pagid">Pagina inicial</label>
          <select name="pagid" id="pagid" class="form form-select" required>
            <?php if($datPag){foreach($datPag AS $dpg){?>
              <option value="<?=$dpg['pagid'];?>" <?php if($datOne && $dpg['pagid']==$datOne[0]['pagid']) 
                  echo " selected ";?>><?=$dpg['pagnom'];?>
              </option>
            <?php }}?>
          </select>
        </div>
        <div class="form-group col-md-6">
          <label for="modid">Modulo</label>
          <select name="modid" id="modid" class="form form-select" required>
            <?php if($datMod){foreach($datMod AS $dmd){?>
              <option value="<?=$dmd['modid'];?>" <?php if($datOne && $dmd['modid']==$datOne[0]['modid']) 
                  echo " selected ";?>><?=$dmd['nomod'];?>
              </option>
            <?php }}?>
          </select>
        </div>
      </div>
    <div class="form-group col-md-12">
      <div class="form-group text-center">
      <?php if($pefid){ ?>
        <input type="submit"  class="btn btn-prin col-12 col-sm-4 col-lg-3" value="Actualizar">
      <?php }else{ ?>
        <input type="submit"  class="btn btn-prin col-12 col-sm-4 col-lg-3" value="Registrar">
      <?php } ?>      
      <input type="hidden" name="ope" value="save">
      <input type="hidden" name="pefid" value="<?php if($datOne) echo $datOne[0]['pefid'];?>">
    </div>
  </form>

  <table class="table w-full table-striped dt-responsive">
    <caption></caption>
    <thead>
      <tr>
        <th scope="col">Perfiles</th>
        <th scope="col"></th>
        <th></th>
      </tr>
    </thead>
    <tbody>
      <?php if($datAll){ foreach($datAll AS $dta){ ?>
      <tr>
        <td>
          <strong>
            <?=$dta['pefid']." - ".$dta['pefnom']; ?>
          </strong>
          <br>
          <small>
            <strong>Página Inicial: </strong><?=$dta['pagnom']?> 
            <strong>Módulo: </strong><?=$dta['nomod']?>
          </small>
        </td>
        <td style="text-align: right;">
          <a class="edi" type="button" href="home.php?pg=401&pefid=<?=$dta['pefid'];?>&ope=edit">
            <i class="fa fa-pencil"></i>
          </a>
          <a class="view" type="button" href="#" data-bs-toggle="modal" data-bs-target="#<?= "mdlchk" . $dta['pefid'] ?>" title="Paginas Por perfil">
            <i class="fa-solid fa-list-check"></i>
          </a>
          <?php
              $mpef->setModid($dta['modid']);
              $dmt = $mpef->getPag();
              $mpef->setPefid($dta['pefid']);
              $dps = $mpef->selPXP();
              $dms = arrstr($dps);
              mchk("mdlchk", $dta['pefid'], $dta['pefnom'], $dmt, $pg, $dms);
          ?>
          <a type="button" class="eli" href="home.php?pg=401&pefid=<?=$dta['pefid'];?>&ope=eli">
            <i class="fa-solid fa-trash"></i>
          </a>
        </td>
        <td></td>
      </tr>
      <?php }} ?>
    </tbody>
    <tfoot>
      <tr>
        <th scope="col">Perfiles</th>
        <th scope="col"></th>
        <th></th>
      </tr>
    </tfoot>
  </table>
</div>
