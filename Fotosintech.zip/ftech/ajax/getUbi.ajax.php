<?php
include "../models/conexion.php";
$ubid = $_POST['data'];

function getUbid($ubid)
{
  $mod = new conexion();
  $con = $mod->get_conexion();
  $sql = "SELECT ubid, nomubi, depubi, estubi, cddubi FROM ubicacion WHERE depubi = :depubi";
  $stmt = $con->prepare($sql);
  $stmt->bindParam(":depubi", $depubi);
  $stmt->execute();
  return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

$data = getUbid($ubid);

if ($data) {
  echo json_encode(["status" => true, "msg" => "Datos encontrados", "data" => $data]);
} else {
  echo json_encode(['status' => false, 'msg' => 'No se encontro datos']);
}
