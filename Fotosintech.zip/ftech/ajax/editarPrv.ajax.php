<?php
include "../models/conexion.php";
include "../models/mper.php";

$noidepro = $_POST['noidepro'];

$mprv = new Mprv();
$mprv->setNoidepro($noidepro);

$data = $mprv->getOne();

if ($data) {
  echo json_encode(["status" => true, "msg" => "Datos encontrados", "data" => $data[0]]);
} else {
  echo json_encode(['status' => false, 'msg' => 'No se encontro datos']);
}