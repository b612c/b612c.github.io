<?php
include('models/mmen.php');

$mmen = new Mmen();
$dat = $mmen->getMen();

function validar($pagid){
	$mmen = new Mmen();
	$mmen->setPagid($pagid);
	$dat = $mmen->getVal();
	return $dat;
}
