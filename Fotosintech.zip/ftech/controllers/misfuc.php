<?php
function titulo($ico, $pagnom){
	$txt = '';
	$txt .= '<div class="titu">';
		$txt .= '<img class="tit-img" src="img/icon/'.$ico.'">';
		$txt .= ' '.$pagnom;
		$txt .= '<hr class="mibarra">';
	$txt .= '</div>';
	echo $txt;
}


function mchk($nm, $id, $tit, $mt, $pg, $dms)
{
  $txt = '';
  $txt .= '<div class="modal fade" id="' . $nm . $id . '" tabindex="-1" aria-labelledby="" aria-hidden="true">';
    $txt .= '<div class="modal-dialog">';
      $txt .= '<div class="modal-content">';
        $txt .= '<div class="modal-header">';
          $txt .= '<h1 class="modal-title fs-5" style="color: #2e7e95;font-weight: bold !important;">Páginas - ' . $tit . '</h1>';
          $txt .= '<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>';
        $txt .= '</div>';
        $txt .= '<form action="home.php?pg=' . $pg . '" method="POST">';
          $txt .= '<div class="modal-body">';
            $txt .= '<input type="hidden" value="' . $id . '" name="pefid">';
            $txt .= '<div class="row">';
              if ($mt) {
                foreach ($mt as $tm) {
                  $txt .= '<div class="form-group col-md-6" style="text-align: left !important;">';
                    $pos = strpos($dms, $tm['pagid']);
                    $txt .= '<input type="checkbox" name="chk[]" value="' . $tm['pagid'] . '"';
                    if ($pos > -1) $txt .= ' checked ';
                    $txt .= '> ';
                    $txt .= $tm['pagnom'];
                  $txt .= '</div>';
                }
              }
            $txt .= '</div>';
          $txt .= '</div>';
          $txt .= '<div class="modal-footer">';
            $txt .= '<button type="button" class="btn btn-sec" data-bs-dismiss="modal">Cerrar</button>';
            $txt .= '<input type="hidden" value="savepxp" name="ope">';
            $txt .= '<input type="submit" class="btn btn-prin" value="Guardar">';
          $txt .= '</div>';
        $txt .= '</form>';
      $txt .= '</div>';
    $txt .= '</div>';
  $txt .= '</div>';
  echo $txt;
}

function mcmb($nm, $id, $tit, $mt, $pg, $dm){
  $mper = new Mper();
  $txt = '';
  $txt .= '<div class="modal fade" id="'.$nm.$id.'" tabindex="-1" aria-labelledby="'.$nm.$id.'label" aria-hidden="true">';
    $txt .= '<div class="modal-dialog" style="text-align: left;">';
      $txt .= '<div class="modal-content">';
        $txt .= '<div class="modal-header">';
          $txt .= '<h3 class="modal-title" id="'.$nm.$id.'label" style="color: #2e7e95;font-weight: bold !important;">Perfiles - '.$tit.'</h3>';
          $txt .= '<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>';
        $txt .= '</div>';
        $txt .= '<div class="modal-body">';
        $txt .= '<form action="home.php?pg='.$pg.'" method="POST">';
            $txt .= '<input type="hidden" value="'.$id.'" name="perid">';
              $txt .= '<div class="row form-group">';
                if ($mt) { foreach ($mt as $dt) {
                  $dtpg = $mper->getOnePef($dt['modid']);
                  $txt .= '<div class="col-md-6 col-8" >';
                    $txt .= '<label for="modid" class="form-label">'.$dt['nomod'].'</label>';
                    $txt .= '<input type="hidden" name="modid[]" value="'.$dt['modid'].'">';
                    $txt .= '<select name="pefid[]" id="pefid" class="form-select" required>';
                      $txt .= '<option value="0">Sin perfil</option>';
                        if ($dtpg) { foreach ($dtpg as $td) {
                          $pos = strpos($dm, $td['pefid']);
                            $txt .= '<option value="'.$td['pefid'].'" ';
                              if ($pos > -1) $txt .= 'selected';
                                $txt .= '>' . $td['pefnom'] . '</option>';
                              }
                          }
                    $txt .= '</select>';
                  $txt .= '</div>';
                } }
              $txt .= '</div>';
          $txt .= '</div>';
          $txt .= '<div class="modal-footer">';
            $txt .= '<button type="button" class="btn btn-sec" data-bs-dismiss="modal">Cerrar</button>';
            $txt .= '<input type="hidden" value="savepxf" name="ope">';
            $txt .= '<input type="submit" class="btn btn-prin" value="Guardar">';
            $txt .= '</div>';
          $txt .= '</form>';
      $txt .= '</div>';
    $txt .= '</div>';
  $txt .= '</div>';
  echo $txt;
}

function arrstr($dt){
  $txt = "";
  if ($dt) {
    foreach ($dt as $d) {
      $txt .= $d['pagid'] . ",";
    }
  }
  return $txt;
}

function ManejoError($e)
{
  if (strpos($e->getMessage(), '1451')) {
    echo '<script>err("No se puede eliminar este registro. Por que se encuentra relacionado en otra opción.");</script>';
  } elseif (strpos($e->getMessage(), '1062')) {
    echo '<script>err("Registro duplicado. Intente nuevamente con otro número de identificación ó comuníquese con el administrador del sistema.");</script>';
  } else {
    echo '<script>err("Se generó un error comuníquese con el administrador del sistema.");</script>';
  }
}
?>