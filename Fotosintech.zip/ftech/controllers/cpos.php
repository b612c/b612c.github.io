<?php
require_once("models/mpos.php");
require_once("models/mbloq.php");
require_once("models/mval.php");
require_once("models/mflor.php");

define("THISPG", '<script>window.location = "home.php?pg=303"</script>');
$mpos = new Mpos();
$mbloq = new Mbloq();
$mval = new Mval();
$mflor = new Mflor();

$cosecid = isset($_REQUEST['cosecid']) ? $_REQUEST['cosecid'] : NULL;
$bloqid = isset($_REQUEST['bloqid']) ? $_REQUEST['bloqid'] : NULL;
$fech = date("Y-m-d H:i:s");
$cant = isset($_POST['cant']) ? $_POST['cant'] : NULL;
$florid = isset($_REQUEST['florid']) ? $_REQUEST['florid'] : NULL;
$ncajas = isset($_POST['ncajas']) ? $_POST['ncajas'] : NULL;
$tam = isset($_POST['tam']) ? $_POST['tam'] : NULL;
$emp = isset($_POST['emp']) ? $_POST['emp'] : NULL;
$perid = $_SESSION['perid'];
$ope = isset($_REQUEST['ope']) ? $_REQUEST['ope'] : NULL;
$datOne = NULL;

$mpos->setCosecid($cosecid);
if ($ope == "save") {
        $mpos->setBloqid($bloqid);
        $mpos->setFech($fech);
        $mpos->setCant($cant);
        $mpos->setFlorid($florid);
        $mpos->setNcajas($ncajas);
        $mpos->setTam($tam);
        $mpos->setEmp($emp);
        $mpos->setPerid($perid);
        
         echo '<script>window.location = "home.php?pg='.$pg.'"</script>';
        if (!$cosecid) {
            $mpos->save();
           
         echo '<script>window.location = "home.php?pg='.$pg.'"</script>';
            
        } else {
            $mpos->edit();
         echo '<script>window.location = "home.php?pg='.$pg.'"</script>';
        }
    }
    if ($ope == "eli" && $cosecid)$mpos->del();
    $datVal = $mval->getAll(); 
    $datAll = $mpos->getAll(); 
    $datMbloq = $mbloq->getAll();
    $datMflor = $mflor->getAll();
    $datImpr = $mpos->Impr();
    $Suma = $mpos->Cant();
    $Totalt = $mpos->Total();

?>