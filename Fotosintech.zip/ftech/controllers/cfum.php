<?php
require_once("models/mfum.php");
require_once("models/mbloq.php");
require_once("models/mfit.php");
require_once("models/mqui.php");
define("THISPG",'<script>window.location = "home.php?pg=304"</script>');
$mfum = new Mfum();
$mfit = new Mfit();
$mbloq = new Mbloq();
$mqui = new Mqui();
$fumid = isset($_REQUEST['fumid']) ? $_REQUEST['fumid'] : NULL;
$bloqid = isset($_REQUEST['bloqid']) ? $_REQUEST['bloqid'] : NULL;
$quimid = isset($_REQUEST['quimid']) ? $_REQUEST['quimid'] : NULL;
$fecha = date("Y-m-d H:i:s");
$perid = $_SESSION['perid'];
$ncamas = isset($_POST['ncamas']) ? $_POST['ncamas'] : NULL;
$totagua = isset($_POST['totagua']) ? $_POST['totagua'] : NULL;
$totquim = isset($_POST['totquim']) ? $_POST['totquim'] : NULL;

$ope = isset($_REQUEST['ope']) ? $_REQUEST['ope'] : NULL;
$datOne = NULL;

$mfum->setPerid($perid);
$mfum->setFumid($fumid);

if ($ope == "save") {
        $mfum->setBloqid($bloqid);
        $mfum->setQuimid($quimid);
        $mfum->setFecha($fecha);
        $mfum->setPerid($perid);
        $mfum->setNcamas($ncamas);
        $mfum->setTotagua($totagua);
        $mfum->setTotquim($totquim);
         echo '<script>window.location = "home.php?pg='.$pg.'"</script>';
        if (!$fumid) {
            $mfum->save();
             echo '<script>window.location = "home.php?pg='.$pg.'"</script>';
        }
    }
if ($ope == "eli" AND $fumid)$mfum->del();

$datAll = $mfum->getAll();
$datMbloq = $mbloq->getAll();
$datMfit = $mfit ->getAll();
$datMqui = $mqui ->getAll(); 
$datGrafic = $mfum ->grafic();
?>