<?php
include("models/mqui.php");
require_once("models/mfit.php");

define("THISPG", '<script>window.location = "home.php?pg=601"</script>');
$mqui = new Mqui();
$mfit = new Mfit();

$quimid = isset($_REQUEST['quimid']) ? $_REQUEST['quimid'] : NULL;
$nomquim = isset($_POST['nomquim']) ? $_POST['nomquim'] : NULL;
$actquim = isset($_REQUEST['actquim']) ? $_REQUEST['actquim'] : NULL;
$ingreact = isset($_POST['ingreact']) ? $_POST['ingreact']: NULL;
$fitoid = isset($_POST['fitoid']) ? $_POST['fitoid']: NULL;
$ope = isset($_REQUEST['ope']) ? $_REQUEST['ope'] : NULL;
$datOne = NULL;

$mqui->setQuimid($quimid);



if ($ope == "save") {
        $mqui->setQuimid($quimid);
        $mqui->setNomquim($nomquim);
        $mqui->setActquim($actquim);
        $mqui->setQuimid($quimid);
        $mqui->setIngreact($ingreact);
        $mqui->setFitoid($fitoid);
         echo '<script>window.location = "home.php?pg='.$pg.'"</script>';
    
        if (!$quimid) {
            $mqui->save();
             echo '<script>window.location = "home.php?pg='.$pg.'"</script>';
        }else {
            $mqui->edit();
             echo '<script>window.location = "home.php?pg='.$pg.'"</script>';
        }
    }
    if($ope=='act' && $quimid){
        $mqui->setActquim($actquim);
        $mqui->Actquim();
    }
if ($ope == "eli" AND $quimid)$mqui->del();
if ($ope == "edit" && $quimid) {
    $datOne = $mqui->getOne();
}

$datAll = $mqui->getAll();
$datMfit = $mfit->getAll();
?>