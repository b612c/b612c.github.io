<?php 
require_once ('models/mper.php');
require_once ('models/mpag.php');
require_once ('models/memp.php');

$mper = new Mper();
$mpag = new Mpag();
$memp = new Memp();


$perid = isset($_REQUEST['perid']) ? $_REQUEST['perid']:NULL;
$ndper = isset($_POST['ndper']) ? $_POST['ndper']:NULL;
$nomper = isset($_POST['nomper']) ? $_POST['nomper']:NULL;
$apper = isset($_POST['apper']) ? $_POST['apper']:NULL;
$emaper = isset($_POST['emaper']) ? $_POST['emaper']:NULL;
$passper = isset($_POST['passper']) ? $_POST['passper']:NULL;
$dirper = isset($_POST['dirper']) ? $_POST['dirper']:NULL;
$telper = isset($_POST['telper']) ? $_POST['telper']:NULL;
$ubid = isset($_POST['ubid']) ? $_POST['ubid']:NULL;
$foto = isset($_FILES['foto']) ? $_FILES['foto']:NULL;
$estper = isset($_POST['estper']) ? $_POST['estper']:NULL;
$fecnacper = isset($_POST['fecnacper']) ? $_POST['fecnacper']:NULL;
$ocuper = isset($_POST['ocuper']) ? $_POST['ocuper']:NULL;
$tipdper = isset($_POST['tipdper']) ? $_POST['tipdper']:NULL;
$actper = isset($_REQUEST['actper']) ? $_REQUEST['actper']:NULL;
$sexo = isset($_POST['sexo']) ? $_POST['sexo']:NULL;
$empid = isset($_REQUEST['empid']) ? $_REQUEST['empid']:NULL ;
$pefid = isset($_POST['pefid']) ? $_POST['pefid']:NULL;
$arcimg = isset($_FILES['arcimg']) ? $_FILES['arcimg']:NULL;


$ope = isset($_REQUEST['ope']) ? $_REQUEST['ope']:NULL;
$datOne=NULL;

$img=null;

if($foto) {
    $img = opti($foto, "per", "img", $nmfl);
}
$mper->setPerid($perid);
    if($ope=="save" ){
        $mper->setNdper($ndper);
        $mper->setNomper($nomper);
        $mper->setApper($apper);
        $mper->setEmaper($emaper);
        $mper->SetPassper(sha1(md5($passper))."Xg5%");
        $mper->setDirper($dirper);
        $mper->setTelper($telper);
        $mper->setUbid($ubid);
        $mper->setFoto($img);

        $mper->setEmpid($empid);
        $mper->setEstper($estper);
        $mper->setFecnacper($fecnacper);
        $mper->setOcuper($ocuper);
        $mper->setTipdper($tipdper);
        $mper->setActper($actper);
        $mper->setSexo($sexo);
        if($perid) {$mper->edit();}
        else $mper->save();
        echo '<script>window.location = "home.php?pg='.$pg.'"</script>';
    }
    if($ope=="eli" && $perid) $mper->del();

    if($ope=="savepxf"){
        if($perid) $mper->delPxF();
        if($pefid){ foreach ($pefid as $pf) {
            if($pf){
                $mper->setPefid($pf);
                $mper->savePxF();
            }
        }}
    }
    if($perid && $ope=="act"){
        $mper->setActper($actper);
        $mper->Actper();
    }


    if($perid AND $ope=="edi"){
        $datOne = $mper->getOne();
    }
    
    $datAll = $mper->getAll($pg);
    $datEmp = $memp->getAll();
    $mod = $mpag->getMod();    
    $datVal = $mper->valor();



    function getDep($depubi){
        $mod = new conexion();
        $con = $mod->get_conexion();
        $sql = "SELECT ubid, nomubi, depubi, estubi, cddubi FROM ubicacion WHERE depubi = :depubi";
        $stmt = $con->prepare($sql);
        $stmt->bindParam(":depubi", $depubi);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
?>