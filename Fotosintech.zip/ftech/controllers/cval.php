<?php
    include('models/mval.php');
    include('models/mdom.php');
    define("THISPG", '<script>window.location = "home.php?pg=605"</script>');
   
    $mval = new Mval();
    $mdom = new Mdom();
    $valid = isset($_REQUEST['valid']) ? $_REQUEST['valid'] : NULL;
    $domid = isset($_REQUEST['domid']) ? $_REQUEST['domid']:NULL;
    $nomval = isset($_POST['nomval']) ? $_POST['nomval'] : NULL;
    $parval = isset($_POST['parval']) ? $_POST['parval']:NULL;
    $actval = isset($_REQUEST['actval']) ? $_REQUEST['actval'] : NULL;
    
    $ope = isset($_REQUEST['ope']) ? $_REQUEST['ope'] : NULL;
    $datOne = NULL;    
    $mval -> setValid($valid);
    if($ope == "save"){
        $mval ->setValid($valid);
        $mval->setNomval($nomval);
        $mval->setDomid($domid);
        $mval->setParval($parval);
        $mval->setActval($actval);
         echo '<script>window.location = "home.php?pg='.$pg.'"</script>';
        if(!$valid){
            $mval -> save();
             echo '<script>window.location = "home.php?pg='.$pg.'"</script>';
        }else{
             $mval -> edit();
              echo '<script>window.location = "home.php?pg='.$pg.'"</script>';
        }
    }
    if($ope=='act' && $valid){
        $mval->setActval($actval);
        $mval->Actval();
    }
    if ($ope == "eli" AND $valid)$mval->del();
    if ($ope == "edit" && $valid) {
        $datOne = $mval->getOne();
    }
    $datAll = $mval -> getAll();
    $datDom = $mdom-> getALL();
?>