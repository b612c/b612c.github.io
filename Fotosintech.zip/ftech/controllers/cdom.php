<?php
    include('models/mdom.php');
    define("THISPG", '<script>window.location = "home.php?pg=604"</script>');
    $mdom = new Mdom();
    $domid = isset($_REQUEST['domid']) ? $_REQUEST['domid'] : NULL;
    $nomd = isset($_REQUEST['nomd']) ? $_REQUEST['nomd'] : NULL;
    $ope = isset($_REQUEST['ope']) ? $_REQUEST['ope'] : NULL;
    $datOne = NULL;    
    $mdom -> setDomid($domid);
    if ($ope == "save") {
        $mdom->setDomid($domid);
        $mdom->setNomd($nomd);
            if (!$domid) {
                $mdom->save();
                echo '<script>window.location = "home.php?pg='.$pg.'"</script>';
            } else {
                $mdom->edit();
                echo '<script>window.location = "home.php?pg='.$pg.'"</script>';
            }
        }
    if ($ope == "eli" AND $domid)$mdom->del();
    if ($ope == "edit" && $domid) {
        $datOne = $mdom->getOne();
    }

    $datAll = $mdom -> getAll();
    // $datGra = $mdom -> datGrf();
?>