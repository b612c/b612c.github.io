<?php
    include("models/mbloq.php");
    require_once('models/mcam.php');
    require_once ('models/memp.php');

    define("THISPG", '<script>window.location = "home.php?pg=103"</script>');
    $mbloq = new Mbloq(); $mcam = new Mcam(); $memp = new Memp();

    $bloqid = isset($_REQUEST['bloqid']) ? $_REQUEST['bloqid']:NULL ;
    $nombloq = isset($_POST['nombloq']) ? $_POST['nombloq']:NULL ;
    $empid = isset($_REQUEST['empid']) ? $_REQUEST['empid']:NULL ;
    $camid = isset($_REQUEST['camid']) ? $_REQUEST['camid']:NULL ;
    $ope = isset($_REQUEST['ope']) ? $_REQUEST['ope']:NULL;

    $datOne = NULL;

    $mbloq->setBloqid($bloqid);
    if($ope=="save"){
        $mbloq->setnombloq($nombloq);
        $mbloq->setEmpid($empid);
        $bloqid = $mbloq->save();
        foreach($camid as $cm) {
            $mbloq->saveBxC($bloqid, $cm);
        }
        echo '<script>window.location = "home.php?pg='.$pg.'"</script>';
    }

    if($ope=="eli" AND $bloqid) $mbloq->delBxc(); $mbloq->del();

    $datAll = $mbloq->getAll();
    $datCam = $mcam->getAll();
    $datEmp = $memp->getAll();


?>