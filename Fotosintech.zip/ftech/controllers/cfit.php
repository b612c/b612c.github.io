<?php
require_once("models/mfit.php");
define("THISPG", '<script>window.location = "home.php?pg=503"</script>');
$mfit = new Mfit();
$fitoid = isset($_REQUEST['fitoid']) ? $_REQUEST['fitoid'] : NULL;
$tpfito = isset($_REQUEST['tpfito']) ? $_REQUEST['tpfito'] : NULL;
$nomfito = isset($_POST['nomfito']) ? $_POST['nomfito'] : NULL;

$ope = isset($_REQUEST['ope']) ? $_REQUEST['ope'] : NULL;
$datOne = NULL;

$mfit->setFitoid($fitoid);
if ($ope == "save") {
        $mfit->setFitoid($fitoid);
        $mfit->setTpfito($tpfito);
        $mfit->setNomfito($nomfito);
        echo '<script>window.location = "home.php?pg='.$pg.'"</script>';
        if (!$fitoid) {
            $mfit->save();
            echo '<script>window.location = "home.php?pg='.$pg.'"</script>';
        } else {
            $mfit->edit();
            echo '<script>window.location = "home.php?pg='.$pg.'"</script>';
        }
    }
if ($ope == "eli" AND $fitoid)$mfit->del();
if ($ope == "edit" && $fitoid) {
    $datOne = $mfit->getOne();
}
$datAll = $mfit->getAll();
?>