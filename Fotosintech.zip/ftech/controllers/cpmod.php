<?php require_once ('models/mmod.php');

$mmod = new Mmod();

$modid = isset($_POST['modid']) ? $_POST['modid']:NULL;
$perid = isset($_SESSION['perid']) ? $_SESSION['perid']:NULL;

$ope = isset($_REQUEST['ope']) ? $_REQUEST['ope']:NULL;

if($ope=="dircc" AND $perid AND $modid){
	$mmod->setModid($modid);
	$datPrPfMd = $mmod->getOnePrPfMd();
	if($datPrPfMd){
		$_SESSION['pefid'] = $datPrPfMd[0]['pefid'];
		$_SESSION['pefnom'] = $datPrPfMd[0]['pefnom'];
		echo '<script>window.location=\'home.php?pg='.$datPrPfMd[0]['pagid'].'\';</script>';
	}
}

$datAll = $mmod->getAllAct();
$datPrPf = $mmod->getOnePrPf();
?>