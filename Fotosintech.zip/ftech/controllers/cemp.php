<?php
    require_once ('models/memp.php');

    $memp = new Memp();

    $empid = isset($_REQUEST['empid']) ? $_REQUEST['empid']:NULL;
    $ubid = isset($_REQUEST['ubid']) ? $_REQUEST['ubid']:NULL;
    $nemp = isset($_POST['nemp']) ? $_POST['nemp']:NULL;
    $nitemp = isset($_POST['nitemp']) ? $_POST['nitemp']:NULL;
    $diremp = isset($_POST['diremp']) ? $_POST['diremp']:NULL;
    $email = isset($_POST['email']) ? $_POST['email']:NULL;
    $tel = isset($_POST['tel']) ? $_POST['tel']:NULL;
    $logo = isset($_FILES['logo']) ? $_FILES['logo']:NULL;
    $arcimg = isset($_FILES['arcimg']) ? $_FILES['arcimg']:NULL;

    $ope = isset($_REQUEST['ope']) ? $_REQUEST['ope']:NULL;
    $datOne = NULL;

    if($arcimg) $logo = opti($arcimg, "emp", "img", $nmfl);
    $memp->setEmpid($empid);
    if($ope=="save" AND $nitemp){
        $memp->setUbid($ubid);
        $memp->setNemp($nemp);
        $memp->setNitemp($nitemp);
        $memp->setDiremp($diremp);
        $memp->setEmail($email);
        $memp->setTel($tel);
        $memp->setLogo($logo);
        if($empid) $memp->edit(); 
        else $memp->save();
        echo '<script>window.location = "home.php?pg='.$pg.'"</script>';
    }
    if($ope=="eli" AND $empid) $memp->del();
    if($empid AND $ope="edi") $datOne = $memp->getOne();

    $datAll = $memp->getAll();

    function getDep($depubi){
        $mod = new conexion();
        $con = $mod->get_conexion();
        $sql = "SELECT ubid, nomubi, depubi, estubi, cddubi FROM ubicacion WHERE depubi = :depubi";
        $stmt = $con->prepare($sql);
        $stmt->bindParam(":depubi", $depubi);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

?>
