<?php
    require_once('models/mflor.php'); 
    
    $mflor = new Mflor();

    $florid = isset($_REQUEST['florid']) ? $_REQUEST['florid']:NULL; 
    $desf = isset($_POST['desf']) ? $_POST['desf']:NULL; 
    $cuidaf = isset($_POST['cuidaf']) ? $_POST['cuidaf']:NULL;
    $imgf = isset($_FILES['imgf']) ? $_FILES['imgf']:NULL;
    $color = isset($_POST['color']) ? $_POST['color']:NULL;
    $arcimg = isset($_FILES['arcimg']) ? $_FILES['arcimg']:NULL;
    $valid = isset($_REQUEST['valid']) ? $_REQUEST['valid']:NULL;
    $ope = isset($_REQUEST['ope']) ? $_REQUEST['ope']:NULL;
    $datOne = NULL;

    if($arcimg) $imgf = opti($arcimg, "flor", "img", $nmfl);
    $mflor->SetFlorid($florid);
    if($ope=="save" AND $valid){
        $mflor->setDesf($desf);
        $mflor->setCuidaf($cuidaf);
        $mflor->setImgf($imgf);
        $mflor->setValid($valid);
        $mflor->setColor($color);
        if($florid) $mflor->edit(); 
        else $mflor->save();
        echo '<script>window.location = "home.php?pg='.$pg.'"</script>';
    }
    if($ope=="eli" AND $florid) $mflor->del();

    
    if($florid AND $ope="edi") $datOne = $mflor->getOne();

    $datAll = $mflor->getAll();
    $datOne = $mflor->getOne();
    $datTpF = $mflor->getTpF();

    $datClF = $mflor->getClF();

?>