<?php
require_once('models/mmod.php');
require_once('models/mpag.php');

$mpag = new Mpag();
$mmod = new Mmod();

$modid = isset($_REQUEST['modid']) ? $_REQUEST['modid']:NULL;
$nomod = isset($_POST['nomod']) ? $_POST['nomod']:NULL;
$imgmod = NULL;
$actmod = isset($_REQUEST['actmod']) ? $_REQUEST['actmod']:NULL;
$pagid = isset($_POST['pagid']) ? $_POST['pagid']:NULL;
$arcimg = isset($_FILES['arcimg']) ? $_FILES['arcimg']:NULL;

$ope = isset($_REQUEST['ope']) ? $_REQUEST['ope']:NULL;

$datOne = NULL;

$pg = 701;

if($arcimg) $imgmod = opti($arcimg, "mod", "img", $nmfl);
$mmod->setModid($modid);
if($ope=='save'){
	$mmod->setNomod($nomod);
	$mmod->setImgmod($imgmod);
	$mmod->setActmod($actmod);
	$mmod->setPagid($pagid);
	if(!$modid){
		$mmod->save();
	}else{
		$mmod->edit();
	}
	echo '<script>window.location = "home.php?pg='.$pg.'"</script>';

}
if($ope=='act' && $modid){
	$mmod->setActmod($actmod);
	$mmod->edact();
}
if($ope=='del' && $modid){
	$mmod->del();
}
if($ope=='edit' && $modid){
	$datOne = $mmod->getOne();
}

$datAll = $mmod->getAll();
$datPag = $mpag->getAll();

?>