<?php
require_once ("models/mpag.php");

$mpag = new Mpag();

$pagid = isset($_REQUEST['pagid']) ? $_REQUEST['pagid']:NULL;
$editpagid = isset($_REQUEST['editpagid']) ? $_REQUEST['editpagid'] : NULL;

$modid = isset($_POST['modid']) ? $_POST['modid'] : NULL;
$pagnom = isset($_POST['pagnom']) ? $_POST['pagnom']:NULL;
$pagarc = isset($_POST['pagarc']) ? $_POST['pagarc']:NULL;
$pagmos = isset($_REQUEST['pagmos']) ? $_REQUEST['pagmos']:NULL;
//$mosico = isset($_POST['mosico']) ? $_POST['mosico']:NULL;
$pagord = isset($_POST['pagord']) ? $_POST['pagord']:NULL;
$pagmen = isset($_POST['pagmen']) ? $_POST['pagmen']:NULL;
$icono = NULL;
$arcimg = isset($_FILES['arcimg']) ? $_FILES['arcimg']:NULL;

$ope = isset($_REQUEST['ope']) ? $_REQUEST['ope']:NULL;
$datOne = NULL;

if($arcimg) $icono = opti($arcimg, "pag", "img", $nmfl);

$mpag->setPagid($pagid);

if($pagid AND $ope == "save"){
	$mpag->setPagid($pagid);
	$mpag->setModid($modid);
	$mpag->setPagnom($pagnom);
	$mpag->setPagarc($pagarc);
	$mpag->setPagmos($pagmos);
	$mpag->setPagord($pagord);
	$mpag->setPagmen($pagmen);
	$mpag->setIcono($icono);
	$mpag->setEditpagid($editpagid);
	if($editpagid){
		$mpag->edit();
	}else{
		$mpag->save();
	}
	echo '<script>window.location = "home.php?pg='.$pg.'"</script>';

}
if($ope=='mos' AND $pagid){
	$mpag->setPagmos($pagmos);
	$mpag->edmos();
}
if($editpagid AND $ope == "edit"){
	$mpag->setPagid($editpagid);
	$datOne = $mpag->getOne();
}
if($pagid AND $ope == "delete"){
	$mpag->del();
}
$datmod = $mpag->getMod();
$datAll = $mpag->getAll();
?>