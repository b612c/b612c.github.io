<?php
require_once('models/mpef.php');
require_once('models/mpag.php');

$mpag = new Mpag();
$mpef = new Mpef(); 

    $pefid = isset($_REQUEST['pefid']) ? $_REQUEST['pefid']: NULL;
    $pefnom = isset($_POST['pefnom']) ? $_POST['pefnom']: NULL;
    $modid = isset($_POST['modid']) ? $_POST['modid']: NULL;
    $pagnom = isset($_POST['pagnom']) ? $_POST['pagnom']: NULL;
    $pagid = isset($_POST['pagid']) ? $_POST['pagid']: NULL;
    $chk = isset($_POST['chk']) ? $_POST['chk']: NULL;
    $ope = isset($_REQUEST['ope']) ? $_REQUEST['ope']: NULL;
    $datOne = NULL;

$mpef->setPefid ($pefid);
    if($ope=="savepxp"){
        if($pefid) $mpef->delPxP();
        if($chk){ foreach($chk AS $ck){
            $mpef->setPagid ($ck);
            $mpef->savePxP();
        } }
    }
    if($ope=="save"){
        if($pefnom AND $pagid AND $modid){
            $mpef->setPefnom($pefnom);
            $mpef->setModid($modid);
            $mpef->setPagid($pagid);
            if($pefid){ 
                $mpef->edit();
                echo '<script>window.location = "home.php?pg='.$pg.'"</script>';
            }else {
                $mpef->save();
            }
        }
    }
    if($pefid AND $ope=="edit"){
        $datOne = $mpef->getOne();
    }
    if($pefid AND $ope=="eli") $mpef->del();


$datAll = $mpef->getAll();
$datPag = $mpag->getAll();
$datMod = $mpag->getMod();

?>
