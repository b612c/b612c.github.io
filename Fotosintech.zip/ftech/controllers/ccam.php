<?php
require_once('models/mcam.php'); require_once('models/mflor.php'); require_once('models/mval.php');

$mcam = new Mcam(); $mflor = new Mflor(); $mval = new Mval();

$camid = isset($_REQUEST['camid']) ? $_REQUEST['camid']:NULL;
$florid = isset($_POST['florid']) ? $_POST['florid']:NULL;
$ope = isset($_REQUEST['ope']) ? $_REQUEST['ope']:NULL;
$datOne = NULL;

$mcam->setCamid($camid);
if($ope=="save"){
    $mcam->setFlorid($florid);
    $mcam->save();
    echo '<script>window.location = "home.php?pg='.$pg.'"</script>';

}
if($ope=="eli" AND $camid) $mcam->del();

$datAll = $mcam->getAll();
$datFlor = $mflor->getAll();
$datMval = $mval->getAll(); 

?>