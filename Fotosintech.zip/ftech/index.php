<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fotosintech</title>
    <link rel="shortcut icon" href="img/icon/logo-ftch.svg">

    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" crossorigin="anonymous" referrerpolicy="no-referrer"/>
    <!-- <link rel="stylesheet" href="css/estilos.css"> -->
    <link rel="stylesheet" href="css/log.css">
</head>
<body>
    <?php
        $pg = isset($_GET['pg']) ? $_GET['pg'] : null;
        if ($pg == '101') {
            include_once "views/log.php";
        }else {
            include_once "views/log.php";
        }
        require_once("views/pie.php");
        ?>
    <script src="js/login.js"></script>

</body>
</html>