$(document).ready(function () {
    $('.table').DataTable( {
      "language": {
          "decimal": "",
          "emptyTable": "No hay información",
          "info": "Mostrando _START_ a _END_ de _TOTAL_ Entradas",
          "infoEmpty": "Mostrando 0 to 0 of 0 Entradas",
          "infoFiltered": "(Filtrado de _MAX_ total entradas)",
          "infoPostFix": "",
          "thousands": ",",
          "lengthMenu": "Mostrar _MENU_ Entradas",
          "loadingRecords": "Cargando...",
          "processing": "Procesando...",
          "search": "Buscar:",
          "zeroRecords": "Sin resultados encontrados",
          "paginate": {
              "first": "Primero",
              "last": "Ultimo",
              "next": ">",
              "previous": "<"
          }
      }
  });
});

function alertaSuave(ruta) {
    let rutaC = location.href
    Swal.fire({
      icon: 'warning',
      title: '¿Esta seguro de eliminarlo?',
      text: 'Si no lo esta todavia puede cancelar la acción',
      showConfirmButton: true,
      confirmButtonText: 'Eliminar',
      confirmButtonColor: '#00495c',
      showCancelButton: true,
      cancelButtonText: 'Cancelar',
      cancelButtonColor: '#832626',

    }).then((result) => {
      console.log(result)
      if (result.isConfirmed) {
        window.location = ruta
      } else {
        window.location = rutaC
      }
    })
}


function err(mess = '') {
  let params = new URLSearchParams(location.search)
  p = params.get('pg')
  if (mess) {
      mess = '<strong style="color: #832626">Error:</strong> ¡' + mess + '!'
      document.getElementById('err').innerHTML = mess
      document.getElementById('err').style.display = 'inline-block'
      setTimeout(function () {
        location.href = `home.php?pg=${p}`;
      }, 5000);
    } else {
      document.getElementById('err').innerHTML = 'Prueba'
      document.getElementById('err').style.display = 'none'
    }
}

$(document).ready(function () {
	const ico = document.getElementById('ico');
	$('#btn-m').click(function () {
		$('#sidebar').toggle();
		if ($(ico).hasClass('fa-solid fa-bars')) {
			$(ico).removeClass('fa-solid fa-bars').addClass('fa-solid fa-xmark');
		} else {
			$(ico).removeClass('fa-solid fa-xmark').addClass('fa-solid fa-bars');
		}
	});
});