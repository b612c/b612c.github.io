/** @format */
function recVariedad(value) {
	//alert("Si le llega "+value);
	var parametros = {
		valor: value,
	}
  $.ajax({
		data: parametros,
		url: 'views/selVar.php',
		type: 'post',
		success: function (response) {
      console.log(response)
			$('#reloadVar').html(response)
		},
	})
}
function recCiudad(value) {
	//alert("Si le llega "+value);
	var parametros = {
		valor: value,
	}
	$.ajax({
		data: parametros,
		url: 'views/selmun.php',
		type: 'post',
		success: function (response) {
			$('#reloadMun').html(response)
		},
	})
}
function recQuim(value) {
	var parametros = {
		valor: value,
	}
  $.ajax({
		data: parametros,
		url: 'views/selQuim.php',
		type: 'post',
		success: function (response) {
      console.log(response)
			$('#reloadQuim').html(response)
		},
	})
}
function recCama(value) {
	var parametros = {
		valor: value,
	}
  $.ajax({
		data: parametros,
		url: 'views/selCam.php',
		type: 'post',
		success: function (response) {
      console.log(response)
			$('#reloadCam').html(response)
		},
	})
}
var lang_es = {
	months: [
		'Enero',
		'Febrero',
		'Marzo',
		'Abril',
		'Mayo',
		'Junio',
		'Julio',
		'Agosto',
		'Septiembre',
		'Octubre',
		'Noviembre',
		'Diciembre',
	],
	weekdays: ['Domingo', 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado'],
	downloadJPEG: 'Descargar Imagen JPEG',
	downloadPDF: 'Descargar Documento PDF',
	downloadPNG: 'Descargar Imagen PNG',
	downloadSVG: 'Descargar Imagen SVG',
	downloadCSV: 'Descargar SVG',
	downloadXLS: 'Descargar XLS',
	printChart: 'Imprimir chart',
	resetZoom: 'Resetear zoom',
	resetZoomTitle: 'Resetear zoom',
	hideData: 'Ocultar tabla de datos',
	viewData: 'Mostrar tabla de datos',
	viewFullscreen: 'Mostrar en pantalla completa',
	getWeekDays: function () {
		return this.weekdays
	},
	getMonths: function () {
		return this.months
	},
	getShortWeekDays: function () {
		return this.weekdays.map(function (day) {
			return day.substring(0, 3)
		})
	},
	getShortMonths: function () {
		return this.months.map(function (month) {
			return month.substring(0, 3)
		})
	},
}
Highcharts.setOptions({
	lang: {
		months: lang_es.getMonths(),
		weekdays: lang_es.getWeekDays(),
		shortWeekdays: lang_es.getShortWeekDays(),
		shortMonths: lang_es.getShortMonths(),
		downloadJPEG: lang_es.downloadJPEG,
		downloadPDF: lang_es.downloadPDF,
		downloadPNG: lang_es.downloadPNG,
		downloadSVG: lang_es.downloadSVG,
		downloadCSV: lang_es.downloadCSV,
		downloadXLS: lang_es.downloadXLS,
		hideData: lang_es.hideData,
		viewData: lang_es.viewData,
		viewFullscreen: lang_es.viewFullscreen,
		printChart: lang_es.printChart,
		resetZoom: lang_es.resetZoom,
		resetZoomTitle: lang_es.resetZoomTitle,
	},
})