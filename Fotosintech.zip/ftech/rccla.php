<!DOCTYPE html>
<html lang="es">

<head>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
</head>
<body>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU"
    crossorigin="anonymous">
<script src="js/login.js"></script>
<script src="js/code.js"></script>
<script src="js/sc.js"></script>

<?php

include_once "vendor//vendor/autoload.php";
USE PHPMailer\PHPMailer\PHPMailer;
include('models/datos.php');

// Generando clave aleatoria
$logitudPass = 4;
$miPassword  = substr(md5(microtime()), 1, $logitudPass);
$clave       = $miPassword;

$correo             = trim($_REQUEST['email']); // Quitamos algun espacio en blanco
$consulta           = ("SELECT * FROM persona WHERE emaper ='" . $correo . "'");
$queryconsulta      = mysqli_query($con, $consulta);
$cantidadConsulta   = mysqli_num_rows($queryconsulta);
$dataConsulta       = mysqli_fetch_array($queryconsulta);

if ($cantidadConsulta == 0) {
    header("Location:index.php?errorEmail=1");
    exit();
} else {
    $updateClave    = ("UPDATE persona SET passper='$clave' WHERE emaper='" . $correo . "' ");
    $queryResult    = mysqli_query($con, $updateClave);

    $mail = new PHPMailer();
    $mail->isSMTP();
    $mail->Host = "smtp.gmail.com";
    $mail->SMTPAuth = true;
    $mail->Username = "brayan1075652425.c@gmail.com";
    $mail->Password = "nyag weit qyfa qwwl";
    $mail->SMTPSecure = "ssl";
    $mail->Port = 465;
    $destinatario = $correo;
    $mail->addAddress($destinatario);
    $destinatario = $correo;
    $mail->Subject = "Recuperar Clave - FOTOSINTECH ";

    // Configurar el contenido del correo (HTML)
    $mail->isHTML(true);
    $mail->Subject = 'Recuperar Clave Acceso-FOTOSINTECH';
    $mail->Body = '
        <!DOCTYPE html>
        <html lang="es">

        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
        </head>

        <body>
            <div>
                <h2>Recuperar Contraseña</h2>
                <p>Hola, ' . $dataConsulta['nomper'] . '&nbsp;' . $dataConsulta['apper'] . '.</p>
                <p>Recibimos una solicitud para restablecer tu contraseña. Haz clic en el siguiente botón para cambiar tu contraseña:</p>
                <a href="https://tu-sitio.com/recuperar-contrasena?token=123456"
                    style="display: inline-block; padding: 10px 20px; background-color: #00495c; color: white; text-decoration: none; border-radius: 5px;">Recuperar Contraseña</a>
                <p>Si no realizaste esta solicitud, puedes ignorar este correo.</p>
                <p>Gracias,<br>Tu Equipo de FOTOSINTECH</p>
                <img src="https://tu-sitio.com/ruta-de-la-imagen.png"
                    style="max-width: 100%; height: auto; display: block; margin: 20px auto;">

            </div>
        </body>

        </html>
    ';

    // Enviar correo electrónico
    if (!$mail->send()) {
        ?>
        <script>
Swal.fire({
    icon: 'warning',
    title: 'Importante.!',
    text: 'El correo ingresado no coincide con el registrado',  
    confirmButtonColor: '#00495c',
    didDestroy: () => {
        window.location.href = 'index.php';
    }
});
        </script>
    <?php
        
    } else {
        // Definición de la función Enviado
        function Enviado()
        {
            ?>
            <script>
    let targetElement = document.querySelector('body');
    
    let rutaC = location.href;
    Swal.fire({
        icon: 'success',
        title: 'Felicidades.!',
        text: 'Revisa tu correo para continuar con la recuperación de tu cuenta',  
        confirmButtonColor: '#00495c',
        didDestroy: () => {
            window.location.href = 'index.php';
        }
    });

            </script>
        <?php
        }

        // Llamada a la función Enviado
        Enviado();
    }
}
?>
</body>
</html>