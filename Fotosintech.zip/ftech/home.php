<?php
require_once("models/seguridad.php");
?>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fotosintech</title>
    <link rel="shortcut icon" href="img/logo-ftech.png">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" crossorigin="anonymous" referrerpolicy="no-referrer"/>

    <!-- BOOTSTRAP 5 -->

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>

<!-- SWEET ALERTS 2 -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <!-- JQUERY -->
    <script src="https://code.jquery.com/jquery-3.7.0.min.js" integrity="sha256-2Pmvv0kuTBOenSvLm6bvfBSSHrUJ+3A7x6P5Ebd07/g=" crossorigin="anonymous"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <!-- DATA TABLES -->
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.2.0/css/bootstrap.min.css" />
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.13.4/css/dataTables.bootstrap5.min.css" />
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/responsive/2.4.1/css/responsive.bootstrap5.min.css" />
    <script src="https://code.jquery.com/jquery-3.7.0.min.js" integrity="sha256-2Pmvv0kuTBOenSvLm6bvfBSSHrUJ+3A7x6P5Ebd07/g=" crossorigin="anonymous"></script>
    <script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.4/js/dataTables.bootstrap5.min.js"></script>
    <script src="https://cdn.datatables.net/responsive/2.4.1/js/dataTables.responsive.min.js"></script>
    <script src="https://cdn.datatables.net/responsive/2.4.1/js/responsive.bootstrap5.min.js"></script>

    <!-- HIGHCHARTS -->
    <script src="https://code.highcharts.com/highcharts.js"></script>

    <link rel="stylesheet" href="css/estilos.css">
    <script src="js/code.js"></script>
    <script src="js/sc.js"></script>
</head>
<body>
    <?php
        date_default_timezone_set('America/Bogota');
        $nmfl = date('YmdHis');
        $pg = isset($_REQUEST['pg']) ? $_REQUEST['pg']:NULL;
        require_once("models/conexion.php");
        require_once("controllers/misfuc.php");
        require_once("views/vmen.php");
        require_once("controllers/optimg.php");
        require_once("views/cab.php");

        $ope = isset($_REQUEST['ope']) ? $_REQUEST['ope']:NULL;
      
        $mos = 0;
        $est = 0;
        $rut = validar($pg);
        if ($rut) {
          $pagnom = $rut[0]['pagnom'];
        } else {
          $pagnom = '';
        }
        echo '<main>';
        if ($rut) {
          $mos = $rut[0]['pagmos'];
          if ($ope == "edit") $est = 1;
          titulo($rut[0]['icono'], $rut[0]['pagnom'], $rut[0]['pagmos']);
          echo '<div id="err"></div>';
          echo "<script>err();</script>";
          require_once($rut[0]['pagarc']);
        } else {
          echo 'en construccion';
        }
        require_once("views/pie.php");
        echo '</main>';
      
        ?>
    </body>
<script src="js/login.js"></script>

      
</html>